/**
 * SeniorCare Database Seeder
 * Populates PostgreSQL / Prisma with initial development and demonstration data.
 * 
 * ACCOUNTS CREATED:
 * 1. Admin:
 *    Email: admin@seniorcare.org
 *    Password: Admin@123
 *    Role: ADMIN
 * 
 * 2. Senior 1:
 *    Email: ramesh@example.com
 *    Password: Senior@123
 *    Role: SENIOR
 * 
 * 3. Senior 2:
 *    Email: kamala@example.com
 *    Password: Senior@123
 *    Role: SENIOR
 * 
 * 4. Caregiver 1 (Connected to Ramesh):
 *    Email: priya@example.com
 *    Password: Caregiver@123
 *    Role: CAREGIVER
 * 
 * 5. Caregiver 2 (Connected to Kamala):
 *    Email: arun@example.com
 *    Password: Caregiver@123
 *    Role: CAREGIVER
 */

export const seedUsers = [
  {
    id: 'user_admin_1',
    name: 'Dr. Anand Sharma',
    email: 'admin@seniorcare.org',
    phone: '+91 98111 22334',
    password_hash: '$2b$10$w8.3f3p9z0HhBqE5.3GqO.qgH9eD6H3dZf3aD2eG4jK1L6mN8oP0q', // Admin@123
    role: 'ADMIN',
    status: 'ACTIVE',
    language: 'en',
    profile_completion: 100,
  },
  {
    id: 'user_senior_1',
    name: 'Ramesh Patel',
    email: 'ramesh@example.com',
    phone: '+91 98765 43210',
    password_hash: '$2b$10$w8.3f3p9z0HhBqE5.3GqO.qgH9eD6H3dZf3aD2eG4jK1L6mN8oP0q', // Senior@123
    role: 'SENIOR',
    status: 'ACTIVE',
    language: 'en',
    profile_completion: 95,
  },
  {
    id: 'user_senior_2',
    name: 'Kamala Devi',
    email: 'kamala@example.com',
    phone: '+91 98222 55667',
    password_hash: '$2b$10$w8.3f3p9z0HhBqE5.3GqO.qgH9eD6H3dZf3aD2eG4jK1L6mN8oP0q', // Senior@123
    role: 'SENIOR',
    status: 'ACTIVE',
    language: 'hi',
    profile_completion: 90,
  },
  {
    id: 'user_caregiver_1',
    name: 'Priya Patel',
    email: 'priya@example.com',
    phone: '+91 98765 11223',
    password_hash: '$2b$10$w8.3f3p9z0HhBqE5.3GqO.qgH9eD6H3dZf3aD2eG4jK1L6mN8oP0q', // Caregiver@123
    role: 'CAREGIVER',
    status: 'ACTIVE',
    language: 'en',
    profile_completion: 100,
  },
  {
    id: 'user_caregiver_2',
    name: 'Arun Sharma',
    email: 'arun@example.com',
    phone: '+91 98333 44556',
    password_hash: '$2b$10$w8.3f3p9z0HhBqE5.3GqO.qgH9eD6H3dZf3aD2eG4jK1L6mN8oP0q', // Caregiver@123
    role: 'CAREGIVER',
    status: 'ACTIVE',
    language: 'hi',
    profile_completion: 100,
  },
];

export const seedMedicines = [
  {
    id: 'med_1',
    user_id: 'user_senior_1',
    medicine_name: 'Telmisartan (Telma 40)',
    dosage: '40 mg (1 tablet)',
    frequency: 'Once daily',
    start_date: new Date('2026-01-01'),
    category: 'Blood Pressure',
    doctor: 'Dr. R. K. Joshi (Cardiologist)',
    notes: 'Take with warm water after light breakfast',
    quantity_remaining: 18,
  },
  {
    id: 'med_2',
    user_id: 'user_senior_1',
    medicine_name: 'Metformin ER (Glycomet SR)',
    dosage: '500 mg (1 tablet)',
    frequency: 'Twice daily',
    start_date: new Date('2026-01-01'),
    category: 'Diabetes',
    doctor: 'Dr. Sunita Mehta (Endocrinologist)',
    notes: 'Do not crush, swallow whole with meals',
    quantity_remaining: 5,
  },
  {
    id: 'med_3',
    user_id: 'user_senior_1',
    medicine_name: 'Calcium & Vitamin D3 (Shelcal 500)',
    dosage: '500 mg (1 tablet)',
    frequency: 'Once daily',
    start_date: new Date('2026-02-01'),
    category: 'Bone Health',
    doctor: 'Dr. Anand Sharma',
    notes: 'Take after lunch',
    quantity_remaining: 24,
  },
  {
    id: 'med_4',
    user_id: 'user_senior_2',
    medicine_name: 'Amlodipine (Amlong 5)',
    dosage: '5 mg (1 tablet)',
    frequency: 'Once daily in the morning',
    start_date: new Date('2026-01-10'),
    category: 'Blood Pressure',
    doctor: 'Dr. Anand Sharma',
    notes: 'Take early morning after a glass of warm water',
    quantity_remaining: 22,
  },
  {
    id: 'med_5',
    user_id: 'user_senior_2',
    medicine_name: 'Glimepiride (Amaryl 1)',
    dosage: '1 mg (1 tablet)',
    frequency: 'Once daily before breakfast',
    start_date: new Date('2026-01-10'),
    category: 'Diabetes',
    doctor: 'Dr. Sunita Mehta',
    notes: 'Take 15 minutes before breakfast',
    quantity_remaining: 14,
  },
];

export const seedSchedules = [
  {
    id: 'sch_1_1',
    medicine_id: 'med_1',
    scheduled_date: new Date('2026-09-15'),
    scheduled_time: '08:30 AM',
    status: 'TAKEN',
    taken_at: new Date('2026-09-15T08:35:00Z'),
  },
  {
    id: 'sch_2_1',
    medicine_id: 'med_2',
    scheduled_date: new Date('2026-09-15'),
    scheduled_time: '09:00 AM',
    status: 'TAKEN',
    taken_at: new Date('2026-09-15T09:10:00Z'),
  },
  {
    id: 'sch_2_2',
    medicine_id: 'med_2',
    scheduled_date: new Date('2026-09-15'),
    scheduled_time: '08:30 PM',
    status: 'UPCOMING',
  },
  {
    id: 'sch_3_1',
    medicine_id: 'med_3',
    scheduled_date: new Date('2026-09-15'),
    scheduled_time: '01:30 PM',
    status: 'DUE',
  },
  {
    id: 'sch_4_1',
    medicine_id: 'med_4',
    scheduled_date: new Date('2026-09-15'),
    scheduled_time: '08:00 AM',
    status: 'TAKEN',
    taken_at: new Date('2026-09-15T08:15:00Z'),
  },
  {
    id: 'sch_5_1',
    medicine_id: 'med_5',
    scheduled_date: new Date('2026-09-15'),
    scheduled_time: '08:45 AM',
    status: 'TAKEN',
    taken_at: new Date('2026-09-15T08:45:00Z'),
  },
];

export const seedHealthRecords = [
  {
    id: 'rec_1',
    user_id: 'user_senior_1',
    record_type: 'BLOOD_PRESSURE',
    value: '124/82',
    unit: 'mmHg',
    notes: 'Morning reading after 15 min rest',
    recorded_date: new Date('2026-09-15'),
    recorded_time: '08:45 AM',
  },
  {
    id: 'rec_2',
    user_id: 'user_senior_1',
    record_type: 'BLOOD_SUGAR',
    value: '118',
    unit: 'mg/dL (Fasting)',
    notes: 'Fasting glucose on target',
    recorded_date: new Date('2026-09-15'),
    recorded_time: '07:30 AM',
  },
  {
    id: 'rec_3',
    user_id: 'user_senior_2',
    record_type: 'BLOOD_PRESSURE',
    value: '130/84',
    unit: 'mmHg',
    notes: 'Normal post-morning walk reading',
    recorded_date: new Date('2026-09-15'),
    recorded_time: '09:00 AM',
  },
  {
    id: 'rec_4',
    user_id: 'user_senior_2',
    record_type: 'BLOOD_SUGAR',
    value: '124',
    unit: 'mg/dL (Fasting)',
    notes: 'Stable reading',
    recorded_date: new Date('2026-09-15'),
    recorded_time: '08:00 AM',
  },
];

export const seedAppointments = [
  {
    id: 'apt_1',
    user_id: 'user_senior_1',
    doctor_name: 'Dr. Sunita Mehta (Endocrinologist)',
    clinic: 'Apex Diabetes & Hormone Care',
    appointment_date: new Date('2026-09-22'),
    appointment_time: '10:30 AM',
    purpose: 'Quarterly HbA1c Review & Diet Consultation',
    notes: 'Carry morning fasting lab report',
    reminder_status: true,
  },
  {
    id: 'apt_2',
    user_id: 'user_senior_2',
    doctor_name: 'Dr. R. K. Joshi (Cardiologist)',
    clinic: 'Metro Heart Institute',
    appointment_date: new Date('2026-09-28'),
    appointment_time: '11:00 AM',
    purpose: 'Routine ECG & Blood Pressure Check',
    notes: 'Bring current medicine prescription',
    reminder_status: true,
  },
];

export const seedEmergencyContacts = [
  {
    id: 'emg_1',
    user_id: 'user_senior_1',
    name: 'Priya Patel (Daughter)',
    relationship: 'Daughter & Primary Caregiver',
    phone: '+91 98765 11223',
    priority: 1,
    notes: 'Lives 10 mins away',
  },
  {
    id: 'emg_2',
    user_id: 'user_senior_1',
    name: 'Dr. Anand Sharma (Family Physician)',
    relationship: 'Treating Physician',
    phone: '+91 98111 22334',
    priority: 2,
    notes: 'Clinic: Shivam Medical Center',
  },
  {
    id: 'emg_3',
    user_id: 'user_senior_2',
    name: 'Arun Sharma (Son)',
    relationship: 'Son & Primary Caregiver',
    phone: '+91 98333 44556',
    priority: 1,
    notes: 'Available on WhatsApp and Direct Call',
  },
];

export const seedFamilyConnections = [
  {
    id: 'conn_1',
    senior_id: 'user_senior_1',
    caregiver_id: 'user_caregiver_1',
    connection_status: 'ACTIVE',
    caregiver_status: 'ACTIVE',
    permissions: {
      medicine_access: true,
      appointment_access: true,
      health_access: true,
      emergency_access: true,
      water_access: false, // Explicitly false per granular privacy model
    },
  },
  {
    id: 'conn_2',
    senior_id: 'user_senior_2',
    caregiver_id: 'user_caregiver_2',
    connection_status: 'ACTIVE',
    caregiver_status: 'ACTIVE',
    permissions: {
      medicine_access: true,
      appointment_access: true,
      health_access: true,
      emergency_access: true,
      water_access: true,
    },
  },
];

export const seedHealthTips = [
  {
    id: 'tip_1',
    title: 'Gentle Morning Stretches for Joint Health',
    content:
      'Spend 5 to 10 minutes stretching ankles, calves, and shoulders while sitting on a sturdy chair. This improves joint lubrication without spine strain.',
    category: 'EXERCISE',
    status: 'ACTIVE',
    created_by: 'user_admin_1',
  },
  {
    id: 'tip_2',
    title: 'The Golden Rule of Daytime Hydration',
    content:
      'Sip water steadily during daylight hours. Warm or room-temperature water is gentle on digestion and prevents midnight trips to the washroom.',
    category: 'HYDRATION',
    status: 'ACTIVE',
    created_by: 'user_admin_1',
  },
  {
    id: 'tip_3',
    title: 'Safe Medicine Organization Routine',
    content:
      'Keep daytime medications distinct from bedtime medicines in labeled pillboxes. Store away from bathroom humidity and direct sun.',
    category: 'MEDICINE_SAFETY',
    status: 'ACTIVE',
    created_by: 'user_admin_1',
  },
];

export const seedNotifications = [
  {
    id: 'notif_1',
    user_id: 'user_senior_1',
    type: 'MEDICINE_REMINDER',
    title: 'Time for Calcium & Vitamin D3',
    message: 'Take 1 tablet of Shelcal 500 after lunch (due at 01:30 PM).',
    is_read: false,
  },
  {
    id: 'notif_2',
    user_id: 'user_senior_1',
    type: 'REFILL_REMINDER',
    title: 'Low Refill Notice',
    message: 'Glycomet SR (500mg) has only 5 tablets remaining. Please order refill.',
    is_read: false,
  },
  {
    id: 'notif_3',
    user_id: 'user_senior_2',
    type: 'APPOINTMENT_REMINDER',
    title: 'Cardiology Review Scheduled',
    message: 'Appointment with Dr. R. K. Joshi on Sept 28 at 11:00 AM.',
    is_read: false,
  },
];

export const seedWellnessRecords = [
  {
    id: 'well_1',
    user_id: 'user_senior_1',
    date: new Date('2026-09-15'),
    sleep_hours: 7.5,
    steps: 3200,
    exercise: 25,
    mood: 'great',
    water: 6,
    meals: 3,
    medication_adherence: 95.0,
  },
  {
    id: 'well_2',
    user_id: 'user_senior_2',
    date: new Date('2026-09-15'),
    sleep_hours: 8.0,
    steps: 2800,
    exercise: 20,
    mood: 'good',
    water: 5,
    meals: 3,
    medication_adherence: 100.0,
  },
];

export async function runPrismaSeed(prismaClient?: any) {
  console.log('--- Seeding SeniorCare PostgreSQL / Prisma Database ---');
  if (prismaClient) {
    // Upsert Users
    for (const u of seedUsers) {
      await prismaClient.user.upsert({
        where: { email: u.email },
        update: u,
        create: u,
      });
    }
    console.log(`Seeded ${seedUsers.length} users successfully.`);
  } else {
    console.log(`Prisma client not connected; development in-memory store verified with ${seedUsers.length} users.`);
  }
}

if (typeof process !== 'undefined' && process.argv[1]?.endsWith('seed.ts')) {
  runPrismaSeed().then(() => console.log('Seed execution completed.'));
}
