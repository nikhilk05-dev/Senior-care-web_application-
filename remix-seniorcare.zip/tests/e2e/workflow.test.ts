/**
 * SeniorCare End-to-End Workflow Test
 * Specifically executes the exact required lifecycle:
 * Signup -> Login -> Complete Profile -> Add Medicine -> Receive Reminder -> Mark Medicine Taken -> Dashboard Updated
 */

import { TestResult } from '../unit/adherence.test';

const BASE_URL = 'http://127.0.0.1:3000';

export async function runE2EWorkflowTests(): Promise<TestResult[]> {
  const results: TestResult[] = [];

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      results.push({ suite: 'E2E Workflow', name, passed: true });
    } catch (err: any) {
      results.push({ suite: 'E2E Workflow', name, passed: false, error: err?.message || String(err) });
    }
  }

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  function assertEquals(actual: any, expected: any, msg?: string) {
    if (actual !== expected) {
      throw new Error(`${msg ? msg + ': ' : ''}Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
    }
  }

  const testEmail = `senior.e2e.${Date.now()}@example.com`;
  const testPassword = 'SecurePassword456!';
  let userId = '';
  let medicineId = '';

  await test('Step 1: Signup new Senior user', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Nathuram Sharma',
        email: testEmail,
        password: testPassword,
        phone: '+91 98111 99887',
        role: 'senior',
      }),
    });
    const data = await res.json();
    assert(res.status === 201 && data.success, `Registration failed: ${data.message}`);
    assert(Boolean(data.user?.id), 'User ID must be generated');
    userId = data.user.id;
  });

  await test('Step 2: Login with new credentials', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testEmail,
        password: testPassword,
        role: 'senior',
      }),
    });
    const data = await res.json();
    assert(res.ok && data.success, `Login failed: ${data.message}`);
    assertEquals(data.user.id, userId, 'Logged in user ID matches registered ID');
    assertEquals(data.user.role, 'senior', 'Role is senior');
  });

  await test('Step 3: Complete Senior Profile with Health & Medical Info', async () => {
    const res = await fetch(`${BASE_URL}/api/users/me`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': userId,
      },
      body: JSON.stringify({
        age: 74,
        gender: 'Male',
        bloodGroup: 'O+',
        allergies: ['Penicillin', 'Sulfa drugs'],
        medicalConditions: ['Hypertension', 'Mild Osteoarthritis'],
        profileCompletion: 100,
      }),
    });
    const data = await res.json();
    assert(res.ok && data.success, `Profile update failed: ${data.message}`);
    assertEquals(data.user.bloodGroup, 'O+', 'Blood group updated');
    assertEquals(data.user.profileCompletion, 100, 'Profile completion updated to 100%');
  });

  await test('Step 4: Add New Medicine Schedule', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': userId,
      },
      body: JSON.stringify({
        name: 'Losartan Potassium (Repace 50)',
        dosage: '50 mg (1 tablet)',
        frequency: 'Once daily in the morning',
        category: 'Blood Pressure',
        timing: 'after_food',
        times: ['08:30 AM'],
        prescribingDoctor: 'Dr. Anand Sharma',
        quantityRemaining: 30,
        refillThreshold: 7,
      }),
    });
    const data = await res.json();
    assert(res.status === 201 && data.success, `Add medicine failed: ${data.message}`);
    assert(Boolean(data.data?.id), 'Medicine ID generated');
    medicineId = data.data.id;
  });

  await test('Step 5: Receive / Verify Medicine Reminder Schedule', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines/${medicineId}`, {
      headers: { 'x-user-id': userId },
    });
    const data = await res.json();
    assert(res.ok && data.success, 'Fetched medicine schedule');
    assert(Array.isArray(data.data.schedules), 'Schedules array exists');
    assert(data.data.schedules.length > 0, 'Has at least one scheduled dose');
    assertEquals(data.data.schedules[0].time, '08:30 AM', 'Reminder time set to 08:30 AM');
    assert(data.data.schedules[0].status === 'upcoming' || data.data.schedules[0].status === 'due', 'Schedule status is upcoming or due');
  });

  await test('Step 6: Mark Medicine Taken and verify pill inventory decremented', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines/${medicineId}/taken`, {
      method: 'POST',
      headers: { 'x-user-id': userId },
    });
    const data = await res.json();
    assert(res.ok && data.success, 'Marked medicine as taken');
    assertEquals(data.data.schedules[0].status, 'taken', 'Schedule marked as taken');
    assert(Boolean(data.data.schedules[0].takenAt), 'Recorded exact time taken');
    assertEquals(data.data.quantityRemaining, 29, 'Pills remaining decremented from 30 to 29');
  });

  await test('Step 7: Dashboard Updated with 100% Adherence for taken dose', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines`, {
      headers: { 'x-user-id': userId },
    });
    const data = await res.json();
    assert(res.ok && data.success, 'Fetched updated medicine list');
    const userMeds = data.data;
    const allSchedules = userMeds.flatMap((m: any) => m.schedules || []);
    const takenCount = allSchedules.filter((s: any) => s.status === 'taken').length;
    const adherence = Math.round((takenCount / allSchedules.length) * 100);

    assertEquals(adherence, 100, 'Senior dashboard adherence is 100% after taking dose');
  });

  return results;
}
