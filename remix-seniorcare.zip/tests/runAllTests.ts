/**
 * SeniorCare Universal Test Runner
 * Executes Unit Tests, Integration Tests, and End-to-End Workflow Tests.
 */

import { runUnitTests } from './unit/adherence.test';
import { runIntegrationTests } from './integration/api.test';
import { runE2EWorkflowTests } from './e2e/workflow.test';

async function main() {
  console.log('====================================================');
  console.log('       SeniorCare Automated Test Suite Runner       ');
  console.log('====================================================\n');

  let allResults: Array<{ suite: string; name: string; passed: boolean; error?: string }> = [];

  // 1. Unit Tests
  console.log('▶ Running Unit Tests...');
  const unitResults = runUnitTests();
  allResults = allResults.concat(unitResults);

  // 2. Integration Tests
  console.log('▶ Running Integration Tests...');
  try {
    const integrationResults = await runIntegrationTests();
    allResults = allResults.concat(integrationResults);
  } catch (err) {
    console.error('Failed running integration tests:', err);
    allResults.push({
      suite: 'Integration Tests',
      name: 'Integration suite execution',
      passed: false,
      error: String(err),
    });
  }

  // 3. E2E Workflow Tests
  console.log('▶ Running E2E Workflow Tests...');
  try {
    const e2eResults = await runE2EWorkflowTests();
    allResults = allResults.concat(e2eResults);
  } catch (err) {
    console.error('Failed running E2E tests:', err);
    allResults.push({
      suite: 'E2E Workflow',
      name: 'E2E suite execution',
      passed: false,
      error: String(err),
    });
  }

  // Report
  console.log('\n====================================================');
  console.log('                 Test Results Summary               ');
  console.log('====================================================');

  let passedCount = 0;
  let failedCount = 0;

  let currentSuite = '';
  for (const r of allResults) {
    if (r.suite !== currentSuite) {
      currentSuite = r.suite;
      console.log(`\n[${currentSuite}]`);
    }

    if (r.passed) {
      passedCount++;
      console.log(`  ✓ ${r.name}`);
    } else {
      failedCount++;
      console.log(`  ✗ ${r.name}`);
      console.log(`    Error: ${r.error}`);
    }
  }

  console.log('\n----------------------------------------------------');
  console.log(`Total Tests: ${allResults.length}`);
  console.log(`Passed:      ${passedCount}`);
  console.log(`Failed:      ${failedCount}`);
  console.log('----------------------------------------------------');

  if (failedCount > 0) {
    console.log('❌ Some tests failed.');
    process.exit(1);
  } else {
    console.log('✅ ALL TEST SUITES PASSED SUCCESSFULLY!');
    process.exit(0);
  }
}

main().catch((err) => {
  console.error('Unexpected error in test runner:', err);
  process.exit(1);
});
