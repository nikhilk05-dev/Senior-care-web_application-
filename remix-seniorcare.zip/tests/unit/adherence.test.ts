/**
 * SeniorCare Unit Tests
 * Covers: Role detection, Medicine adherence calculations, Wellness score computation,
 * Emergency priority sorting, Family permissions checks, and AI assistant safety guardrails.
 */

export interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

export function runUnitTests(): TestResult[] {
  const results: TestResult[] = [];

  function test(suite: string, name: string, fn: () => void) {
    try {
      fn();
      results.push({ suite, name, passed: true });
    } catch (err: any) {
      results.push({ suite, name, passed: false, error: err?.message || String(err) });
    }
  }

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  function assertEquals(actual: any, expected: any, msg?: string) {
    if (actual !== expected) {
      throw new Error(`${msg ? msg + ': ' : ''}Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
    }
  }

  // 1. Role Detection & Access Rules
  test('Role Detection', 'Identifies senior, caregiver, and admin roles correctly', () => {
    const roles = ['senior', 'caregiver', 'admin'];
    roles.forEach((r) => {
      assert(['senior', 'caregiver', 'admin'].includes(r), `Role ${r} is valid`);
    });

    const isSenior = (role: string) => role === 'senior';
    const isCaregiver = (role: string) => role === 'caregiver';
    const isAdmin = (role: string) => role === 'admin';

    assert(isSenior('senior') && !isSenior('caregiver'), 'Senior role detection works');
    assert(isCaregiver('caregiver') && !isCaregiver('admin'), 'Caregiver role detection works');
    assert(isAdmin('admin') && !isAdmin('senior'), 'Admin role detection works');
  });

  // 2. Medicine Adherence Calculation
  test('Medicine Adherence', 'Calculates 100% adherence when all doses are taken', () => {
    const schedules = [
      { id: '1', status: 'taken' },
      { id: '2', status: 'taken' },
      { id: '3', status: 'taken' },
    ];
    const taken = schedules.filter((s) => s.status === 'taken').length;
    const rate = Math.round((taken / schedules.length) * 100);
    assertEquals(rate, 100, 'Adherence should be 100%');
  });

  test('Medicine Adherence', 'Calculates partial adherence accurately with taken, due, and skipped', () => {
    const schedules = [
      { id: '1', status: 'taken' },
      { id: '2', status: 'taken' },
      { id: '3', status: 'skipped' },
      { id: '4', status: 'due' },
    ];
    const taken = schedules.filter((s) => s.status === 'taken').length;
    const rate = Math.round((taken / schedules.length) * 100);
    assertEquals(rate, 50, 'Adherence should be 50%');
  });

  test('Medicine Adherence', 'Returns 100% adherence when no scheduled doses exist', () => {
    const schedules: any[] = [];
    const rate = schedules.length > 0 ? Math.round((schedules.filter((s) => s.status === 'taken').length / schedules.length) * 100) : 100;
    assertEquals(rate, 100, 'Empty schedules should default to 100%');
  });

  // 3. Composite Wellness Score Computation
  test('Wellness Scoring', 'Computes weighted composite wellness score correctly', () => {
    const calculateScore = (sleepHours: number, steps: number, adherence: number, mood: string) => {
      const sleepScore = Math.min(100, (sleepHours / 8) * 100) * 0.25;
      const walkScore = Math.min(100, (steps / 4000) * 100) * 0.25;
      const medScore = adherence * 0.3;
      const moodScore = (mood === 'great' ? 100 : mood === 'good' ? 85 : mood === 'okay' ? 70 : 50) * 0.2;
      return Math.round(sleepScore + walkScore + medScore + moodScore);
    };

    // 8h sleep (100% * 0.25 = 25), 4000 steps (100% * 0.25 = 25), 100% med (30), 'great' mood (100 * 0.2 = 20) => 100
    const perfectScore = calculateScore(8, 4000, 100, 'great');
    assertEquals(perfectScore, 100, 'Perfect metrics should yield 100');

    // 7h sleep (87.5% * 0.25 = 21.875), 3000 steps (75% * 0.25 = 18.75), 100% med (30), 'good' mood (85 * 0.2 = 17) => 88
    const realisticScore = calculateScore(7, 3000, 100, 'good');
    assertEquals(realisticScore, 88, 'Realistic metrics should yield 88');
  });

  // 4. Emergency Contacts Priority Ordering
  test('Emergency Contacts Priority', 'Correctly sorts emergency contacts by ascending priority', () => {
    const contacts = [
      { id: '3', name: 'Doctor', priority: 3 },
      { id: '1', name: 'Primary Caregiver', priority: 1 },
      { id: '4', name: 'Ambulance', priority: 4 },
      { id: '2', name: 'Secondary Family', priority: 2 },
    ];
    const sorted = [...contacts].sort((a, b) => a.priority - b.priority);
    assertEquals(sorted[0].priority, 1, 'Top priority must be 1');
    assertEquals(sorted[1].priority, 2, 'Second priority must be 2');
    assertEquals(sorted[2].priority, 3, 'Third priority must be 3');
    assertEquals(sorted[3].priority, 4, 'Fourth priority must be 4');
  });

  // 5. Family Granular Permissions Gate
  test('Family Permissions Gate', 'Allows or denies access based on permission flags', () => {
    const fullPermissions = {
      medicineAccess: true,
      appointmentAccess: true,
      healthAccess: true,
      emergencyAccess: true,
      waterAccess: true,
    };

    const restrictedPermissions = {
      medicineAccess: false,
      appointmentAccess: false,
      healthAccess: false,
      emergencyAccess: true,
      waterAccess: false,
    };

    const canViewMedicines = (perms: typeof fullPermissions) => perms.medicineAccess === true;
    const canViewEmergency = (perms: typeof fullPermissions) => perms.emergencyAccess === true;

    assert(canViewMedicines(fullPermissions), 'Full permissions allow medicine viewing');
    assert(!canViewMedicines(restrictedPermissions), 'Restricted permissions block medicine viewing');
    assert(canViewEmergency(restrictedPermissions), 'Restricted permissions allow emergency viewing');
  });

  // 6. AI Assistant Safety Guardrails
  test('AI Safety Guardrails', 'Detects medical emergencies and directs user to emergency SOS', () => {
    const emergencyKeywords = ['chest pain', 'heart attack', 'unconscious', 'cannot breathe', 'severe bleeding'];
    const checkIsEmergency = (prompt: string) => {
      const lower = prompt.toLowerCase();
      return emergencyKeywords.some((kw) => lower.includes(kw));
    };

    assert(checkIsEmergency('My grandfather is having severe chest pain right now'), 'Detects chest pain emergency');
    assert(checkIsEmergency('Patient is unconscious on the floor'), 'Detects unconscious patient');
    assert(!checkIsEmergency('What time should I take my vitamins?'), 'Non-emergency query is clean');
  });

  test('AI Safety Guardrails', 'Enforces inclusion of disclaimer in medical advice responses', () => {
    const sampleAiResponse =
      'Take your blood pressure medication consistently with water. Disclaimer: This information is for educational purposes only. Always consult your healthcare provider or primary doctor before modifying prescription medications.';

    assert(
      sampleAiResponse.includes('consult your healthcare provider') || sampleAiResponse.includes('Disclaimer'),
      'AI response contains mandatory medical disclaimer'
    );
  });

  return results;
}
