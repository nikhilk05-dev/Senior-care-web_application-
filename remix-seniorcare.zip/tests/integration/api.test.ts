/**
 * SeniorCare Integration Tests
 * Tests all REST API endpoints against the running server:
 * Auth, Profiles, Medicines CRUD & Adherence, Health Records, Appointments,
 * Emergency SOS & Contacts, Family Permissions, Water, Wellness, Notifications, Admin APIs, Search.
 */

import { TestResult } from '../unit/adherence.test';

const BASE_URL = 'http://127.0.0.1:3000';

export async function runIntegrationTests(): Promise<TestResult[]> {
  const results: TestResult[] = [];

  async function test(suite: string, name: string, fn: () => Promise<void>) {
    try {
      await fn();
      results.push({ suite, name, passed: true });
    } catch (err: any) {
      results.push({ suite, name, passed: false, error: err?.message || String(err) });
    }
  }

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  function assertEquals(actual: any, expected: any, msg?: string) {
    if (actual !== expected) {
      throw new Error(`${msg ? msg + ': ' : ''}Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
    }
  }

  // 1. Authentication Endpoints
  await test('API: Auth', 'POST /api/auth/login succeeds for Senior user', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'ramesh@example.com', password: 'password123', role: 'senior' }),
    });
    const data = await res.json();
    assert(res.ok && data.success, 'Login response must be success');
    assertEquals(data.user.role, 'senior', 'User role should be senior');
  });

  await test('API: Auth', 'POST /api/auth/login succeeds for Caregiver user', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'priya@example.com', password: 'password123', role: 'caregiver' }),
    });
    const data = await res.json();
    assert(res.ok && data.success, 'Caregiver login succeeds');
    assertEquals(data.user.role, 'caregiver', 'User role should be caregiver');
  });

  await test('API: Auth', 'POST /api/auth/login succeeds for Admin user', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@seniorcare.org', password: 'password123', role: 'admin' }),
    });
    const data = await res.json();
    assert(res.ok && data.success, 'Admin login succeeds');
    assertEquals(data.user.role, 'admin', 'User role should be admin');
  });

  await test('API: Auth', 'POST /api/auth/login rejects incorrect password', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'ramesh@example.com', password: 'wrongPassword123' }),
    });
    const data = await res.json();
    assertEquals(res.status, 401, 'Should return 401 for bad password');
    assert(!data.success, 'Success flag must be false');
  });

  await test('API: Auth', 'POST /api/auth/forgot-password & reset-password succeed', async () => {
    const forgotRes = await fetch(`${BASE_URL}/api/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'ramesh@example.com' }),
    });
    const forgotData = await forgotRes.json();
    assert(forgotData.success, 'Forgot password response should be success');

    const resetRes = await fetch(`${BASE_URL}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'ramesh@example.com', newPassword: 'newSecretPassword123' }),
    });
    const resetData = await resetRes.json();
    assert(resetData.success, 'Reset password response should be success');
  });

  // 2. User Profile
  await test('API: User Profile', 'GET & PUT /api/users/me operates correctly', async () => {
    const getRes = await fetch(`${BASE_URL}/api/users/me`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const getData = await getRes.json();
    assert(getData.success, 'Fetched profile successfully');
    assertEquals(getData.user.id, 'user_senior_1');

    const putRes = await fetch(`${BASE_URL}/api/users/me`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({ age: 68, bloodGroup: 'B+' }),
    });
    const putData = await putRes.json();
    assert(putData.success, 'Updated profile successfully');
  });

  // 3. Medicines CRUD & Adherence
  let createdMedId = '';
  await test('API: Medicines', 'GET /api/medicines returns senior medication list', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const data = await res.json();
    assert(data.success && Array.isArray(data.data), 'Medicines is array');
    assert(data.data.length > 0, 'Has initial medicines');
  });

  await test('API: Medicines', 'POST /api/medicines creates a new medicine schedule', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({
        name: 'Multivitamin Senior Vitality',
        dosage: '1 capsule',
        frequency: 'Once daily',
        category: 'Supplements',
        timing: 'after_food',
        times: ['09:00 AM'],
        quantityRemaining: 30,
        refillThreshold: 5,
      }),
    });
    const data = await res.json();
    assert(res.status === 201 && data.success, 'Created medicine successfully');
    assert(Boolean(data.data.id), 'Medicine has valid id');
    createdMedId = data.data.id;
  });

  await test('API: Medicines', 'GET /api/medicines/:id fetches medicine by ID', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines/${createdMedId}`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const data = await res.json();
    assert(data.success, 'Fetched medicine by ID');
    assertEquals(data.data.name, 'Multivitamin Senior Vitality');
  });

  await test('API: Medicines', 'POST /api/medicines/:id/taken marks dose taken and decreases count', async () => {
    const initialRes = await fetch(`${BASE_URL}/api/medicines/${createdMedId}`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const initialData = await initialRes.json();
    const initialQty = initialData.data.quantityRemaining;

    const res = await fetch(`${BASE_URL}/api/medicines/${createdMedId}/taken`, {
      method: 'POST',
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const data = await res.json();
    assert(data.success, 'Marked medicine as taken');
    assertEquals(data.data.quantityRemaining, initialQty - 1, 'Quantity remaining decremented by 1');
  });

  await test('API: Medicines', 'DELETE /api/medicines/:id removes medicine', async () => {
    const res = await fetch(`${BASE_URL}/api/medicines/${createdMedId}`, {
      method: 'DELETE',
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const data = await res.json();
    assert(data.success, 'Medicine deleted successfully');
  });

  // 4. Health Records
  let createdRecId = '';
  await test('API: Health Records', 'POST & GET /api/health-records creates and reads vital signs', async () => {
    const postRes = await fetch(`${BASE_URL}/api/health-records`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({
        type: 'blood_pressure',
        value: '122/80',
        unit: 'mmHg',
        notes: 'Calm morning reading',
        status: 'normal',
      }),
    });
    const postData = await postRes.json();
    assert(postRes.status === 201 && postData.success, 'Created health record');
    createdRecId = postData.data.id;

    const getRes = await fetch(`${BASE_URL}/api/health-records/${createdRecId}`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const getData = await getRes.json();
    assert(getData.success, 'Fetched health record by ID');
    assertEquals(getData.data.value, '122/80');
  });

  await test('API: Health Records', 'GET /api/health-records/summary calculates vital summary', async () => {
    const res = await fetch(`${BASE_URL}/api/health-records/summary`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const data = await res.json();
    assert(data.success, 'Summary fetched');
    assert(Boolean(data.data.bloodPressure), 'Has latest BP');
    assert(Boolean(data.data.bloodSugar), 'Has latest Blood Sugar');
  });

  // 5. Appointments
  let createdApptId = '';
  await test('API: Appointments', 'POST, GET, and PUT /api/appointments manage clinic visits', async () => {
    const postRes = await fetch(`${BASE_URL}/api/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({
        doctorName: 'Dr. Anita Desai',
        clinic: 'Smile Dental Care',
        appointmentDate: '2026-10-15',
        appointmentTime: '11:00 AM',
        purpose: 'Dental cleaning & examination',
      }),
    });
    const postData = await postRes.json();
    assert(postRes.status === 201 && postData.success, 'Booked appointment');
    createdApptId = postData.data.id;

    const getRes = await fetch(`${BASE_URL}/api/appointments/${createdApptId}`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const getData = await getRes.json();
    assert(getData.success, 'Fetched appointment by ID');
    assertEquals(getData.data.doctorName, 'Dr. Anita Desai');

    const putRes = await fetch(`${BASE_URL}/api/appointments/${createdApptId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({ status: 'completed' }),
    });
    const putData = await putRes.json();
    assert(putData.success && putData.data.status === 'completed', 'Updated appointment status');
  });

  // 6. Emergency SOS & Contacts
  await test('API: Emergency', 'GET /api/emergency/contacts & /info return structured data', async () => {
    const contactsRes = await fetch(`${BASE_URL}/api/emergency/contacts`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const contactsData = await contactsRes.json();
    assert(contactsData.success && contactsData.data.length > 0, 'Contacts returned');
    assert(contactsData.data[0].priority <= contactsData.data[1].priority, 'Sorted by priority');

    const infoRes = await fetch(`${BASE_URL}/api/emergency/info`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const infoData = await infoRes.json();
    assert(infoData.success && Boolean(infoData.data.bloodGroup), 'Emergency info has blood group');
  });

  await test('API: Emergency', 'POST /api/emergency/sos broadcasts alert', async () => {
    const res = await fetch(`${BASE_URL}/api/emergency/sos`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({
        location: { latitude: 19.076, longitude: 72.8777, address: 'Bandra West, Mumbai' },
      }),
    });
    const data = await res.json();
    assert(data.success, 'Emergency SOS triggered successfully');
    assert(data.alert.contactsNotified > 0, 'Notified emergency contacts');
  });

  // 7. Family Connections & RBAC Permissions
  await test('API: Family & Permissions', 'Caregiver sees only permitted senior datasets', async () => {
    const res = await fetch(`${BASE_URL}/api/caregiver/seniors`, {
      headers: { 'x-user-id': 'user_caregiver_1' },
    });
    const data = await res.json();
    assert(data.success && Array.isArray(data.data), 'Caregiver seniors list returned');
    assert(data.data.length > 0, 'Connected senior present');
    const seniorItem = data.data[0];
    assert(Boolean(seniorItem.permissions), 'Permissions object present');
    if (seniorItem.permissions.medicineAccess) {
      assert(Array.isArray(seniorItem.medicines), 'Medicines accessible when permitted');
    }
  });

  // 8. Water Tracking
  await test('API: Water Tracking', 'POST /api/water/log increments glass and volume', async () => {
    const todayRes = await fetch(`${BASE_URL}/api/water/today`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const todayData = await todayRes.json();
    const initialGlasses = todayData.data.glasses;

    const logRes = await fetch(`${BASE_URL}/api/water/log`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({ amountMl: 250 }),
    });
    const logData = await logRes.json();
    assert(logData.success, 'Water logged successfully');
    assertEquals(logData.data.glasses, initialGlasses + 1, 'Glass count incremented');
  });

  // 9. Wellness Tracking
  await test('API: Wellness', 'POST /api/wellness logs daily score & metrics', async () => {
    const res = await fetch(`${BASE_URL}/api/wellness`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': 'user_senior_1',
      },
      body: JSON.stringify({
        sleepHours: 7.5,
        steps: 3500,
        exerciseMinutes: 20,
        mood: 'great',
        waterGlasses: 7,
        medicationAdherence: 100,
        notes: 'Good day overall',
      }),
    });
    const data = await res.json();
    assert(res.status === 201 && data.success, 'Wellness logged');
    assert(data.data.wellnessScore > 75, 'Wellness score is computed');
  });

  // 10. Admin API
  await test('API: Admin', 'GET /api/admin/stats and /users operate with full dashboard data', async () => {
    const statsRes = await fetch(`${BASE_URL}/api/admin/stats`);
    const statsData = await statsRes.json();
    assert(statsData.success, 'Stats fetched');
    assert(statsData.data.totalUsers >= 2, 'Has registered users');

    const usersRes = await fetch(`${BASE_URL}/api/admin/users`);
    const usersData = await usersRes.json();
    assert(usersData.success && Array.isArray(usersData.data), 'Users list returned');
  });

  // 11. Global Search
  await test('API: Search', 'GET /api/search finds medicine by name query', async () => {
    const res = await fetch(`${BASE_URL}/api/search?q=telma`, {
      headers: { 'x-user-id': 'user_senior_1' },
    });
    const data = await res.json();
    assert(data.success, 'Search succeeded');
    assert(data.data.medicines.length > 0, 'Found matching medicine');
  });

  return results;
}
