export type UserRole = 'senior' | 'family' | 'caregiver' | 'admin';
export type AccountStatus = 'active' | 'inactive' | 'suspended' | 'pending';
export type Language = 'en' | 'hi' | 'mr';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  status: AccountStatus;
  language: Language;
  avatar?: string;
  age?: number;
  gender?: string;
  bloodGroup?: string;
  allergies?: string[];
  medicalConditions?: string[];
  profileCompletion: number;
  createdAt: string;
  fontSize?: 'normal' | 'large' | 'xlarge';
  accountStatus?: string;
  address?: string;
  city?: string;
  height?: number; // cm
  weight?: number; // kg
  activityLevel?: 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active';
  dailyCalorieGoal?: number; // kcal
}

export type DoseStatus = 'upcoming' | 'due' | 'taken' | 'missed' | 'skipped';

export interface MedicineSchedule {
  id: string;
  time: string; // e.g., "08:00 AM"
  status: DoseStatus;
  takenAt?: string;
  slot?: 'morning' | 'afternoon' | 'evening' | 'night';
}

export interface Medicine {
  id: string;
  userId: string;
  name: string;
  dosage: string; // e.g., "500mg" or "1 tablet"
  frequency: string; // e.g., "Once daily", "Twice daily", "Thrice daily"
  category: string; // e.g., "Blood Pressure", "Diabetes", "Vitamins", "Heart"
  timing: 'before_food' | 'after_food' | 'with_food' | 'anytime';
  times: string[]; // e.g., ["08:00 AM", "08:00 PM"]
  schedules: MedicineSchedule[];
  startDate: string;
  endDate?: string;
  prescribingDoctor?: string;
  instructions?: string;
  notes?: string;
  quantityRemaining: number;
  refillThreshold: number;
  refillDate?: string;
  createdAt: string;
}

export type HealthRecordType =
  | 'blood_pressure'
  | 'blood_sugar'
  | 'weight'
  | 'temperature'
  | 'heart_rate'
  | 'oxygen'
  | 'doctor_notes'
  | 'symptoms';

export interface HealthRecord {
  id: string;
  userId: string;
  type: HealthRecordType;
  value: string; // e.g. "120/80" or "110"
  numericValue?: number;
  unit: string; // e.g. "mmHg", "mg/dL", "kg", "°F", "bpm", "%"
  recordedDate: string; // YYYY-MM-DD
  recordedTime: string; // HH:mm
  notes?: string;
  status?: 'normal' | 'warning' | 'critical';
  createdAt: string;
}

export type AppointmentType = 'hospital_visit' | 'clinic_visit' | 'video_consultation' | 'home_visit';
export type AppointmentStatus = 'requested' | 'confirmed' | 'completed' | 'cancelled' | 'upcoming';

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  hospitalClinic: string;
  phone: string;
  email: string;
  experienceYears: number;
  consultationFee: string;
  availableDays: string[];
  availableSlots: string[];
  rating: number;
  avatar?: string;
}

export interface Appointment {
  id: string;
  userId: string;
  doctorId?: string;
  doctorName: string;
  clinic: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // HH:mm
  appointmentType?: AppointmentType;
  purpose: string;
  reason?: string;
  notes?: string;
  status: AppointmentStatus;
  reminderStatus: boolean;
  createdAt: string;
}

export type DocumentType =
  | 'prescription'
  | 'blood_report'
  | 'xray_scan'
  | 'discharge_summary'
  | 'insurance_card'
  | 'vaccination_cert'
  | 'medical_certificate';

export interface MedicalDocument {
  id: string;
  seniorId: string;
  documentType: DocumentType;
  title: string;
  fileName: string;
  fileSize: string;
  uploadedBy: string;
  uploadedAt: string;
  doctorName?: string;
  hospitalClinic?: string;
  description?: string;
  fileUrl?: string;
  tags?: string[];
}

export type ServiceType =
  | 'medicine_delivery'
  | 'grocery_delivery'
  | 'doctor_visit'
  | 'home_nurse'
  | 'physiotherapy'
  | 'elder_transport'
  | 'home_repair'
  | 'document_assistance';

export interface ServiceRequest {
  id: string;
  seniorId: string;
  seniorName: string;
  serviceType: ServiceType;
  title: string;
  description: string;
  requestedDate: string;
  priority: 'normal' | 'urgent' | 'emergency';
  assignedTo?: string;
  assignedRole?: string;
  status: 'requested' | 'assigned' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: string;
  completedAt?: string;
}

export interface EmergencyAlert {
  id: string;
  seniorId: string;
  seniorName: string;
  seniorPhone: string;
  emergencyType: 'medical_emergency' | 'fall_detected' | 'chest_pain' | 'sos_button' | 'breathing_difficulty';
  latitude?: number;
  longitude?: number;
  address: string;
  description?: string;
  status: 'active' | 'acknowledged' | 'responding' | 'resolved' | 'cancelled';
  responderNotes?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface DirectMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'senior' | 'family' | 'caregiver' | 'admin';
  receiverId: string;
  receiverName: string;
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface AuditLogEntry {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  module: string;
  recordId?: string;
  ipAddress: string;
  createdAt: string;
}

export interface EmergencyContact {
  id: string;
  userId: string;
  name: string;
  relationship: string;
  phone: string;
  priority: number; // 1, 2, 3...
  notes?: string;
}

export interface EmergencyInformation {
  userId: string;
  name: string;
  bloodGroup: string;
  allergies: string[];
  medicalConditions: string[];
  primaryDoctor: string;
  doctorPhone: string;
  preferredHospital: string;
  insuranceNumber?: string;
  emergencyNotes?: string;
  updatedAt: string;
}

export interface FamilyPermissions {
  medicineAccess: boolean;
  appointmentAccess: boolean;
  healthAccess: boolean;
  emergencyAccess: boolean;
  waterAccess: boolean;
}

export interface FamilyMember {
  id: string;
  seniorId: string;
  caregiverId?: string;
  name: string;
  relationship: string;
  phone: string;
  email: string;
  isCaregiver: boolean;
  connectionStatus: 'connected' | 'pending' | 'rejected';
  permissions: FamilyPermissions;
  avatar?: string;
  createdAt: string;
}

export interface WaterDay {
  date: string;
  consumedMl: number;
  targetMl: number;
  glasses: number;
}

export interface WellnessRecord {
  id: string;
  userId: string;
  date: string;
  sleepHours: number;
  steps: number;
  exerciseMinutes: number;
  mood: 'great' | 'good' | 'okay' | 'low' | 'tired';
  waterGlasses: number;
  mealsCount: number;
  medicationAdherence: number;
  wellnessScore: number; // 0-100
  notes?: string;
}

export type NotificationType =
  | 'medicine_reminder'
  | 'missed_medicine'
  | 'appointment_reminder'
  | 'water_reminder'
  | 'health_tip'
  | 'family_notification'
  | 'refill_reminder'
  | 'emergency_alert'
  | 'system_notification'
  | 'medicine'
  | 'system'
  | 'general';

export interface NotificationItem {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  isRead: boolean;
  priority?: 'urgent' | 'high' | 'medium' | 'low';
  actionUrl?: string;
  createdAt: string;
}

export type TipCategory =
  | 'nutrition'
  | 'exercise'
  | 'hydration'
  | 'sleep'
  | 'medicine_safety'
  | 'mental_wellness'
  | 'preventive_care'
  | 'general_wellness';

export interface HealthTip {
  id: string;
  title: string;
  content: string;
  category: TipCategory;
  isActive: boolean;
  readTimeMinutes: number;
  iconName?: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  target: string;
  status: 'success' | 'warning' | 'info';
  timestamp: string;
}

export interface AdminDashboardStats {
  totalUsers: number;
  activeUsers: number;
  caregivers: number;
  medicinesTracked: number;
  overallAdherence: number;
  missedMedicinesToday: number;
  upcomingAppointments: number;
  healthRecordsCount: number;
  emergencyAlerts: number;
  activeNotifications: number;
}

// AI Studio & Gemini Suite Types
export type ChatRoleType = 'complex' | 'general' | 'fast';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  modelUsed?: string;
  roleType?: ChatRoleType;
}

export interface SearchGroundingSource {
  title: string;
  uri: string;
}

export interface MapsGroundingPlace {
  title: string;
  uri: string;
  address?: string;
  reviewSnippets?: string[];
}

export interface GeneratedMusic {
  id: string;
  title: string;
  prompt: string;
  mode: 'clip' | 'full';
  audioUrl: string;
  lyrics?: string;
  createdAt: string;
}

export interface GeneratedVideo {
  id: string;
  title: string;
  prompt: string;
  type: 'text-to-video' | 'image-to-video';
  aspectRatio: '16:9' | '9:16';
  status: 'queued' | 'processing' | 'completed' | 'failed';
  operationName?: string;
  videoUrl?: string;
  previewImageUrl?: string;
  createdAt: string;
  error?: string;
}

export interface GeneratedImageItem {
  id: string;
  title: string;
  prompt: string;
  mode: 'create' | 'edit';
  aspectRatio: string;
  imageUrl: string;
  originalImageUrl?: string;
  createdAt: string;
  modelUsed?: string;
}

export type MealType = 'breakfast' | 'lunch' | 'snacks' | 'dinner';

export interface CalorieRecord {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  foodName: string;
  mealType: MealType;
  quantity: number; // e.g., 1, 1.5, 2
  servingUnit?: string; // e.g., "serving", "cup", "bowl", "slice"
  calories: number;
  protein: number; // grams
  carbohydrates: number; // grams
  fat: number; // grams
  fiber: number; // grams
  createdAt: string;
  updatedAt?: string;
}

export interface FoodItem {
  id: string;
  foodName: string;
  servingSize: string; // e.g., "1 cup (200g)", "1 bowl", "1 slice"
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
  fiber: number;
  category?: string;
  isCustom?: boolean;
}

export interface CalorieDailySummary {
  date: string;
  totalCalories: number;
  calorieGoal: number;
  remainingCalories: number;
  progressPercentage: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  breakfastCalories: number;
  lunchCalories: number;
  snacksCalories: number;
  dinnerCalories: number;
}

