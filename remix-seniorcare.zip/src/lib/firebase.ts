import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  signInAnonymously,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  Auth,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  getDocFromServer,
  Firestore,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { User, UserRole, Language } from '../types';

let app: FirebaseApp;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

export const auth: Auth = getAuth(app);
export const firestore: Firestore = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Connection test per skill directive
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(firestore, 'test', 'connection'));
    console.log('Firestore connection verified successfully.');
    return true;
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firestore client is offline. Verify network/firebase config.');
    } else {
      console.log('Firestore initialized with project:', firebaseConfig.projectId);
    }
    return false;
  }
}

// Test connection on boot
testFirestoreConnection();

/**
 * Synchronize user profile into Firestore database for persistent authentication
 */
export async function saveUserToFirestore(user: User): Promise<void> {
  try {
    const userDocRef = doc(firestore, 'users', user.id);
    await setDoc(
      userDocRef,
      {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone || '',
        role: user.role,
        status: user.status || 'active',
        language: user.language || 'en',
        updatedAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      },
      { merge: true }
    );
    console.log(`User profile ${user.id} synced to Firestore database.`);
  } catch (err) {
    console.warn('Could not sync user to Firestore (continuing locally):', err);
  }
}

/**
 * Fetch user profile from Firestore database
 */
export async function getUserFromFirestore(userId: string): Promise<User | null> {
  try {
    const userDocRef = doc(firestore, 'users', userId);
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      return snap.data() as User;
    }
  } catch (err) {
    console.warn('Could not load user from Firestore:', err);
  }
  return null;
}

/**
 * Authenticate or register user via Firebase Auth + Firestore Database
 */
export async function firebaseAuthenticateUser(params: {
  email: string;
  password?: string;
  name?: string;
  phone?: string;
  role: UserRole;
  language: Language;
}): Promise<User> {
  const { email, role, language } = params;
  const password = params.password || 'SeniorCare@2026';
  const name = params.name || (role === 'senior' ? 'Senior Member' : role === 'family' ? 'Family Member' : role === 'caregiver' ? 'Caregiver Nurse' : 'System Administrator');
  const phone = params.phone || '';

  let firebaseUser: FirebaseUser | null = null;

  // 1. Attempt Firebase Auth Email/Password
  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    firebaseUser = cred.user;
  } catch (signInErr: any) {
    // If user not found, create new Firebase Auth user
    if (signInErr.code === 'auth/user-not-found' || signInErr.code === 'auth/invalid-credential') {
      try {
        const createCred = await createUserWithEmailAndPassword(auth, email, password);
        firebaseUser = createCred.user;
      } catch (createErr: any) {
        // Fallback to anonymous auth if email/password signup fails (e.g. email already exists or auth config)
        try {
          const anonCred = await signInAnonymously(auth);
          firebaseUser = anonCred.user;
        } catch (anonErr) {
          console.warn('Firebase anonymous auth fallback error:', anonErr);
        }
      }
    } else {
      // Fallback to anonymous auth
      try {
        const anonCred = await signInAnonymously(auth);
        firebaseUser = anonCred.user;
      } catch (anonErr) {
        console.warn('Firebase anonymous auth fallback error:', anonErr);
      }
    }
  }

  const userId = firebaseUser?.uid || `user_${role}_${Date.now()}`;

  const resolvedUser: User = {
    id: userId,
    name,
    email,
    phone,
    role,
    status: 'active',
    language,
    profileCompletion: 90,
    createdAt: new Date().toISOString(),
  };

  // 2. Persist in Firestore database
  await saveUserToFirestore(resolvedUser);

  return resolvedUser;
}
