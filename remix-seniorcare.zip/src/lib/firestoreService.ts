import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  Unsubscribe,
} from 'firebase/firestore';
import { firestore } from './firebase';
import {
  Medicine,
  HealthRecord,
  Appointment,
  EmergencyAlert,
  EmergencyInformation,
  EmergencyContact,
  DirectMessage,
  WaterDay,
  User,
  ServiceRequest,
  MedicalDocument,
  FamilyMember,
  WellnessRecord,
  HealthTip,
  AuditLogEntry,
  CalorieRecord,
  FoodItem,
  NotificationItem,
} from '../types';

export function cleanFirestoreData(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map((item) => cleanFirestoreData(item));
  const cleaned: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) {
      cleaned[k] = cleanFirestoreData(v);
    }
  }
  return cleaned;
}

// ============================================================
// 1. MEDICINES CRUD & REAL-TIME
// ============================================================

export function subscribeMedicines(
  userId: string,
  onData: (medicines: Medicine[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'medicines');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: Medicine[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as Medicine;
        list.push({ ...item, id: d.id });
      });
      // Filter by userId if specified or show user medicines
      const userMeds = userId ? list.filter((m) => m.userId === userId || !m.userId) : list;
      onData(userMeds);
    },
    (err) => {
      console.warn('Error subscribing to medicines:', err);
      if (onError) onError(err);
    }
  );
}

export async function addMedicineToFirestore(med: Medicine): Promise<void> {
  const docRef = doc(firestore, 'medicines', med.id);
  const cleaned = cleanFirestoreData({
    ...med,
    createdAt: med.createdAt || new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function updateMedicineInFirestore(id: string, updates: Partial<Medicine>): Promise<void> {
  const docRef = doc(firestore, 'medicines', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

export async function deleteMedicineFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'medicines', id);
  await deleteDoc(docRef);
}

// ============================================================
// 2. HEALTH RECORDS (VITALS) CRUD & REAL-TIME
// ============================================================

export function subscribeHealthRecords(
  userId: string,
  onData: (records: HealthRecord[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'healthRecords');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: HealthRecord[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as HealthRecord;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      const userRecords = userId ? list.filter((r) => r.userId === userId || !r.userId) : list;
      onData(userRecords);
    },
    (err) => {
      console.warn('Error subscribing to health records:', err);
      if (onError) onError(err);
    }
  );
}

export async function addHealthRecordToFirestore(record: HealthRecord): Promise<void> {
  const docRef = doc(firestore, 'healthRecords', record.id);
  const cleaned = cleanFirestoreData({
    ...record,
    createdAt: record.createdAt || new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function deleteHealthRecordFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'healthRecords', id);
  await deleteDoc(docRef);
}

// ============================================================
// 3. APPOINTMENTS CRUD & REAL-TIME
// ============================================================

export function subscribeAppointments(
  userId: string,
  onData: (appointments: Appointment[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'appointments');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: Appointment[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as Appointment;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(a.appointmentDate).getTime() - new Date(b.appointmentDate).getTime());
      const userAppts = userId ? list.filter((a) => a.userId === userId || !a.userId) : list;
      onData(userAppts);
    },
    (err) => {
      console.warn('Error subscribing to appointments:', err);
      if (onError) onError(err);
    }
  );
}

export async function addAppointmentToFirestore(appt: Appointment): Promise<void> {
  const docRef = doc(firestore, 'appointments', appt.id);
  const cleaned = cleanFirestoreData({
    ...appt,
    createdAt: appt.createdAt || new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function updateAppointmentInFirestore(id: string, updates: Partial<Appointment>): Promise<void> {
  const docRef = doc(firestore, 'appointments', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

export async function deleteAppointmentFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'appointments', id);
  await deleteDoc(docRef);
}

// ============================================================
// 4. EMERGENCY ALERTS (SOS) & REAL-TIME DISPATCH
// ============================================================

export function subscribeEmergencyAlerts(
  onData: (alerts: EmergencyAlert[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'emergencyAlerts');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: EmergencyAlert[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as EmergencyAlert;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onData(list);
    },
    (err) => {
      console.warn('Error subscribing to emergency alerts:', err);
      if (onError) onError(err);
    }
  );
}

export async function createEmergencyAlertInFirestore(alert: EmergencyAlert): Promise<void> {
  const docRef = doc(firestore, 'emergencyAlerts', alert.id);
  const cleaned = cleanFirestoreData({
    ...alert,
    createdAt: alert.createdAt || new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function resolveEmergencyAlertInFirestore(id: string, responderNotes?: string): Promise<void> {
  const docRef = doc(firestore, 'emergencyAlerts', id);
  await updateDoc(docRef, {
    status: 'resolved',
    resolvedAt: new Date().toISOString(),
    responderNotes: responderNotes || 'Assisted safely by emergency response unit.',
  });
}

// ============================================================
// 5. DIRECT MESSAGES REAL-TIME CHAT
// ============================================================

export function subscribeMessages(
  userId: string,
  onData: (messages: DirectMessage[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'messages');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: DirectMessage[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as DirectMessage;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      onData(list);
    },
    (err) => {
      console.warn('Error subscribing to messages:', err);
      if (onError) onError(err);
    }
  );
}

export async function sendMessageToFirestore(message: DirectMessage): Promise<void> {
  const docRef = doc(firestore, 'messages', message.id);
  const cleaned = cleanFirestoreData({
    ...message,
    timestamp: message.timestamp || new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

// ============================================================
// 6. WATER TRACKING & HYDRATION
// ============================================================

export async function saveWaterTrackingToFirestore(
  userId: string,
  date: string,
  waterData: WaterDay
): Promise<void> {
  const docId = `${userId}_${date}`;
  const docRef = doc(firestore, 'waterTracking', docId);
  const cleaned = cleanFirestoreData({
    userId,
    date,
    consumedMl: waterData.consumedMl,
    glasses: waterData.glasses,
    targetMl: waterData.targetMl,
    updatedAt: new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function getWaterTrackingFromFirestore(userId: string, date: string): Promise<WaterDay | null> {
  try {
    const docId = `${userId}_${date}`;
    const docRef = doc(firestore, 'waterTracking', docId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const d = snap.data();
      return {
        date: d.date,
        consumedMl: d.consumedMl,
        glasses: d.glasses,
        targetMl: d.targetMl,
      };
    }
  } catch (err) {
    console.warn('Failed to get water tracking from Firestore:', err);
  }
  return null;
}

// ============================================================
// 7. EMERGENCY INFORMATION
// ============================================================

export function subscribeEmergencyInfo(
  userId: string,
  onData: (info: EmergencyInformation) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const docRef = doc(firestore, 'emergencyInfo', userId);
  return onSnapshot(
    docRef,
    (snapshot) => {
      if (snapshot.exists()) {
        onData(snapshot.data() as EmergencyInformation);
      }
    },
    (err) => {
      console.warn('Error subscribing to emergency info:', err);
      if (onError) onError(err);
    }
  );
}

export async function saveEmergencyInfoToFirestore(info: EmergencyInformation): Promise<void> {
  const docRef = doc(firestore, 'emergencyInfo', info.userId);
  const cleaned = cleanFirestoreData({
    ...info,
    updatedAt: new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function getEmergencyInfoFromFirestore(userId: string): Promise<EmergencyInformation | null> {
  try {
    const docRef = doc(firestore, 'emergencyInfo', userId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as EmergencyInformation;
    }
  } catch (err) {
    console.warn('Failed to load emergency info from Firestore:', err);
  }
  return null;
}

// ============================================================
// 8. EMERGENCY CONTACTS CRUD & REAL-TIME
// ============================================================

export function subscribeEmergencyContacts(
  userId: string,
  onData: (contacts: EmergencyContact[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'emergencyContacts');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: EmergencyContact[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as EmergencyContact;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => (a.priority || 1) - (b.priority || 1));
      const userContacts = userId ? list.filter((c) => c.userId === userId || !c.userId) : list;
      onData(userContacts);
    },
    (err) => {
      console.warn('Error subscribing to emergency contacts:', err);
      if (onError) onError(err);
    }
  );
}

export async function addEmergencyContactToFirestore(contact: EmergencyContact): Promise<void> {
  const docRef = doc(firestore, 'emergencyContacts', contact.id);
  const cleaned = cleanFirestoreData(contact);
  await setDoc(docRef, cleaned);
}

export async function updateEmergencyContactInFirestore(id: string, updates: Partial<EmergencyContact>): Promise<void> {
  const docRef = doc(firestore, 'emergencyContacts', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

export async function deleteEmergencyContactFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'emergencyContacts', id);
  await deleteDoc(docRef);
}

// ============================================================
// 9. MEDICAL DOCUMENTS CRUD & REAL-TIME
// ============================================================

export function subscribeMedicalDocuments(
  seniorId: string,
  onData: (docs: MedicalDocument[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'medicalDocuments');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: MedicalDocument[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as MedicalDocument;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
      const filtered = seniorId ? list.filter((d) => !d.seniorId || d.seniorId === seniorId) : list;
      onData(filtered);
    },
    (err) => {
      console.warn('Error subscribing to medical documents:', err);
      if (onError) onError(err);
    }
  );
}

export async function addMedicalDocumentToFirestore(medDoc: MedicalDocument): Promise<void> {
  const docRef = doc(firestore, 'medicalDocuments', medDoc.id);
  const cleaned = cleanFirestoreData(medDoc);
  await setDoc(docRef, cleaned);
}

export async function deleteMedicalDocumentFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'medicalDocuments', id);
  await deleteDoc(docRef);
}

// ============================================================
// 10. ELDERCARE SERVICE REQUESTS CRUD & REAL-TIME
// ============================================================

export function subscribeServiceRequests(
  seniorId: string,
  onData: (services: ServiceRequest[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'serviceRequests');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: ServiceRequest[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as ServiceRequest;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      const filtered = seniorId ? list.filter((s) => !s.seniorId || s.seniorId === seniorId) : list;
      onData(filtered);
    },
    (err) => {
      console.warn('Error subscribing to service requests:', err);
      if (onError) onError(err);
    }
  );
}

export async function addServiceRequestToFirestore(request: ServiceRequest): Promise<void> {
  const docRef = doc(firestore, 'serviceRequests', request.id);
  const cleaned = cleanFirestoreData(request);
  await setDoc(docRef, cleaned);
}

export async function updateServiceRequestInFirestore(id: string, updates: Partial<ServiceRequest>): Promise<void> {
  const docRef = doc(firestore, 'serviceRequests', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

// ============================================================
// 11. FAMILY MEMBERS & PERMISSIONS CRUD & REAL-TIME
// ============================================================

export function subscribeFamilyMembers(
  seniorId: string,
  onData: (members: FamilyMember[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'familyMembers');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: FamilyMember[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as FamilyMember;
        list.push({ ...item, id: d.id });
      });
      const filtered = seniorId ? list.filter((f) => f.seniorId === seniorId) : list;
      onData(filtered);
    },
    (err) => {
      console.warn('Error subscribing to family members:', err);
      if (onError) onError(err);
    }
  );
}

export async function addFamilyMemberToFirestore(member: FamilyMember): Promise<void> {
  const docRef = doc(firestore, 'familyMembers', member.id);
  const cleaned = cleanFirestoreData(member);
  await setDoc(docRef, cleaned);
}

export async function updateFamilyMemberInFirestore(id: string, updates: Partial<FamilyMember>): Promise<void> {
  const docRef = doc(firestore, 'familyMembers', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

export async function deleteFamilyMemberFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'familyMembers', id);
  await deleteDoc(docRef);
}

// ============================================================
// 12. WELLNESS RECORDS
// ============================================================

export function subscribeWellnessRecords(
  userId: string,
  onData: (records: WellnessRecord[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'wellness');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: WellnessRecord[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as WellnessRecord;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      const filtered = userId ? list.filter((w) => w.userId === userId) : list;
      onData(filtered);
    },
    (err) => {
      console.warn('Error subscribing to wellness:', err);
      if (onError) onError(err);
    }
  );
}

export async function saveWellnessRecordToFirestore(record: WellnessRecord): Promise<void> {
  const docRef = doc(firestore, 'wellness', record.id);
  const cleaned = cleanFirestoreData(record);
  await setDoc(docRef, cleaned);
}

// ============================================================
// 13. HEALTH TIPS
// ============================================================

export function subscribeHealthTips(
  onData: (tips: HealthTip[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'healthTips');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: HealthTip[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as HealthTip;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onData(list);
    },
    (err) => {
      console.warn('Error subscribing to health tips:', err);
      if (onError) onError(err);
    }
  );
}

export async function addHealthTipToFirestore(tip: HealthTip): Promise<void> {
  const docRef = doc(firestore, 'healthTips', tip.id);
  const cleaned = cleanFirestoreData(tip);
  await setDoc(docRef, cleaned);
}

export async function deleteHealthTipFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'healthTips', id);
  await deleteDoc(docRef);
}

// ============================================================
// 14. AUDIT LOGS
// ============================================================

export async function addAuditLogToFirestore(entry: AuditLogEntry): Promise<void> {
  const docRef = doc(firestore, 'auditLogs', entry.id);
  const cleaned = cleanFirestoreData(entry);
  await setDoc(docRef, cleaned);
}

// ============================================================
// 15. CALORIE RECORDS CRUD & REAL-TIME
// ============================================================

export function subscribeCalorieRecords(
  userId: string,
  onData: (records: CalorieRecord[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'calorieRecords');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: CalorieRecord[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as CalorieRecord;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.createdAt || b.date).getTime() - new Date(a.createdAt || a.date).getTime());
      const userRecords = userId ? list.filter((r) => r.userId === userId || !r.userId) : list;
      onData(userRecords);
    },
    (err) => {
      console.warn('Error subscribing to calorie records:', err);
      if (onError) onError(err);
    }
  );
}

export async function addCalorieRecordToFirestore(record: CalorieRecord): Promise<void> {
  const docRef = doc(firestore, 'calorieRecords', record.id);
  const cleaned = cleanFirestoreData({
    ...record,
    createdAt: record.createdAt || new Date().toISOString(),
  });
  await setDoc(docRef, cleaned);
}

export async function updateCalorieRecordInFirestore(id: string, updates: Partial<CalorieRecord>): Promise<void> {
  const docRef = doc(firestore, 'calorieRecords', id);
  const cleaned = cleanFirestoreData({
    ...updates,
    updatedAt: new Date().toISOString(),
  });
  await updateDoc(docRef, cleaned);
}

export async function deleteCalorieRecordFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'calorieRecords', id);
  await deleteDoc(docRef);
}

// ============================================================
// 16. FOOD DATABASE CRUD & REAL-TIME
// ============================================================

export function subscribeFoods(
  onData: (foods: FoodItem[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'foods');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: FoodItem[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as FoodItem;
        list.push({ ...item, id: d.id });
      });
      onData(list);
    },
    (err) => {
      console.warn('Error subscribing to foods:', err);
      if (onError) onError(err);
    }
  );
}

export async function addFoodToFirestore(food: FoodItem): Promise<void> {
  const docRef = doc(firestore, 'foods', food.id);
  const cleaned = cleanFirestoreData(food);
  await setDoc(docRef, cleaned);
}

export async function updateFoodInFirestore(id: string, updates: Partial<FoodItem>): Promise<void> {
  const docRef = doc(firestore, 'foods', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

export async function deleteFoodFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'foods', id);
  await deleteDoc(docRef);
}

export async function saveUserCalorieProfileToFirestore(
  userId: string,
  profile: {
    age?: number;
    gender?: string;
    height?: number;
    weight?: number;
    activityLevel?: 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active';
    dailyCalorieGoal?: number;
  }
): Promise<void> {
  const docRef = doc(firestore, 'users', userId);
  const cleaned = cleanFirestoreData({
    ...profile,
    updatedAt: new Date().toISOString(),
  });
  await updateDoc(docRef, cleaned);
}

// ============================================================
// 17. NOTIFICATIONS CRUD & REAL-TIME
// ============================================================

export function subscribeNotifications(
  userId: string,
  onData: (notifications: NotificationItem[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(firestore, 'notifications');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: NotificationItem[] = [];
      snapshot.forEach((d) => {
        const item = d.data() as NotificationItem;
        list.push({ ...item, id: d.id });
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      const filtered = userId ? list.filter((n) => !n.userId || n.userId === userId) : list;
      onData(filtered);
    },
    (err) => {
      console.warn('subscribeNotifications error:', err.message);
      if (onError) onError(err);
    }
  );
}

export async function addNotificationToFirestore(notification: NotificationItem): Promise<void> {
  const docRef = doc(firestore, 'notifications', notification.id);
  const cleaned = cleanFirestoreData(notification);
  await setDoc(docRef, cleaned);
}

export async function updateNotificationInFirestore(
  id: string,
  updates: Partial<NotificationItem>
): Promise<void> {
  const docRef = doc(firestore, 'notifications', id);
  const cleaned = cleanFirestoreData(updates);
  await updateDoc(docRef, cleaned);
}

export async function deleteNotificationFromFirestore(id: string): Promise<void> {
  const docRef = doc(firestore, 'notifications', id);
  await deleteDoc(docRef);
}

// ============================================================
// 18. INITIAL SEEDING HELPER
// Checks if collections are populated; if not, seeds them with rich defaults
// ============================================================

export async function seedFirestoreIfEmpty(seedData: {
  users?: User[];
  medicines?: Medicine[];
  healthRecords?: HealthRecord[];
  appointments?: Appointment[];
  emergencyInfo?: Record<string, EmergencyInformation>;
  emergencyContacts?: EmergencyContact[];
  serviceRequests?: ServiceRequest[];
  medicalDocuments?: MedicalDocument[];
  familyMembers?: FamilyMember[];
  healthTips?: HealthTip[];
}): Promise<void> {
  try {
    // Check if medicines collection has docs
    const medsSnap = await getDocs(collection(firestore, 'medicines'));
    if (medsSnap.empty && seedData.medicines && seedData.medicines.length > 0) {
      console.log('Seeding medicines to Firestore...');
      for (const m of seedData.medicines) {
        await setDoc(doc(firestore, 'medicines', m.id), cleanFirestoreData(m));
      }
    }

    // Check if healthRecords collection has docs
    const recordsSnap = await getDocs(collection(firestore, 'healthRecords'));
    if (recordsSnap.empty && seedData.healthRecords && seedData.healthRecords.length > 0) {
      console.log('Seeding healthRecords to Firestore...');
      for (const r of seedData.healthRecords) {
        await setDoc(doc(firestore, 'healthRecords', r.id), cleanFirestoreData(r));
      }
    }

    // Check if appointments collection has docs
    const apptsSnap = await getDocs(collection(firestore, 'appointments'));
    if (apptsSnap.empty && seedData.appointments && seedData.appointments.length > 0) {
      console.log('Seeding appointments to Firestore...');
      for (const a of seedData.appointments) {
        await setDoc(doc(firestore, 'appointments', a.id), cleanFirestoreData(a));
      }
    }

    // Check users
    if (seedData.users) {
      for (const u of seedData.users) {
        const uDoc = await getDoc(doc(firestore, 'users', u.id));
        if (!uDoc.exists()) {
          await setDoc(doc(firestore, 'users', u.id), cleanFirestoreData(u));
        }
      }
    }

    // Check emergency info
    if (seedData.emergencyInfo) {
      for (const [uid, info] of Object.entries(seedData.emergencyInfo)) {
        const eDoc = await getDoc(doc(firestore, 'emergencyInfo', uid));
        if (!eDoc.exists()) {
          await setDoc(doc(firestore, 'emergencyInfo', uid), cleanFirestoreData(info));
        }
      }
    }

    // Check emergency contacts
    if (seedData.emergencyContacts) {
      const cSnap = await getDocs(collection(firestore, 'emergencyContacts'));
      if (cSnap.empty) {
        for (const c of seedData.emergencyContacts) {
          await setDoc(doc(firestore, 'emergencyContacts', c.id), cleanFirestoreData(c));
        }
      }
    }

    // Check service requests
    if (seedData.serviceRequests) {
      const sSnap = await getDocs(collection(firestore, 'serviceRequests'));
      if (sSnap.empty) {
        for (const s of seedData.serviceRequests) {
          await setDoc(doc(firestore, 'serviceRequests', s.id), cleanFirestoreData(s));
        }
      }
    }

    // Check medical documents
    if (seedData.medicalDocuments) {
      const dSnap = await getDocs(collection(firestore, 'medicalDocuments'));
      if (dSnap.empty) {
        for (const d of seedData.medicalDocuments) {
          await setDoc(doc(firestore, 'medicalDocuments', d.id), cleanFirestoreData(d));
        }
      }
    }

    // Check family members
    if (seedData.familyMembers) {
      const fSnap = await getDocs(collection(firestore, 'familyMembers'));
      if (fSnap.empty) {
        for (const f of seedData.familyMembers) {
          await setDoc(doc(firestore, 'familyMembers', f.id), cleanFirestoreData(f));
        }
      }
    }

    // Check health tips
    if (seedData.healthTips) {
      const tSnap = await getDocs(collection(firestore, 'healthTips'));
      if (tSnap.empty) {
        for (const t of seedData.healthTips) {
          await setDoc(doc(firestore, 'healthTips', t.id), cleanFirestoreData(t));
        }
      }
    }
  } catch (err) {
    console.warn('Firestore seeding check encountered:', err);
  }
}
