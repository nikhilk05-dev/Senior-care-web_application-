import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { EmergencyModal } from './components/EmergencyModal';
import { DashboardView } from './components/senior/DashboardView';
import { MedicineView } from './components/senior/MedicineView';
import { HealthRecordsView } from './components/senior/HealthRecordsView';
import { WaterTrackerView } from './components/senior/WaterTrackerView';
import { WellnessView } from './components/senior/WellnessView';
import { AppointmentsView } from './components/senior/AppointmentsView';
import { FamilyConnectView } from './components/senior/FamilyConnectView';
import { HealthAssistantView } from './components/senior/HealthAssistantView';
import { AiStudioView } from './components/senior/AiStudioView';
import { HealthTipsView } from './components/senior/HealthTipsView';
import { ProfileView } from './components/senior/ProfileView';
import { MedicalVaultView } from './components/senior/MedicalVaultView';
import { ChatView } from './components/senior/ChatView';
import { FamilyDashboardView } from './components/family/FamilyDashboardView';
import { CaregiverDashboardView } from './components/caregiver/CaregiverDashboardView';
import { AdminDashboardView } from './components/admin/AdminDashboardView';
import { AdminUsersView } from './components/admin/AdminUsersView';
import { AdminTipsView } from './components/admin/AdminTipsView';
import { AdminReportsView } from './components/admin/AdminReportsView';
import { AdminLogsView } from './components/admin/AdminLogsView';
import { AdminAnalyticsView } from './components/admin/AdminAnalyticsView';
import { AdminFoodsView } from './components/admin/AdminFoodsView';
import { CalorieCounterView } from './components/senior/CalorieCounterView';
import { LoginPage } from './components/LoginPage';
import { CalendarView } from './components/CalendarView';
import { NotificationsView } from './components/NotificationsView';
import {
  User,
  Language,
  Medicine,
  HealthRecord,
  Appointment,
  WaterDay,
  WellnessRecord,
  HealthTip,
  EmergencyContact,
  EmergencyInformation,
  FamilyMember,
  NotificationItem,
  MedicalDocument,
  ServiceRequest,
  EmergencyAlert,
  DirectMessage,
  CalorieRecord,
  FoodItem,
} from './types';
import { t } from './i18n';
import {
  subscribeMedicines,
  subscribeHealthRecords,
  subscribeAppointments,
  subscribeEmergencyAlerts,
  subscribeMessages,
  subscribeEmergencyContacts,
  subscribeEmergencyInfo,
  subscribeMedicalDocuments,
  subscribeServiceRequests,
  subscribeFamilyMembers,
  subscribeWellnessRecords,
  subscribeHealthTips,
  subscribeNotifications,
  addNotificationToFirestore,
  updateNotificationInFirestore,
  deleteNotificationFromFirestore,
  addMedicineToFirestore,
  updateMedicineInFirestore,
  deleteMedicineFromFirestore,
  addHealthRecordToFirestore,
  deleteHealthRecordFromFirestore,
  addAppointmentToFirestore,
  updateAppointmentInFirestore,
  deleteAppointmentFromFirestore,
  createEmergencyAlertInFirestore,
  sendMessageToFirestore,
  saveWaterTrackingToFirestore,
  saveEmergencyInfoToFirestore,
  addEmergencyContactToFirestore,
  updateEmergencyContactInFirestore,
  deleteEmergencyContactFromFirestore,
  addMedicalDocumentToFirestore,
  deleteMedicalDocumentFromFirestore,
  addServiceRequestToFirestore,
  updateServiceRequestInFirestore,
  addFamilyMemberToFirestore,
  updateFamilyMemberInFirestore,
  deleteFamilyMemberFromFirestore,
  saveWellnessRecordToFirestore,
  addHealthTipToFirestore,
  deleteHealthTipFromFirestore,
  subscribeCalorieRecords,
  addCalorieRecordToFirestore,
  updateCalorieRecordInFirestore,
  deleteCalorieRecordFromFirestore,
  subscribeFoods,
  addFoodToFirestore,
  updateFoodInFirestore,
  deleteFoodFromFirestore,
  saveUserCalorieProfileToFirestore,
} from './lib/firestoreService';
import { saveUserToFirestore } from './lib/firebase';

export default function App() {
  // Current user state (reads from localStorage or initializes clean profile)
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('seniorcare_active_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.name && !parsed.name.includes('Ramesh Patel')) {
          return parsed;
        }
      }
    } catch (e) {
      // ignore
    }
    return {
      id: 'user_senior_1',
      name: 'Senior Member',
      email: 'senior@seniorcare.org',
      phone: '+91 98765 43210',
      role: 'senior',
      status: 'active',
      profileCompletion: 95,
      age: 68,
      bloodGroup: 'B+',
      language: 'en',
      fontSize: 'large',
      accountStatus: 'active',
      createdAt: '2026-01-15T10:00:00Z',
    };
  });

  const [currentLanguage, setCurrentLanguage] = useState<Language>(() => {
    try {
      const savedLang = localStorage.getItem('seniorcare_language');
      if (savedLang === 'en' || savedLang === 'hi' || savedLang === 'mr') {
        return savedLang;
      }
      const savedUser = localStorage.getItem('seniorcare_active_user');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        if (parsed?.language === 'en' || parsed?.language === 'hi' || parsed?.language === 'mr') {
          return parsed.language;
        }
      }
    } catch {
      // ignore
    }
    return 'en';
  });

  // Centralized Language Handler to guarantee 100% persistence & sync across applet
  const handleLanguageChange = (lang: Language) => {
    setCurrentLanguage(lang);
    try {
      localStorage.setItem('seniorcare_language', lang);
      document.documentElement.lang = lang;
    } catch {
      // ignore
    }
    if (user) {
      const updatedUser: User = { ...user, language: lang };
      setUser(updatedUser);
      try {
        localStorage.setItem('seniorcare_active_user', JSON.stringify(updatedUser));
        const raw = localStorage.getItem('seniorcare_saved_role_sessions');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed[user.role]) {
            parsed[user.role].language = lang;
            localStorage.setItem('seniorcare_saved_role_sessions', JSON.stringify(parsed));
          }
        }
      } catch {
        // ignore
      }
      saveUserToFirestore(updatedUser).catch((err) =>
        console.warn('[Firestore] Language preference save notice:', err?.message || err)
      );
    }
  };

  useEffect(() => {
    try {
      document.documentElement.lang = currentLanguage;
    } catch {}
  }, [currentLanguage]);

  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>(() => {
    try {
      const saved = localStorage.getItem('seniorcare_font_size');
      if (saved === 'normal' || saved === 'large' || saved === 'xlarge') {
        return saved;
      }
    } catch {
      // ignore
    }
    return 'large';
  });
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isLoginPage, setIsLoginPage] = useState<boolean>(false);

  // Centralized Text Legibility & Font Size Handler
  const handleFontSizeChange = (size: 'normal' | 'large' | 'xlarge') => {
    setFontSize(size);
    try {
      localStorage.setItem('seniorcare_font_size', size);
    } catch {
      // ignore
    }
    if (user) {
      const updatedUser: User = { ...user, fontSize: size };
      setUser(updatedUser);
      try {
        localStorage.setItem('seniorcare_active_user', JSON.stringify(updatedUser));
      } catch {
        // ignore
      }
      saveUserToFirestore(updatedUser).catch((err) =>
        console.warn('[Firestore] Font size preference save notice:', err?.message || err)
      );
    }
  };

  // Modals
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);

  // App Data States
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [healthRecords, setHealthRecords] = useState<HealthRecord[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [waterToday, setWaterToday] = useState<WaterDay>({
    date: new Date().toISOString().split('T')[0],
    glasses: 5,
    consumedMl: 1250,
    targetMl: 2000,
  });
  const [waterHistory, setWaterHistory] = useState<WaterDay[]>([]);
  const [wellness, setWellness] = useState<WellnessRecord | null>(null);
  const [dailyTip, setDailyTip] = useState<HealthTip | null>(null);
  const [tips, setTips] = useState<HealthTip[]>([]);
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([]);
  const [emergencyInfo, setEmergencyInfo] = useState<EmergencyInformation | null>(null);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [medicalDocuments, setMedicalDocuments] = useState<MedicalDocument[]>([]);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  const [emergencyAlerts, setEmergencyAlerts] = useState<EmergencyAlert[]>([]);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [calorieRecords, setCalorieRecords] = useState<CalorieRecord[]>([]);
  const [foods, setFoods] = useState<FoodItem[]>([]);
  const [isDataLoading, setIsDataLoading] = useState<boolean>(true);
  const [firestoreError, setFirestoreError] = useState<string | null>(null);

  // Apply font size class, style, and attribute to document root for real-time text scaling
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove(
      'font-normal',
      'font-large',
      'font-xlarge',
      'text-size-normal',
      'text-size-large',
      'text-size-xlarge'
    );
    root.setAttribute('data-font-size', fontSize);

    if (fontSize === 'large') {
      root.style.fontSize = '18px';
      root.classList.add('text-size-large', 'font-large');
    } else if (fontSize === 'xlarge') {
      root.style.fontSize = '20px';
      root.classList.add('text-size-xlarge', 'font-xlarge');
    } else {
      root.style.fontSize = '16px';
      root.classList.add('text-size-normal');
    }
  }, [fontSize]);

  // Fetch initial data from backend
  const fetchData = async () => {
    setIsDataLoading(true);
    setFirestoreError(null);
    try {
      const headers = { 'x-user-id': user?.id || 'user_senior_1' };

      const safeFetchJson = async (url: string) => {
        try {
          const res = await fetch(url, { headers });
          if (!res.ok) return null;
          const text = await res.text();
          return JSON.parse(text);
        } catch (err) {
          console.warn(`Failed to fetch JSON from ${url}:`, err);
          return null;
        }
      };

      const [
        medsRes,
        recordsRes,
        apptsRes,
        waterRes,
        waterHistoryRes,
        wellnessRes,
        dailyTipRes,
        tipsRes,
        contactsRes,
        infoRes,
        familyRes,
        docsRes,
        servicesRes,
        alertsRes,
        messagesRes,
        calorieRes,
        foodsRes,
        notifsRes,
      ] = await Promise.all([
        safeFetchJson('/api/medicines'),
        safeFetchJson('/api/health-records'),
        safeFetchJson('/api/appointments'),
        safeFetchJson('/api/water/today'),
        safeFetchJson('/api/water/history'),
        safeFetchJson('/api/wellness/today'),
        safeFetchJson('/api/tips/daily'),
        safeFetchJson('/api/tips'),
        safeFetchJson('/api/emergency/contacts'),
        safeFetchJson('/api/emergency/info'),
        safeFetchJson('/api/family'),
        safeFetchJson('/api/documents'),
        safeFetchJson('/api/services'),
        safeFetchJson('/api/emergency/alerts'),
        safeFetchJson('/api/messages'),
        safeFetchJson('/api/calorie-records'),
        safeFetchJson('/api/foods'),
        safeFetchJson('/api/notifications'),
      ]);

      const meds = medsRes?.medicines || medsRes?.data;
      if (Array.isArray(meds)) setMedicines(meds);

      const records = recordsRes?.records || recordsRes?.data;
      if (Array.isArray(records)) setHealthRecords(records);

      const appts = apptsRes?.appointments || apptsRes?.data;
      if (Array.isArray(appts)) setAppointments(appts);

      const water = waterRes?.water || waterRes?.data;
      if (water) setWaterToday(water);

      const hist = waterHistoryRes?.data || waterHistoryRes?.history;
      if (Array.isArray(hist)) setWaterHistory(hist);

      const well = wellnessRes?.wellness || wellnessRes?.data;
      if (well) setWellness(well);

      const dailyTip = dailyTipRes?.tip || dailyTipRes?.data;
      if (dailyTip) setDailyTip(dailyTip);

      const tips = tipsRes?.tips || tipsRes?.data;
      if (Array.isArray(tips)) setTips(tips);

      const contacts = contactsRes?.contacts || contactsRes?.data;
      if (Array.isArray(contacts)) setEmergencyContacts(contacts);

      const info = infoRes?.info || infoRes?.data;
      if (info) setEmergencyInfo(info);

      const family = familyRes?.familyMembers || familyRes?.data;
      if (Array.isArray(family)) setFamilyMembers(family);

      const docs = docsRes?.documents || docsRes?.data;
      if (Array.isArray(docs)) setMedicalDocuments(docs);

      const services = servicesRes?.services || servicesRes?.data;
      if (Array.isArray(services)) setServiceRequests(services);

      const alerts = alertsRes?.alerts || alertsRes?.data;
      if (Array.isArray(alerts)) setEmergencyAlerts(alerts);

      const msgs = messagesRes?.messages || messagesRes?.data;
      if (Array.isArray(msgs)) setMessages(msgs);

      const calories = calorieRes?.records || calorieRes?.data;
      if (Array.isArray(calories)) setCalorieRecords(calories);

      const foodList = foodsRes?.foods || foodsRes?.data;
      if (Array.isArray(foodList)) setFoods(foodList);

      const notifList = notifsRes?.notifications || notifsRes?.data;
      if (Array.isArray(notifList) && notifList.length > 0) {
        setNotifications(notifList);
      } else {
        setNotifications([
          {
            id: 'notif-1',
            userId: user?.id || 'user_senior_1',
            title: 'Medicine Due Soon: Shelcal 500',
            message: 'Shelcal 500 (Calcium) is due at 01:30 PM after lunch.',
            type: 'medicine',
            isRead: false,
            createdAt: new Date().toISOString(),
          },
          {
            id: 'notif-2',
            userId: user?.id || 'user_senior_1',
            title: 'Daily Hydration Reminder',
            message: 'Time for a fresh glass of warm water to support circulation.',
            type: 'water',
            isRead: false,
            createdAt: new Date().toISOString(),
          },
          {
            id: 'notif-3',
            userId: user?.id || 'user_senior_1',
            title: 'Cardiology Appointment Coming Up',
            message: 'Dr. A. K. Joshi (Cardiology) on March 25, 2026 at 10:30 AM.',
            type: 'appointment',
            isRead: true,
            createdAt: new Date(Date.now() - 3600000).toISOString(),
          },
        ]);
      }
    } catch (e: any) {
      console.error('Initial data fetch error:', e);
      setFirestoreError(e?.message || 'Could not load data from Firestore database.');
    } finally {
      setIsDataLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const activeUserId = user?.id || 'user_senior_1';

    // Real-time Firestore synchronization listeners across all collections
    const unsubMeds = subscribeMedicines(activeUserId, (liveMeds) => {
      if (liveMeds && liveMeds.length > 0) {
        setMedicines(liveMeds);
      }
    });

    const unsubRecords = subscribeHealthRecords(activeUserId, (liveRecords) => {
      if (liveRecords && liveRecords.length > 0) {
        setHealthRecords(liveRecords);
      }
    });

    const unsubAppts = subscribeAppointments(activeUserId, (liveAppts) => {
      if (liveAppts && liveAppts.length > 0) {
        setAppointments(liveAppts);
      }
    });

    const unsubAlerts = subscribeEmergencyAlerts((liveAlerts) => {
      if (liveAlerts && liveAlerts.length > 0) {
        setEmergencyAlerts(liveAlerts);
      }
    });

    const unsubMessages = subscribeMessages(activeUserId, (liveMsgs) => {
      if (liveMsgs && liveMsgs.length > 0) {
        setMessages(liveMsgs);
      }
    });

    const unsubContacts = subscribeEmergencyContacts(activeUserId, (liveContacts) => {
      if (liveContacts && liveContacts.length > 0) {
        setEmergencyContacts(liveContacts);
      }
    });

    const unsubDocs = subscribeMedicalDocuments(activeUserId, (liveDocs) => {
      if (liveDocs && liveDocs.length > 0) {
        setMedicalDocuments(liveDocs);
      }
    });

    const unsubServices = subscribeServiceRequests(activeUserId, (liveServices) => {
      if (liveServices && liveServices.length > 0) {
        setServiceRequests(liveServices);
      }
    });

    const unsubFamily = subscribeFamilyMembers(activeUserId, (liveFamily) => {
      if (liveFamily && liveFamily.length > 0) {
        setFamilyMembers(liveFamily);
      }
    });

    const unsubInfo = subscribeEmergencyInfo(activeUserId, (liveInfo) => {
      if (liveInfo) {
        setEmergencyInfo(liveInfo);
      }
    });

    const unsubWellness = subscribeWellnessRecords(activeUserId, (liveWellness) => {
      if (liveWellness && liveWellness.length > 0) {
        setWellness(liveWellness[0]);
      }
    });

    const unsubCal = subscribeCalorieRecords(activeUserId, (liveCal) => {
      if (liveCal && liveCal.length > 0) {
        setCalorieRecords(liveCal);
      }
    });

    const unsubFoods = subscribeFoods((liveFoods) => {
      if (liveFoods && liveFoods.length > 0) {
        setFoods(liveFoods);
      }
    });

    const unsubNotifs = subscribeNotifications(activeUserId, (liveNotifs) => {
      if (liveNotifs && liveNotifs.length > 0) {
        setNotifications(liveNotifs);
      }
    });

    return () => {
      unsubMeds();
      unsubRecords();
      unsubAppts();
      unsubAlerts();
      unsubMessages();
      unsubContacts();
      unsubDocs();
      unsubServices();
      unsubFamily();
      unsubInfo();
      unsubWellness();
      unsubCal();
      unsubFoods();
      unsubNotifs();
    };
  }, [user]);

  // Care Role Switcher: Preserves and restores past saved role sessions for each role
  const handleSwitchDemoRole = (targetRole: 'senior' | 'family' | 'caregiver' | 'admin') => {
    let savedSession: any = null;
    try {
      const raw = localStorage.getItem('seniorcare_saved_role_sessions');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed[targetRole]) {
          savedSession = parsed[targetRole];
        }
      }
    } catch (e) {}

    let newRoleUser: User;

    if (targetRole === 'senior') {
      newRoleUser = {
        id: 'user_senior_1',
        name: savedSession?.name || 'Senior Member',
        email: savedSession?.email || 'senior@seniorcare.org',
        phone: savedSession?.phone || '+91 98765 43210',
        role: 'senior',
        status: 'active',
        profileCompletion: 95,
        age: 68,
        bloodGroup: 'B+',
        language: currentLanguage,
        fontSize: fontSize,
        accountStatus: 'active',
        createdAt: '2026-01-15T10:00:00Z',
      };
      setActiveTab('dashboard');
    } else if (targetRole === 'family') {
      newRoleUser = {
        id: 'user_family_1',
        name: savedSession?.name || 'Family Member',
        email: savedSession?.email || 'family@seniorcare.org',
        phone: savedSession?.phone || '+91 98765 11223',
        role: 'family',
        status: 'active',
        profileCompletion: 100,
        language: currentLanguage,
        fontSize: 'normal',
        accountStatus: 'active',
        createdAt: '2026-01-16T11:30:00Z',
      };
      setActiveTab('familyDashboard');
    } else if (targetRole === 'caregiver') {
      newRoleUser = {
        id: 'user_caregiver_1',
        name: savedSession?.name || 'Caregiver Nurse',
        email: savedSession?.email || 'caregiver@seniorcare.org',
        phone: savedSession?.phone || '+91 98333 44556',
        role: 'caregiver',
        status: 'active',
        profileCompletion: 100,
        language: currentLanguage,
        fontSize: 'normal',
        accountStatus: 'active',
        createdAt: '2026-01-16T11:30:00Z',
      };
      setActiveTab('caregiverDashboard');
    } else {
      newRoleUser = {
        id: 'user_admin_1',
        name: savedSession?.name || 'System Administrator',
        email: savedSession?.email || 'admin@seniorcare.org',
        phone: savedSession?.phone || '+91 98111 22334',
        role: 'admin',
        status: 'active',
        profileCompletion: 100,
        language: currentLanguage,
        fontSize: 'normal',
        accountStatus: 'active',
        createdAt: '2026-01-01T08:00:00Z',
      };
      setActiveTab('adminDashboard');
    }

    setUser(newRoleUser);
    try {
      localStorage.setItem('seniorcare_active_user', JSON.stringify(newRoleUser));
      const raw = localStorage.getItem('seniorcare_saved_role_sessions');
      const parsed = raw ? JSON.parse(raw) : {};
      parsed[targetRole] = {
        role: targetRole,
        name: newRoleUser.name,
        email: newRoleUser.email,
        phone: newRoleUser.phone,
        lastLoginAt: new Date().toISOString(),
      };
      localStorage.setItem('seniorcare_saved_role_sessions', JSON.stringify(parsed));
    } catch (e) {}
    setIsLoginPage(false);
  };

  // Medicine Actions
  const handleTakeDose = async (medId: string) => {
    try {
      setMedicines((prev) =>
        prev.map((m) => {
          if (m.id === medId) {
            const updatedSchedules = (m.schedules || []).map((s) =>
              s.status === 'due' || s.status === 'upcoming'
                ? { ...s, status: 'taken' as const, takenAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
                : s
            );
            const updated = {
              ...m,
              schedules: updatedSchedules,
              quantityRemaining: Math.max(0, (m.quantityRemaining || 1) - 1),
            };
            updateMedicineInFirestore(medId, updated).catch((err) => console.warn('Firestore update:', err));
            return updated;
          }
          return m;
        })
      );

      const res = await fetch(`/api/medicines/${medId}/take`, {
        method: 'POST',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      const data = await res.json();
      const med = data.medicine || data.data;
      if (med) {
        setMedicines((prev) => prev.map((m) => (m.id === medId ? med : m)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSkipDose = async (medId: string) => {
    try {
      setMedicines((prev) =>
        prev.map((m) => {
          if (m.id === medId) {
            const updatedSchedules = (m.schedules || []).map((s) =>
              s.status === 'due' || s.status === 'upcoming' ? { ...s, status: 'skipped' as const } : s
            );
            const updated = { ...m, schedules: updatedSchedules };
            updateMedicineInFirestore(medId, updated).catch((err) => console.warn('Firestore update:', err));
            return updated;
          }
          return m;
        })
      );

      const res = await fetch(`/api/medicines/${medId}/skip`, {
        method: 'POST',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      const data = await res.json();
      const med = data.medicine || data.data;
      if (med) {
        setMedicines((prev) => prev.map((m) => (m.id === medId ? med : m)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddMedicine = async (medData: Partial<Medicine>) => {
    try {
      const timesArr: string[] = Array.isArray(medData.times) && medData.times.length > 0 ? medData.times : ['08:00 AM'];
      const newMed: Medicine = {
        id: `med_${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        name: medData.name || 'New Medicine',
        dosage: medData.dosage || '1 dose',
        frequency: medData.frequency || 'Once daily',
        category: medData.category || 'General',
        timing: medData.timing || 'after_food',
        times: timesArr,
        schedules: timesArr.map((t, idx) => ({
          id: `sch_${Date.now()}_${idx}`,
          time: t,
          status: 'upcoming',
        })),
        startDate: medData.startDate || new Date().toISOString().split('T')[0],
        prescribingDoctor: medData.prescribingDoctor || '',
        notes: medData.notes || '',
        quantityRemaining: medData.quantityRemaining || 30,
        refillThreshold: medData.refillThreshold || 7,
        createdAt: new Date().toISOString(),
      };

      setMedicines((prev) => [newMed, ...prev]);
      addMedicineToFirestore(newMed).catch((err) => console.warn('Firestore add:', err));

      const res = await fetch('/api/medicines', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(newMed),
      });
      const data = await res.json();
      const med = data.medicine || data.data;
      if (med) {
        setMedicines((prev) => prev.map((m) => (m.id === newMed.id ? med : m)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleEditMedicine = async (id: string, medData: Partial<Medicine>) => {
    try {
      setMedicines((prev) => prev.map((m) => (m.id === id ? { ...m, ...medData } : m)));
      updateMedicineInFirestore(id, medData).catch((err) => console.warn('Firestore edit:', err));

      const res = await fetch(`/api/medicines/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(medData),
      });
      const data = await res.json();
      const med = data.medicine || data.data;
      if (med) {
        setMedicines((prev) => prev.map((m) => (m.id === id ? med : m)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteMedicine = async (id: string) => {
    try {
      setMedicines((prev) => prev.filter((m) => m.id !== id));
      deleteMedicineFromFirestore(id).catch((err) => console.warn('Firestore delete:', err));

      await fetch(`/api/medicines/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
    } catch (e) {
      console.error(e);
    }
  };

  // Water Actions
  const handleAddWaterGlass = async () => {
    // Immediate optimistic update
    const activeUserId = user?.role === 'family' ? 'user_senior_1' : (user?.id || 'user_senior_1');
    setWaterToday((prev) => {
      const updated = {
        ...prev,
        glasses: (prev.glasses || 0) + 1,
        consumedMl: (prev.consumedMl || 0) + 250,
      };
      setWaterHistory((hPrev) => {
        const exists = hPrev.some((d) => d.date === updated.date);
        if (exists) {
          return hPrev.map((d) => (d.date === updated.date ? updated : d));
        }
        return [updated, ...hPrev];
      });
      saveWaterTrackingToFirestore(activeUserId, updated.date, updated).catch((err) => console.warn('Firestore water:', err));
      return updated;
    });

    try {
      const activeUserId = user?.role === 'family' ? 'user_senior_1' : (user?.id || 'user_senior_1');
      const res = await fetch('/api/water/add-glass', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': activeUserId,
        },
        body: JSON.stringify({ amountMl: 250 }),
      });
      if (res.ok) {
        const data = await res.json();
        const water = data.water || data.data;
        if (water) {
          setWaterToday(water);
          setWaterHistory((prev) => {
            const exists = prev.some((d) => d.date === water.date);
            if (exists) {
              return prev.map((d) => (d.date === water.date ? water : d));
            }
            return [water, ...prev];
          });
        }
      }
    } catch (e) {
      console.error('Failed to log water glass:', e);
    }
  };

  const handleRemoveWaterGlass = async () => {
    // Immediate optimistic update
    setWaterToday((prev) => {
      const updated = {
        ...prev,
        glasses: Math.max(0, (prev.glasses || 0) - 1),
        consumedMl: Math.max(0, (prev.consumedMl || 0) - 250),
      };
      setWaterHistory((hPrev) =>
        hPrev.map((d) => (d.date === updated.date ? updated : d))
      );
      return updated;
    });

    try {
      const activeUserId = user?.role === 'family' ? 'user_senior_1' : (user?.id || 'user_senior_1');
      const res = await fetch('/api/water/remove', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': activeUserId,
        },
        body: JSON.stringify({ amountMl: 250 }),
      });
      if (res.ok) {
        const data = await res.json();
        const water = data.water || data.data;
        if (water) {
          setWaterToday(water);
          setWaterHistory((hPrev) =>
            hPrev.map((d) => (d.date === water.date ? water : d))
          );
        }
      }
    } catch (e) {
      console.error('Failed to remove water glass:', e);
    }
  };

  const handleResetWater = async () => {
    // Immediate optimistic update
    setWaterToday((prev) => {
      const updated = {
        ...prev,
        glasses: 0,
        consumedMl: 0,
      };
      setWaterHistory((hPrev) =>
        hPrev.map((d) => (d.date === updated.date ? updated : d))
      );
      return updated;
    });

    try {
      const activeUserId = user?.role === 'family' ? 'user_senior_1' : (user?.id || 'user_senior_1');
      const res = await fetch('/api/water/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': activeUserId,
        },
      });
      if (res.ok) {
        const data = await res.json();
        const water = data.water || data.data;
        if (water) {
          setWaterToday(water);
        }
      }
    } catch (e) {
      console.error('Failed to reset water:', e);
    }
  };

  const handleUpdateWaterTarget = async (targetMl: number) => {
    setWaterToday((prev) => {
      const updated = { ...prev, targetMl };
      setWaterHistory((hPrev) =>
        hPrev.map((d) => (d.date === updated.date ? updated : d))
      );
      return updated;
    });

    try {
      const activeUserId = user?.role === 'family' ? 'user_senior_1' : (user?.id || 'user_senior_1');
      const res = await fetch('/api/water/target', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': activeUserId,
        },
        body: JSON.stringify({ targetMl }),
      });
      if (res.ok) {
        const data = await res.json();
        const water = data.water || data.data;
        if (water) {
          setWaterToday(water);
          setWaterHistory((prev) =>
            prev.map((d) => (d.date === water.date ? water : d))
          );
        }
      }
    } catch (e) {
      console.error('Failed to update water target:', e);
    }
  };

  // Health Records Actions
  const handleAddHealthRecord = async (recData: Partial<HealthRecord>) => {
    try {
      const newRec: HealthRecord = {
        id: `rec_${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        type: recData.type || 'blood_pressure',
        value: recData.value || '',
        numericValue: recData.numericValue,
        unit: recData.unit || '',
        recordedDate: recData.recordedDate || new Date().toISOString().split('T')[0],
        recordedTime: recData.recordedTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        notes: recData.notes || '',
        status: recData.status || 'normal',
        createdAt: new Date().toISOString(),
      };

      setHealthRecords((prev) => [newRec, ...prev]);
      addHealthRecordToFirestore(newRec).catch((err) => console.warn('Firestore record add:', err));

      const res = await fetch('/api/health-records', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(newRec),
      });
      const data = await res.json();
      const record = data.record || data.data;
      if (record) {
        setHealthRecords((prev) => prev.map((r) => (r.id === newRec.id ? record : r)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteHealthRecord = async (id: string) => {
    try {
      setHealthRecords((prev) => prev.filter((r) => r.id !== id));
      deleteHealthRecordFromFirestore(id).catch((err) => console.warn('Firestore record delete:', err));

      await fetch(`/api/health-records/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
    } catch (e) {
      console.error(e);
    }
  };

  // Appointment Actions
  const handleAddAppointment = async (apptData: Partial<Appointment>) => {
    try {
      const newAppt: Appointment = {
        id: `app_${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        doctorName: apptData.doctorName || 'Doctor',
        clinic: apptData.clinic || 'Hospital Clinic',
        appointmentDate: apptData.appointmentDate || new Date().toISOString().split('T')[0],
        appointmentTime: apptData.appointmentTime || '10:00 AM',
        purpose: apptData.purpose || 'General Checkup',
        notes: apptData.notes || '',
        status: 'upcoming',
        reminderStatus: true,
        createdAt: new Date().toISOString(),
      };

      setAppointments((prev) => [...prev, newAppt]);
      addAppointmentToFirestore(newAppt).catch((err) => console.warn('Firestore appt add:', err));

      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(newAppt),
      });
      const data = await res.json();
      const appointment = data.appointment || data.data;
      if (appointment) {
        setAppointments((prev) => prev.map((a) => (a.id === newAppt.id ? appointment : a)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCancelAppointment = async (id: string) => {
    try {
      setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status: 'cancelled' as const } : a)));
      updateAppointmentInFirestore(id, { status: 'cancelled' }).catch((err) => console.warn('Firestore appt cancel:', err));

      const res = await fetch(`/api/appointments/${id}/cancel`, {
        method: 'POST',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      const data = await res.json();
      const appointment = data.appointment || data.data;
      if (appointment) {
        setAppointments((prev) => prev.map((a) => (a.id === id ? appointment : a)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCompleteAppointment = async (id: string) => {
    try {
      setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status: 'completed' as const } : a)));
      updateAppointmentInFirestore(id, { status: 'completed' }).catch((err) => console.warn('Firestore appt complete:', err));

      const res = await fetch(`/api/appointments/${id}/complete`, {
        method: 'POST',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      const data = await res.json();
      const appointment = data.appointment || data.data;
      if (appointment) {
        setAppointments((prev) => prev.map((a) => (a.id === id ? appointment : a)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleReminder = (id: string) => {
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === id ? { ...a, reminderNotification: !a.reminderNotification } : a
      )
    );
  };

  // Wellness Actions
  const handleSaveWellness = async (wellnessData: Partial<WellnessRecord>) => {
    try {
      if (wellnessData.id) {
        saveWellnessRecordToFirestore(wellnessData as WellnessRecord).catch((err) => console.warn('Firestore wellness:', err));
      }

      const res = await fetch('/api/wellness', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(wellnessData),
      });
      const data = await res.json();
      const wellness = data.wellness || data.data;
      if (wellness) {
        setWellness(wellness);
        saveWellnessRecordToFirestore(wellness).catch((err) => console.warn('Firestore wellness:', err));
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Family Connect Actions
  const handleAddFamilyMember = async (memberData: Partial<FamilyMember>) => {
    try {
      const res = await fetch('/api/family', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(memberData),
      });
      const data = await res.json();
      const familyMember = data.familyMember || data.data;
      if (familyMember) {
        setFamilyMembers((prev) => [...prev, familyMember]);
        addFamilyMemberToFirestore(familyMember).catch((err) => console.warn('Firestore family:', err));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateFamilyPermissions = async (memberId: string, perms: any) => {
    try {
      updateFamilyMemberInFirestore(memberId, { permissions: perms }).catch((err) => console.warn('Firestore perms:', err));
      const res = await fetch(`/api/family/${memberId}/permissions`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(perms),
      });
      const data = await res.json();
      const familyMember = data.familyMember || data.data;
      if (familyMember) {
        setFamilyMembers((prev) =>
          prev.map((m) => (m.id === memberId ? familyMember : m))
        );
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRemoveFamilyMember = async (id: string) => {
    try {
      deleteFamilyMemberFromFirestore(id).catch((err) => console.warn('Firestore remove family:', err));
      await fetch(`/api/family/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      setFamilyMembers((prev) => prev.filter((m) => m.id !== id));
    } catch (e) {
      console.error(e);
    }
  };

  // Emergency Actions
  const handleUpdateEmergencyInfo = async (infoData: Partial<EmergencyInformation>) => {
    try {
      const fullInfo = {
        ...(emergencyInfo || {}),
        ...infoData,
        userId: user?.id || 'user_senior_1',
      } as EmergencyInformation;
      saveEmergencyInfoToFirestore(fullInfo).catch((err) => console.warn('Firestore emergency info:', err));

      const res = await fetch('/api/emergency/info', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(infoData),
      });
      const data = await res.json();
      const info = data.info || data.data;
      if (info) {
        setEmergencyInfo(info);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddEmergencyContact = async (contactData: Partial<EmergencyContact>) => {
    try {
      const newContact: EmergencyContact = {
        id: `emg_${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        name: contactData.name || 'Emergency Contact',
        relationship: contactData.relationship || 'Family',
        phone: contactData.phone || '',
        priority: contactData.priority || 1,
        notes: contactData.notes,
      };
      addEmergencyContactToFirestore(newContact).catch((err) => console.warn('Firestore contact add:', err));

      const res = await fetch('/api/emergency/contacts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(contactData),
      });
      const data = await res.json();
      const contact = data.contact || data.data;
      if (contact) {
        setEmergencyContacts((prev) => [...prev, contact]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleEditEmergencyContact = async (id: string, updates: Partial<EmergencyContact>) => {
    try {
      setEmergencyContacts((prev) =>
        prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
      );
      updateEmergencyContactInFirestore(id, updates).catch((err) =>
        console.warn('Firestore contact update:', err)
      );
      await fetch(`/api/emergency/contacts/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(updates),
      });
    } catch (e) {
      console.error('Failed to edit emergency contact:', e);
    }
  };

  const handleDeleteEmergencyContact = async (id: string) => {
    try {
      setEmergencyContacts((prev) => prev.filter((c) => c.id !== id));
      deleteEmergencyContactFromFirestore(id).catch((err) =>
        console.warn('Firestore contact delete:', err)
      );
      await fetch(`/api/emergency/contacts/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      const notif: NotificationItem = {
        id: `notif_${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        title: 'Emergency Contact Removed',
        message: 'An emergency contact was deleted from your priority alert list.',
        type: 'emergency_alert',
        isRead: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => [notif, ...prev]);
    } catch (e) {
      console.error('Failed to delete emergency contact:', e);
    }
  };

  const handleClearAllEmergencyContacts = async () => {
    try {
      const contactsToClear = [...emergencyContacts];
      setEmergencyContacts([]);
      for (const c of contactsToClear) {
        deleteEmergencyContactFromFirestore(c.id).catch(() => {});
      }
      await fetch('/api/emergency/contacts', {
        method: 'DELETE',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
      const notif: NotificationItem = {
        id: `notif_${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        title: 'Emergency Contacts Cleared',
        message: 'All priority emergency contacts have been removed. Please add contacts to enable automated distress alerts.',
        type: 'emergency_alert',
        isRead: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => [notif, ...prev]);
    } catch (e) {
      console.error('Failed to clear all emergency contacts:', e);
    }
  };

  const handleResetDefaultEmergencyContacts = async () => {
    try {
      const defaultContacts: EmergencyContact[] = [
        {
          id: `emg_son_${Date.now()}`,
          userId: user?.id || 'user_senior_1',
          name: 'Rajesh Patel',
          relationship: 'Son (Primary Caregiver)',
          phone: '+91 98765 43211',
          priority: 1,
          notes: 'Lives in Model Colony, Pune. Has apartment key.',
        },
        {
          id: `emg_daughter_${Date.now() + 1}`,
          userId: user?.id || 'user_senior_1',
          name: 'Priya Sharma',
          relationship: 'Daughter',
          phone: '+91 98765 43212',
          priority: 2,
          notes: 'Available after 4:00 PM.',
        },
        {
          id: `emg_doc_${Date.now() + 2}`,
          userId: user?.id || 'user_senior_1',
          name: 'Dr. A. K. Joshi',
          relationship: 'Cardiologist',
          phone: '+91 98220 12345',
          priority: 3,
          notes: 'City General Hospital Clinic.',
        },
      ];
      setEmergencyContacts(defaultContacts);
      for (const c of defaultContacts) {
        addEmergencyContactToFirestore(c).catch(() => {});
        fetch('/api/emergency/contacts', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-user-id': user?.id || 'user_senior_1',
          },
          body: JSON.stringify(c),
        }).catch(() => {});
      }
    } catch (e) {
      console.error('Failed to reset default emergency contacts:', e);
    }
  };

  const handleClearEmergencyInfo = async () => {
    try {
      const clearedInfo: EmergencyInformation = {
        userId: user?.id || 'user_senior_1',
        name: user?.name || 'Senior Member',
        bloodGroup: '',
        allergies: [],
        medicalConditions: [],
        primaryDoctor: '',
        doctorPhone: '',
        preferredHospital: '',
        insuranceNumber: '',
        emergencyNotes: '',
        updatedAt: new Date().toISOString(),
      };
      setEmergencyInfo(clearedInfo);
      saveEmergencyInfoToFirestore(clearedInfo).catch(() => {});
      await fetch('/api/emergency/info', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify(clearedInfo),
      });
    } catch (e) {
      console.error('Failed to clear emergency info:', e);
    }
  };

  // Admin Tips Actions
  const handleAddTip = async (tipData: Partial<HealthTip>) => {
    try {
      const newTip: HealthTip = {
        id: `tip_${Date.now()}`,
        title: tipData.title || '',
        content: tipData.content || '',
        category: tipData.category || 'general_wellness',
        isActive: tipData.isActive ?? true,
        readTimeMinutes: tipData.readTimeMinutes || 2,
        createdAt: new Date().toISOString(),
      };
      addHealthTipToFirestore(newTip).catch((err) => console.warn('Firestore tip add:', err));

      const res = await fetch('/api/tips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tipData),
      });
      const data = await res.json();
      const tip = data.tip || data.data;
      if (tip) {
        setTips((prev) => [tip, ...prev]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteTip = async (id: string) => {
    try {
      deleteHealthTipFromFirestore(id).catch((err) => console.warn('Firestore tip delete:', err));
      await fetch(`/api/tips/${id}`, { method: 'DELETE' });
      setTips((prev) => prev.filter((t) => t.id !== id));
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleActiveTip = (id: string) => {
    setTips((prev) =>
      prev.map((t) => (t.id === id ? { ...t, isActive: !t.isActive } : t))
    );
  };

  // Profile update
  const handleUpdateProfile = (data: Partial<User>) => {
    if (user) {
      const updated = { ...user, ...data };
      setUser(updated);
      saveUserToFirestore(updated).catch((err) => console.warn('Firestore profile update:', err));
      try {
        localStorage.setItem('seniorcare_active_user', JSON.stringify(updated));
      } catch (e) {}
    }
  };

  // Document Vault Handlers
  const handleUploadDocument = async (docData: Partial<MedicalDocument>) => {
    try {
      const newDoc: MedicalDocument = {
        id: `doc_${Date.now()}`,
        seniorId: user?.id || 'user_senior_1',
        documentType: docData.documentType || 'prescription',
        title: docData.title || 'Medical Document',
        fileName: docData.fileName || `${(docData.title || 'document').replace(/\s+/g, '_')}.pdf`,
        fileSize: docData.fileSize || '1.5 MB',
        uploadedBy: user?.name || 'Senior Member',
        uploadedAt: new Date().toISOString(),
        doctorName: docData.doctorName,
        hospitalClinic: docData.hospitalClinic,
        description: docData.description,
        tags: docData.tags || ['Medical Record'],
      };

      setMedicalDocuments((prev) => [newDoc, ...prev]);
      addMedicalDocumentToFirestore(newDoc).catch((err) => console.warn('Firestore doc add:', err));

      const res = await fetch('/api/documents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify({
          seniorId: 'user_senior_1',
          ...docData,
        }),
      });
      const data = await res.json();
      const serverDoc = data.document || data.data;
      if (serverDoc) {
        setMedicalDocuments((prev) => prev.map((d) => (d.id === newDoc.id ? serverDoc : d)));
      }

      const notif: NotificationItem = {
        id: `notif-doc-${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        title: 'New Medical Document Uploaded',
        message: `${newDoc.title} added to senior's encrypted Medical Vault.`,
        type: 'general',
        isRead: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => [notif, ...prev]);
    } catch (e) {
      console.error('Failed to upload document:', e);
    }
  };

  const handleDeleteDocument = async (id: string) => {
    try {
      deleteMedicalDocumentFromFirestore(id).catch((err) => console.warn('Firestore doc delete:', err));
      setMedicalDocuments((prev) => prev.filter((d) => d.id !== id));
      await fetch(`/api/documents/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-id': user?.id || 'user_senior_1' },
      });
    } catch (e) {
      console.error('Failed to delete document:', e);
    }
  };

  // Service Request Handler
  const handleSendServiceRequest = async (serviceData: Partial<ServiceRequest>) => {
    try {
      const newService: ServiceRequest = {
        id: `srv_${Date.now()}`,
        seniorId: 'user_senior_1',
        seniorName: user?.name || 'Ramesh Patel',
        serviceType: serviceData.serviceType || 'medicine_delivery',
        title: serviceData.title || 'Eldercare Assistance',
        description: serviceData.description || '',
        requestedDate: serviceData.requestedDate || new Date().toISOString().split('T')[0],
        priority: serviceData.priority || 'normal',
        status: 'requested',
        createdAt: new Date().toISOString(),
      };

      setServiceRequests((prev) => [newService, ...prev]);
      addServiceRequestToFirestore(newService).catch((err) => console.warn('Firestore service add:', err));

      const res = await fetch('/api/services', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify({
          seniorId: 'user_senior_1',
          requestedById: user?.id || 'user_family_1',
          ...serviceData,
        }),
      });
      const data = await res.json();
      const serverSvc = data.service || data.data;
      if (serverSvc) {
        setServiceRequests((prev) => prev.map((s) => (s.id === newService.id ? serverSvc : s)));
      }

      const notif: NotificationItem = {
        id: `notif-svc-${Date.now()}`,
        userId: user?.id || 'user_senior_1',
        title: 'Care Service Requested',
        message: `${newService.title} has been booked. Care coordinators are dispatching.`,
        type: 'general',
        isRead: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => [notif, ...prev]);
    } catch (e) {
      console.error('Failed to create service request:', e);
    }
  };

  // Direct Messaging Handler
  const handleSendMessage = async (receiverId: string, receiverName: string, text: string) => {
    try {
      const newMsg: DirectMessage = {
        id: `msg_${Date.now()}`,
        senderId: user?.id || 'user_senior_1',
        senderName: user?.name || 'Senior Member',
        senderRole: user?.role || 'senior',
        receiverId,
        receiverName: receiverName || 'Contact',
        message: text,
        timestamp: new Date().toISOString(),
        isRead: false,
      };

      setMessages((prev) => [...prev, newMsg]);
      sendMessageToFirestore(newMsg).catch((err) => console.warn('Firestore msg add:', err));

      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify({
          receiverId,
          receiverName,
          content: text,
        }),
      });
      const data = await res.json();
      const serverMsg = data.message || data.data;
      if (serverMsg) {
        setMessages((prev) => prev.map((m) => (m.id === newMsg.id ? serverMsg : m)));
      }
    } catch (e) {
      console.error('Failed to send message:', e);
    }
  };

  // Notification helpers
  const handleMarkNotificationRead = async (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: !n.isRead } : n))
    );
    updateNotificationInFirestore(id, { isRead: true }).catch(() => {});
    fetch(`/api/notifications/${id}/read`, {
      method: 'PUT',
      headers: { 'x-user-id': user?.id || 'user_senior_1' },
    }).catch(() => {});
  };

  const handleMarkAllNotificationsRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    fetch('/api/notifications/read-all', {
      method: 'PUT',
      headers: { 'x-user-id': user?.id || 'user_senior_1' },
    }).catch(() => {});
  };

  const handleDeleteNotification = async (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    deleteNotificationFromFirestore(id).catch(() => {});
    fetch(`/api/notifications/${id}`, {
      method: 'DELETE',
      headers: { 'x-user-id': user?.id || 'user_senior_1' },
    }).catch(() => {});
  };

  const handleClearAllNotifications = async () => {
    setNotifications([]);
    fetch('/api/notifications', {
      method: 'DELETE',
      headers: { 'x-user-id': user?.id || 'user_senior_1' },
    }).catch(() => {});
  };

  const handleSendTestNotification = async (
    type: 'medicine' | 'health' | 'appointment' | 'emergency' | 'water'
  ) => {
    const metaMap = {
      medicine: {
        title: 'Medicine Due: Metformin 500mg',
        message: 'Take 1 tablet of Metformin 500mg after dinner with water.',
        type: 'medicine',
      },
      health: {
        title: 'Blood Pressure Check Reminder',
        message: 'It has been 24 hours since your last BP reading. Recommended reading: 120/80 mmHg.',
        type: 'health_record',
      },
      appointment: {
        title: 'Upcoming Appointment Reminder',
        message: 'Reminder: Cardiology review with Dr. A. K. Joshi tomorrow at 10:30 AM.',
        type: 'appointment',
      },
      emergency: {
        title: 'Emergency SOS Signal Dispatched',
        message: 'Distress beacon activated. Connected contacts and caregivers have been notified with GPS coordinates.',
        type: 'emergency_alert',
      },
      water: {
        title: 'Hydration Goal: 2 Glasses Remaining',
        message: 'Drink 250ml warm water to reach your daily 2,000ml goal and support circulation.',
        type: 'water_reminder',
      },
    };

    const chosen = metaMap[type] || metaMap.medicine;
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      userId: user?.id || 'user_senior_1',
      title: chosen.title,
      message: chosen.message,
      type: chosen.type as any,
      isRead: false,
      createdAt: new Date().toISOString(),
    };

    setNotifications((prev) => [newNotif, ...prev]);
    addNotificationToFirestore(newNotif).catch(() => {});
    fetch('/api/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': user?.id || 'user_senior_1',
      },
      body: JSON.stringify(newNotif),
    }).catch(() => {});
  };

  const handleDistressAlertTriggered = async (details?: { location?: string; timestamp?: string }) => {
    try {
      const newAlert: EmergencyAlert = {
        id: `alert_${Date.now()}`,
        seniorId: user?.id || 'user_senior_1',
        seniorName: user?.name || 'Senior Member',
        seniorPhone: user?.phone || '+91 98765 43210',
        emergencyType: 'sos_button',
        latitude: 18.5204,
        longitude: 73.8567,
        address: details?.location || '18.5204° N, 73.8567° E (Shivajinagar, Pune)',
        description: 'Immediate distress SOS triggered from emergency button',
        status: 'active',
        createdAt: new Date().toISOString(),
      };

      setEmergencyAlerts((prev) => [newAlert, ...prev]);
      createEmergencyAlertInFirestore(newAlert).catch((err) => console.warn('Firestore SOS add:', err));

      const res = await fetch('/api/emergency/sos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.id || 'user_senior_1',
        },
        body: JSON.stringify({
          location: details?.location || '18.5204° N, 73.8567° E (Shivajinagar, Pune)',
          message: 'Immediate distress SOS triggered from emergency button',
        }),
      });
      const data = await res.json();
      if (data.alert) {
        setEmergencyAlerts((prev) => prev.map((a) => (a.id === newAlert.id ? data.alert : a)));
      }
    } catch (e) {
      console.error('Failed to send SOS to backend:', e);
    }

    const newNotif: NotificationItem = {
      id: `notif-sos-${Date.now()}`,
      userId: user?.id || 'user_senior_1',
      title: '🚨 EMERGENCY DISTRESS ALERT BROADCAST',
      message: `Emergency SOS triggered by ${user?.name || 'Senior'}. Location: ${details?.location || '18.5204° N, 73.8567° E'}. Family & caregivers alerted.`,
      type: 'emergency_alert',
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // Calorie Counter & Nutrition Handlers
  const handleAddCalorieRecord = async (rec: Omit<CalorieRecord, 'id' | 'createdAt'>) => {
    const newRecord: CalorieRecord = {
      ...rec,
      id: `cal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setCalorieRecords((prev) => [newRecord, ...prev]);
    try {
      await addCalorieRecordToFirestore(newRecord);
    } catch (err) {
      console.warn('Firestore write warning:', err);
    }
    try {
      await fetch('/api/calorie-records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user?.id || 'user_senior_1' },
        body: JSON.stringify(newRecord),
      });
    } catch (e) {}
  };

  const handleUpdateCalorieRecord = async (id: string, updates: Partial<CalorieRecord>) => {
    setCalorieRecords((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    try {
      await updateCalorieRecordInFirestore(id, updates);
    } catch (err) {
      console.warn('Firestore update warning:', err);
    }
    try {
      await fetch(`/api/calorie-records/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (e) {}
  };

  const handleDeleteCalorieRecord = async (id: string) => {
    setCalorieRecords((prev) => prev.filter((r) => r.id !== id));
    try {
      await deleteCalorieRecordFromFirestore(id);
    } catch (err) {
      console.warn('Firestore delete warning:', err);
    }
    try {
      await fetch(`/api/calorie-records/${id}`, { method: 'DELETE' });
    } catch (e) {}
  };

  const handleAddFood = async (food: Omit<FoodItem, 'id'>) => {
    const newFood: FoodItem = {
      ...food,
      id: `food_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    setFoods((prev) => [...prev, newFood]);
    try {
      await addFoodToFirestore(newFood);
    } catch (err) {
      console.warn('Firestore add food warning:', err);
    }
    try {
      await fetch('/api/foods', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newFood),
      });
    } catch (e) {}
  };

  const handleUpdateFood = async (id: string, updates: Partial<FoodItem>) => {
    setFoods((prev) => prev.map((f) => (f.id === id ? { ...f, ...updates } : f)));
    try {
      await updateFoodInFirestore(id, updates);
    } catch (err) {
      console.warn('Firestore update food warning:', err);
    }
    try {
      await fetch(`/api/foods/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (e) {}
  };

  const handleDeleteFood = async (id: string) => {
    setFoods((prev) => prev.filter((f) => f.id !== id));
    try {
      await deleteFoodFromFirestore(id);
    } catch (err) {
      console.warn('Firestore delete food warning:', err);
    }
    try {
      await fetch(`/api/foods/${id}`, { method: 'DELETE' });
    } catch (e) {}
  };

  const handleUpdateCalorieProfile = async (profile: {
    age?: number;
    gender?: string;
    height?: number;
    weight?: number;
    activityLevel?: any;
    dailyCalorieGoal?: number;
  }) => {
    if (!user) return;
    const updatedUser = { ...user, ...profile };
    setUser(updatedUser);
    try {
      localStorage.setItem('seniorcare_active_user', JSON.stringify(updatedUser));
    } catch (e) {}

    try {
      await saveUserCalorieProfileToFirestore(user.id, profile);
    } catch (err) {
      console.warn('Firestore calorie profile warning:', err);
    }
    try {
      await fetch('/api/user/calorie-profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user.id },
        body: JSON.stringify(profile),
      });
    } catch (e) {}
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Accessible Header */}
      <Header
        user={user}
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
        fontSize={fontSize}
        onFontSizeChange={handleFontSizeChange}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenAuth={() => {
          setIsLoginPage(true);
        }}
        onLogout={() => {
          setUser(null);
          try {
            localStorage.removeItem('seniorcare_active_user');
          } catch (e) {}
          setIsLoginPage(true);
        }}
        onSwitchDemoRole={handleSwitchDemoRole}
        notifications={notifications}
        onMarkNotificationRead={handleMarkNotificationRead}
        onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsLoginPage(false);
        }}
      />

      {/* Role-based Desktop Navigation Bar */}
      {user && !isLoginPage && (
        <Navigation
          role={user.role}
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          language={currentLanguage}
        />
      )}

      {/* Care Roles & View Switcher Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-2 text-xs text-slate-700 flex flex-wrap items-center justify-between gap-2 shadow-2xs">
        <div className="flex items-center space-x-2 flex-wrap gap-y-1">
          <span className="font-extrabold text-slate-800 uppercase tracking-wider text-[11px]">
            {t('carePortal', currentLanguage)}:
          </span>
          
          <button
            onClick={() => {
              setIsLoginPage(false);
            }}
            className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition flex items-center space-x-1.5 ${
              !isLoginPage
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 border border-slate-200 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>{t('activeWorkspace', currentLanguage)} ({user?.name || t(user?.role || 'Guest', currentLanguage)})</span>
          </button>

          <button
            onClick={() => {
              setIsLoginPage(true);
            }}
            className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition flex items-center space-x-1.5 ${
              isLoginPage
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 border border-slate-200 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>🔑 {t('loginPageAllRoles', currentLanguage)}</span>
          </button>

          {/* Quick 1-Click Role Switcher */}
          <div className="flex items-center space-x-1 pl-2 border-l border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 mr-0.5">{t('switchRole', currentLanguage)}:</span>
            <button
              onClick={() => handleSwitchDemoRole('senior')}
              className={`px-2 py-1 rounded-lg text-xs font-semibold cursor-pointer transition ${
                user?.role === 'senior' && !isLoginPage
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title="Switch to Senior Member role"
            >
              👵 {t('senior', currentLanguage)}
            </button>
            <button
              onClick={() => handleSwitchDemoRole('family')}
              className={`px-2 py-1 rounded-lg text-xs font-semibold cursor-pointer transition ${
                user?.role === 'family' && !isLoginPage
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title="Switch to Family Member role"
            >
              👨‍👩‍👧 {t('familyMember', currentLanguage)}
            </button>
            <button
              onClick={() => handleSwitchDemoRole('caregiver')}
              className={`px-2 py-1 rounded-lg text-xs font-semibold cursor-pointer transition ${
                user?.role === 'caregiver' && !isLoginPage
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title="Switch to Caregiver Nurse role"
            >
              🩺 {t('caregiver', currentLanguage)}
            </button>
            <button
              onClick={() => handleSwitchDemoRole('admin')}
              className={`px-2 py-1 rounded-lg text-xs font-semibold cursor-pointer transition ${
                user?.role === 'admin' && !isLoginPage
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title="Switch to Administrator role"
            >
              🛡️ {t('admin', currentLanguage)}
            </button>
          </div>
        </div>

        <div className="hidden sm:flex items-center space-x-3 text-[11px] text-slate-500 font-medium">
          {isDataLoading ? (
            <span className="inline-flex items-center space-x-1.5 text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-ping"></span>
              <span className="font-bold">{t('syncingFirestore', currentLanguage)}</span>
            </span>
          ) : (
            <span className="inline-flex items-center space-x-1.5 text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-bold">{t('firestoreSynced', currentLanguage)}</span>
            </span>
          )}
          <span>{t('activeUser', currentLanguage)}: <strong className="text-teal-700 font-bold">{user?.name || 'Visitor'}</strong></span>
          <span>•</span>
          <span>{t('email', currentLanguage)}: <strong className="text-teal-700 font-semibold">{user?.email || 'N/A'}</strong></span>
          <span>•</span>
          <span>{t('role', currentLanguage)}: <strong className="text-teal-700 uppercase font-bold">{t(user?.role || 'None', currentLanguage)}</strong></span>
          <span>•</span>
          <span>{t('language', currentLanguage)}: <strong className="text-teal-700">{currentLanguage.toUpperCase()} ({currentLanguage === 'hi' ? 'हिन्दी' : currentLanguage === 'mr' ? 'मराठी' : 'EN'})</strong></span>
        </div>
      </div>

      {firestoreError && (
        <div className="bg-rose-50 border-b border-rose-200 px-4 py-2 text-xs text-rose-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="font-bold">Firestore Notice:</span>
            <span>{firestoreError}</span>
          </div>
          <button
            onClick={() => setFirestoreError(null)}
            className="text-rose-600 hover:text-rose-900 font-bold ml-4 cursor-pointer"
          >
            ✕ Dismiss
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1">
        {isLoginPage || !user ? (
          <LoginPage
            language={currentLanguage}
            onLanguageChange={(lang) => setCurrentLanguage(lang)}
            fontSize={fontSize}
            onFontSizeChange={handleFontSizeChange}
            onLoginSuccess={(loggedUser) => {
              setUser(loggedUser);
              saveUserToFirestore(loggedUser).catch((err) => console.warn('Firestore user save:', err));
              try {
                localStorage.setItem('seniorcare_active_user', JSON.stringify(loggedUser));
                const raw = localStorage.getItem('seniorcare_saved_role_sessions');
                const parsed = raw ? JSON.parse(raw) : {};
                parsed[loggedUser.role] = {
                  role: loggedUser.role,
                  name: loggedUser.name,
                  email: loggedUser.email,
                  phone: loggedUser.phone,
                  lastLoginAt: new Date().toISOString(),
                };
                localStorage.setItem('seniorcare_saved_role_sessions', JSON.stringify(parsed));
              } catch (e) {}
              setIsLoginPage(false);
              if (loggedUser.role === 'senior') setActiveTab('dashboard');
              else if (loggedUser.role === 'caregiver') setActiveTab('caregiverDashboard');
              else if (loggedUser.role === 'family') setActiveTab('familyDashboard');
              else setActiveTab('adminDashboard');
            }}
            onOpenEmergency={() => setIsEmergencyOpen(true)}
            onCancel={user ? () => setIsLoginPage(false) : undefined}
          />
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
            {/* Global Notifications & Alert Center: accessible by all roles */}
            {activeTab === 'notifications' && (
              <NotificationsView
                notifications={notifications}
                language={currentLanguage}
                onMarkRead={handleMarkNotificationRead}
                onMarkAllRead={handleMarkAllNotificationsRead}
                onDeleteNotification={handleDeleteNotification}
                onClearAllNotifications={handleClearAllNotifications}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onOpenEmergency={() => setIsEmergencyOpen(true)}
                onSendTestNotification={handleSendTestNotification}
              />
            )}

            {/* Senior Views */}
            {user?.role === 'senior' && (
              <>
                {activeTab === 'dashboard' && (
                  <DashboardView
                    user={user}
                    language={currentLanguage}
                    medicines={medicines}
                    healthRecords={healthRecords}
                    appointments={appointments}
                    waterToday={waterToday}
                    waterHistory={waterHistory}
                    wellness={wellness}
                    dailyTip={dailyTip}
                    calorieRecords={calorieRecords}
                    onTakeDose={handleTakeDose}
                    onAddWaterGlass={handleAddWaterGlass}
                    onNavigateTab={(tab) => setActiveTab(tab)}
                    onOpenAddMedicine={() => setActiveTab('medicines')}
                    onOpenAddReading={() => setActiveTab('healthRecords')}
                    onOpenBookAppointment={() => setActiveTab('appointments')}
                    onOpenEmergency={() => setIsEmergencyOpen(true)}
                  />
                )}

                {activeTab === 'calendar' && (
                  <CalendarView
                    user={user}
                    medicines={medicines}
                    appointments={appointments}
                    language={currentLanguage}
                    onOpenBookAppointment={() => setActiveTab('appointments')}
                    onTakeDose={handleTakeDose}
                  />
                )}

                {activeTab === 'medicines' && (
                  <MedicineView
                    medicines={medicines}
                    language={currentLanguage}
                    onAddMedicine={handleAddMedicine}
                    onEditMedicine={handleEditMedicine}
                    onDeleteMedicine={handleDeleteMedicine}
                    onTakeDose={handleTakeDose}
                    onSkipDose={handleSkipDose}
                  />
                )}

                {activeTab === 'healthRecords' && (
                  <HealthRecordsView
                    records={healthRecords}
                    language={currentLanguage}
                    onAddRecord={handleAddHealthRecord}
                    onDeleteRecord={handleDeleteHealthRecord}
                  />
                )}

                {activeTab === 'waterTracker' && (
                  <WaterTrackerView
                    waterToday={waterToday}
                    waterHistory={waterHistory}
                    language={currentLanguage}
                    onAddGlass={handleAddWaterGlass}
                    onRemoveGlass={handleRemoveWaterGlass}
                    onReset={handleResetWater}
                    onUpdateTarget={handleUpdateWaterTarget}
                  />
                )}

                {activeTab === 'calorieCounter' && (
                  <CalorieCounterView
                    user={user}
                    language={currentLanguage}
                    calorieRecords={calorieRecords}
                    foods={foods}
                    onAddRecord={handleAddCalorieRecord}
                    onUpdateRecord={handleUpdateCalorieRecord}
                    onDeleteRecord={handleDeleteCalorieRecord}
                    onUpdateProfile={handleUpdateCalorieProfile}
                    onAddFoodToDatabase={handleAddFood}
                  />
                )}

                {activeTab === 'wellness' && (
                  <WellnessView
                    wellness={wellness}
                    language={currentLanguage}
                    onSaveWellness={handleSaveWellness}
                  />
                )}

                {activeTab === 'appointments' && (
                  <AppointmentsView
                    appointments={appointments}
                    language={currentLanguage}
                    onAddAppointment={handleAddAppointment}
                    onCancelAppointment={handleCancelAppointment}
                    onCompleteAppointment={handleCompleteAppointment}
                    onToggleReminder={handleToggleReminder}
                  />
                )}

                {activeTab === 'familyConnect' && (
                  <FamilyConnectView
                    familyMembers={familyMembers}
                    language={currentLanguage}
                    onAddFamilyMember={handleAddFamilyMember}
                    onUpdatePermissions={handleUpdateFamilyPermissions}
                    onRemoveFamilyMember={handleRemoveFamilyMember}
                  />
                )}

                {activeTab === 'medicalVault' && (
                  <MedicalVaultView
                    documents={medicalDocuments}
                    language={currentLanguage}
                    onUploadDocument={handleUploadDocument}
                    onDeleteDocument={handleDeleteDocument}
                  />
                )}

                {activeTab === 'messages' && (
                  <ChatView
                    currentUserId={user.id}
                    currentUserName={user.name}
                    currentUserRole={user.role}
                    messages={messages}
                    language={currentLanguage}
                    onSendMessage={handleSendMessage}
                  />
                )}

                {activeTab === 'aiStudio' && (
                  <AiStudioView language={currentLanguage} />
                )}

                {activeTab === 'healthAssistant' && (
                  <HealthAssistantView language={currentLanguage} />
                )}

                {activeTab === 'healthTips' && (
                  <HealthTipsView tips={tips} language={currentLanguage} />
                )}

                {activeTab === 'profile' && (
                  <ProfileView
                    user={user}
                    language={currentLanguage}
                    onLanguageChange={(lang) => setCurrentLanguage(lang)}
                    fontSize={fontSize}
                    onFontSizeChange={handleFontSizeChange}
                    onUpdateProfile={handleUpdateProfile}
                    onLogout={() => {
                      handleSwitchDemoRole('senior');
                    }}
                  />
                )}
              </>
            )}

            {/* Family Views */}
            {user?.role === 'family' && (
              <>
                {activeTab === 'familyDashboard' && (
                  <FamilyDashboardView
                    seniorUser={{
                      id: 'user_senior_1',
                      name: 'Connected Senior Member',
                      email: 'senior@mycare.org',
                      phone: '+91 98765 43210',
                      role: 'senior',
                      age: 68,
                      bloodGroup: 'B+',
                      language: currentLanguage,
                      fontSize: 'large',
                      accountStatus: 'active',
                      createdAt: '2026-01-15T10:00:00Z',
                    }}
                    familyUser={user}
                    medicines={medicines}
                    healthRecords={healthRecords}
                    appointments={appointments}
                    waterToday={waterToday}
                    serviceRequests={serviceRequests}
                    emergencyAlerts={emergencyAlerts}
                    medicalDocuments={medicalDocuments}
                    messages={messages}
                    language={currentLanguage}
                    onSendServiceRequest={handleSendServiceRequest}
                    onSendMessage={handleSendMessage}
                    onNavigateTab={(tab) => setActiveTab(tab)}
                    onOpenEmergency={() => setIsEmergencyOpen(true)}
                  />
                )}

                {activeTab === 'calorieCounter' && (
                  <CalorieCounterView
                    user={user}
                    language={currentLanguage}
                    calorieRecords={calorieRecords}
                    foods={foods}
                    onAddRecord={handleAddCalorieRecord}
                    onUpdateRecord={handleUpdateCalorieRecord}
                    onDeleteRecord={handleDeleteCalorieRecord}
                    onUpdateProfile={handleUpdateCalorieProfile}
                    onAddFoodToDatabase={handleAddFood}
                    isCaregiverOrFamily={true}
                    seniorName="Senior Member"
                  />
                )}

                {activeTab === 'medicalVault' && (
                  <MedicalVaultView
                    documents={medicalDocuments}
                    language={currentLanguage}
                    onUploadDocument={handleUploadDocument}
                    onDeleteDocument={handleDeleteDocument}
                  />
                )}

                {activeTab === 'messages' && (
                  <ChatView
                    currentUserId={user.id}
                    currentUserName={user.name}
                    currentUserRole={user.role}
                    messages={messages}
                    language={currentLanguage}
                    onSendMessage={handleSendMessage}
                  />
                )}

                {activeTab === 'appointments' && (
                  <AppointmentsView
                    appointments={appointments}
                    language={currentLanguage}
                    onAddAppointment={handleAddAppointment}
                    onCancelAppointment={handleCancelAppointment}
                    onCompleteAppointment={handleCompleteAppointment}
                    onToggleReminder={handleToggleReminder}
                  />
                )}

                {activeTab === 'calendar' && (
                  <CalendarView
                    user={user}
                    medicines={medicines}
                    appointments={appointments}
                    language={currentLanguage}
                    onOpenBookAppointment={() => setActiveTab('appointments')}
                    onTakeDose={handleTakeDose}
                  />
                )}

                {activeTab === 'healthAssistant' && (
                  <HealthAssistantView language={currentLanguage} />
                )}

                {activeTab === 'profile' && (
                  <ProfileView
                    user={user}
                    language={currentLanguage}
                    onLanguageChange={(lang) => setCurrentLanguage(lang)}
                    fontSize={fontSize}
                    onFontSizeChange={handleFontSizeChange}
                    onUpdateProfile={handleUpdateProfile}
                    onLogout={() => {
                      handleSwitchDemoRole('senior');
                    }}
                  />
                )}
              </>
            )}

            {/* Caregiver Views */}
            {user?.role === 'caregiver' && (
              <>
                {activeTab === 'caregiverDashboard' && (
                  <CaregiverDashboardView
                    language={currentLanguage}
                    onOpenEmergency={() => setIsEmergencyOpen(true)}
                  />
                )}

                {activeTab === 'calorieCounter' && (
                  <CalorieCounterView
                    user={user}
                    language={currentLanguage}
                    calorieRecords={calorieRecords}
                    foods={foods}
                    onAddRecord={handleAddCalorieRecord}
                    onUpdateRecord={handleUpdateCalorieRecord}
                    onDeleteRecord={handleDeleteCalorieRecord}
                    onUpdateProfile={handleUpdateCalorieProfile}
                    onAddFoodToDatabase={handleAddFood}
                    isCaregiverOrFamily={true}
                    seniorName="Connected Senior"
                  />
                )}

                {activeTab === 'calendar' && (
                  <CalendarView
                    user={user}
                    medicines={medicines}
                    appointments={appointments}
                    language={currentLanguage}
                    onOpenBookAppointment={() => setActiveTab('appointments')}
                    onTakeDose={handleTakeDose}
                  />
                )}

                {activeTab === 'messages' && (
                  <ChatView
                    currentUserId={user.id}
                    currentUserName={user.name}
                    currentUserRole={user.role}
                    messages={messages}
                    language={currentLanguage}
                    onSendMessage={handleSendMessage}
                  />
                )}

                {activeTab === 'aiStudio' && (
                  <AiStudioView language={currentLanguage} />
                )}

                {activeTab === 'familyConnect' && (
                  <FamilyConnectView
                    familyMembers={familyMembers}
                    language={currentLanguage}
                    onAddFamilyMember={handleAddFamilyMember}
                    onUpdatePermissions={handleUpdateFamilyPermissions}
                    onRemoveFamilyMember={handleRemoveFamilyMember}
                  />
                )}

                {activeTab === 'healthAssistant' && (
                  <HealthAssistantView language={currentLanguage} />
                )}

                {activeTab === 'healthTips' && (
                  <HealthTipsView tips={tips} language={currentLanguage} />
                )}

                {activeTab === 'profile' && (
                  <ProfileView
                    user={user}
                    language={currentLanguage}
                    onLanguageChange={(lang) => setCurrentLanguage(lang)}
                    fontSize={fontSize}
                    onFontSizeChange={handleFontSizeChange}
                    onUpdateProfile={handleUpdateProfile}
                    onLogout={() => {
                      handleSwitchDemoRole('senior');
                    }}
                  />
                )}
              </>
            )}

            {/* Admin Views */}
            {user?.role === 'admin' && (
              <>
                {activeTab === 'adminDashboard' && (
                  <AdminDashboardView
                    language={currentLanguage}
                    onNavigateTab={(tab) => setActiveTab(tab)}
                  />
                )}

                {activeTab === 'adminFoods' && (
                  <AdminFoodsView
                    foods={foods}
                    language={currentLanguage}
                    onAddFood={handleAddFood}
                    onUpdateFood={handleUpdateFood}
                    onDeleteFood={handleDeleteFood}
                  />
                )}

                {activeTab === 'adminUsers' && (
                  <AdminUsersView language={currentLanguage} />
                )}

                {activeTab === 'adminTips' && (
                  <AdminTipsView
                    tips={tips}
                    language={currentLanguage}
                    onAddTip={handleAddTip}
                    onDeleteTip={handleDeleteTip}
                    onToggleActiveTip={handleToggleActiveTip}
                  />
                )}

                {activeTab === 'adminReports' && (
                  <AdminReportsView language={currentLanguage} />
                )}

                {activeTab === 'adminLogs' && (
                  <AdminLogsView language={currentLanguage} />
                )}

                {activeTab === 'adminAnalytics' && (
                  <AdminAnalyticsView language={currentLanguage} />
                )}
              </>
            )}
          </div>
        )}
      </main>

      {/* Modals */}
      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        contacts={emergencyContacts}
        emergencyInfo={emergencyInfo}
        language={currentLanguage}
        onUpdateInfo={handleUpdateEmergencyInfo}
        onAddContact={handleAddEmergencyContact}
        onEditContact={handleEditEmergencyContact}
        onDeleteContact={handleDeleteEmergencyContact}
        onClearAllContacts={handleClearAllEmergencyContacts}
        onClearEmergencyInfo={handleClearEmergencyInfo}
        onResetDefaultContacts={handleResetDefaultEmergencyContacts}
        onTriggerDistressAlert={handleDistressAlertTriggered}
      />
    </div>
  );
}
