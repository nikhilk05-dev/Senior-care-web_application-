import React from 'react';
import {
  LayoutDashboard,
  Pill,
  Activity,
  Droplets,
  Heart,
  Calendar,
  Users,
  Bot,
  Lightbulb,
  ShieldCheck,
  FileText,
  History,
  TrendingUp,
  UserCheck,
  Sparkles,
  MessageCircle,
  FolderLock,
  ShoppingBag,
  Home,
  Flame,
  Utensils,
  Bell,
} from 'lucide-react';
import { UserRole, Language } from '../types';
import { t } from '../i18n';

interface NavigationProps {
  role: UserRole;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  language: Language;
}

export const Navigation: React.FC<NavigationProps> = ({
  role,
  activeTab,
  onSelectTab,
  language,
}) => {
  if (role === 'senior') {
    const navItems = [
      { id: 'dashboard', label: t('dashboard', language), icon: LayoutDashboard },
      { id: 'notifications', label: t('notifications', language), icon: Bell },
      { id: 'calendar', label: t('calendar', language), icon: Calendar },
      { id: 'medicines', label: t('medicines', language), icon: Pill },
      { id: 'healthRecords', label: t('healthRecords', language), icon: Activity },
      { id: 'medicalVault', label: 'Document Vault', icon: FolderLock },
      { id: 'messages', label: 'Messages', icon: MessageCircle },
      { id: 'waterTracker', label: t('waterTracker', language), icon: Droplets },
      { id: 'calorieCounter', label: 'Calorie Counter', icon: Flame },
      { id: 'wellness', label: t('wellness', language), icon: Heart },
      { id: 'appointments', label: t('appointments', language), icon: Calendar },
      { id: 'familyConnect', label: t('familyConnect', language), icon: Users },
      { id: 'healthAssistant', label: t('healthAssistant', language), icon: Bot },
      { id: 'healthTips', label: t('healthTips', language), icon: Lightbulb },
      { id: 'aiStudio', label: t('aiStudio', language), icon: Sparkles },
    ];

    return (
      <nav className="hidden lg:block bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1 overflow-x-auto py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-xl font-bold text-xs tracking-tight transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    );
  }

  if (role === 'family') {
    const navItems = [
      { id: 'familyDashboard', label: 'Senior Health Overview', icon: Home },
      { id: 'notifications', label: t('notifications', language), icon: Bell },
      { id: 'calendar', label: 'Senior Calendar', icon: Calendar },
      { id: 'calorieCounter', label: 'Senior Nutrition & Calories', icon: Flame },
      { id: 'medicalVault', label: 'Senior Medical Vault', icon: FolderLock },
      { id: 'messages', label: 'Care & Family Chat', icon: MessageCircle },
      { id: 'appointments', label: 'Doctor Visits', icon: Calendar },
      { id: 'healthAssistant', label: 'AI Health Companion', icon: Bot },
    ];

    return (
      <nav className="hidden lg:block bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-2">
            <div className="flex space-x-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-tab-${item.id}`}
                    onClick={() => onSelectTab(item.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-bold text-sm tracking-tight transition-all cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
            <span className="text-xs font-bold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
              Monitoring: Connected Senior
            </span>
          </div>
        </div>
      </nav>
    );
  }

  if (role === 'caregiver') {
    const navItems = [
      { id: 'caregiverDashboard', label: 'Connected Seniors Health', icon: UserCheck },
      { id: 'notifications', label: t('notifications', language), icon: Bell },
      { id: 'calendar', label: 'Care Calendar', icon: Calendar },
      { id: 'calorieCounter', label: 'Senior Calorie Tracking', icon: Flame },
      { id: 'messages', label: 'Direct Messages', icon: MessageCircle },
      { id: 'familyConnect', label: t('familyConnect', language), icon: Users },
      { id: 'healthAssistant', label: t('healthAssistant', language), icon: Bot },
      { id: 'healthTips', label: t('healthTips', language), icon: Lightbulb },
      { id: 'aiStudio', label: t('aiStudio', language), icon: Sparkles },
    ];

    return (
      <nav className="hidden lg:block bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-2 py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl font-bold text-sm tracking-tight transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    );
  }

  // Admin Navigation
  const adminItems = [
    { id: 'adminDashboard', label: t('adminDashboard', language), icon: LayoutDashboard },
    { id: 'adminFoods', label: 'Food Database', icon: Utensils },
    { id: 'adminUsers', label: t('adminUsers', language), icon: Users },
    { id: 'adminTips', label: t('adminTips', language), icon: Lightbulb },
    { id: 'adminReports', label: t('adminReports', language), icon: FileText },
    { id: 'adminLogs', label: t('adminLogs', language), icon: History },
    { id: 'adminAnalytics', label: t('adminAnalytics', language), icon: TrendingUp },
  ];

  return (
    <nav className="hidden lg:block bg-slate-900 border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-2">
          <div className="flex space-x-1">
            {adminItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`admin-nav-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-bold text-sm transition-all cursor-pointer ${
                    isActive ? 'bg-teal-600 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
          <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2.5 py-1 rounded-full font-mono">
            Admin Console (Protected)
          </span>
        </div>
      </div>
    </nav>
  );
};
