import React, { useState } from 'react';
import {
  Users,
  Pill,
  Calendar,
  Activity,
  Droplets,
  Heart,
  Lock,
  PhoneCall,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  Flame,
  Utensils,
} from 'lucide-react';
import { FamilyPermissions, Language } from '../../types';
import { t } from '../../i18n';

interface CaregiverDashboardViewProps {
  language: Language;
  onOpenEmergency: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const CaregiverDashboardView: React.FC<CaregiverDashboardViewProps> = ({
  language,
  onOpenEmergency,
  onNavigateTab,
}) => {
  // Connected senior demo data
  const senior = {
    id: 'user_senior_1',
    name: 'Connected Senior',
    age: 68,
    relationship: 'Father',
    phone: '+91 98765 43210',
    bloodGroup: 'B+',
    // Caregiver permissions granted by Senior Patient
    permissions: {
      canViewMedicineAdherence: true,
      canViewAppointments: true,
      canViewHealthSummary: true,
      canViewEmergencyInfo: true,
      canViewWaterIntake: false, // Intentionally test denied state!
    },
  };

  const medicines = [
    { name: 'Telmisartan 40mg', time: '08:00 AM', status: 'taken', timing: 'After Breakfast' },
    { name: 'Shelcal 500', time: '01:30 PM', status: 'due', timing: 'After Lunch' },
    { name: 'Metformin 500mg', time: '08:30 PM', status: 'upcoming', timing: 'After Dinner' },
  ];

  const appointments = [
    {
      doctorName: 'Dr. A. K. Joshi',
      clinic: 'City Care Hospital',
      date: '2026-03-25',
      time: '10:30 AM',
      purpose: 'Cardiology 3-Month Followup',
    },
  ];

  const healthReadings = [
    { type: 'Blood Pressure', value: '128/82', unit: 'mmHg', time: 'Today 08:35 AM' },
    { type: 'Fasting Blood Sugar', value: '112', unit: 'mg/dL', time: 'Today 07:45 AM' },
    { type: 'SpO2 Oxygen', value: '98', unit: '%', time: 'Today 08:35 AM' },
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
            Caregiver Console
          </span>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight mt-2">
            Family Care & Health Overview
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Monitoring health vitals and daily routines under senior-granted permissions.
          </p>
        </div>

        <div className="flex gap-2">
          <a
            href={`tel:${senior.phone}`}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
          >
            <PhoneCall className="w-4 h-4 text-teal-600" />
            <span>Call {senior.name}</span>
          </a>
          <button
            id="caregiver-emergency-btn"
            onClick={onOpenEmergency}
            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center space-x-1.5 shadow-md shadow-rose-600/20 cursor-pointer animate-pulse hover:animate-none transition-all"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Emergency Medical Card</span>
          </button>
        </div>
      </div>

      {/* Senior Profile Banner */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white font-black text-xl flex items-center justify-center">
            RP
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="font-display font-bold text-xl text-slate-900">{senior.name}</h3>
              <span className="text-xs font-semibold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full">
                {senior.relationship} (Age {senior.age})
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Phone: {senior.phone} • Blood Group: <strong className="text-rose-600">{senior.bloodGroup}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Dose Status Today:
          </span>
          <span className="px-3.5 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 font-extrabold text-sm">
            All Doses On Schedule
          </span>
        </div>
      </div>

      {/* Permission-Enforced Cards Grid (Section 22) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card 1: Medicine Schedule (Permission-checked) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center space-x-2">
              <Pill className="w-5 h-5 text-teal-700" />
              <h4 className="font-bold text-base text-slate-900">Medicine Schedule & Doses</h4>
            </div>
            <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full">
              Permission Granted
            </span>
          </div>

          {senior.permissions.canViewMedicineAdherence ? (
            <div className="mt-4 space-y-3">
              {medicines.map((med, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                >
                  <div>
                    <p className="font-bold text-sm text-slate-900">{med.name}</p>
                    <p className="text-xs text-slate-500">
                      {med.time} • {med.timing}
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                      med.status === 'taken'
                        ? 'bg-emerald-100 text-emerald-800'
                        : med.status === 'due'
                        ? 'bg-amber-100 text-amber-800 animate-pulse'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {med.status === 'taken' ? '✓ Taken' : med.status === 'due' ? 'Due Soon' : 'Upcoming'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
              <Lock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">Access Restricted</p>
              <p className="text-xs text-slate-500 mt-1">
                {senior.name} has not granted permission to view medication details.
              </p>
            </div>
          )}
        </div>

        {/* Card 2: Upcoming Appointments (Permission-checked) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-indigo-700" />
              <h4 className="font-bold text-base text-slate-900">Upcoming Medical Appointments</h4>
            </div>
            <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full">
              Permission Granted
            </span>
          </div>

          {senior.permissions.canViewAppointments ? (
            <div className="mt-4 space-y-3">
              {appointments.map((appt, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-start justify-between"
                >
                  <div>
                    <h5 className="font-bold text-sm text-slate-900">{appt.doctorName}</h5>
                    <p className="text-xs text-slate-500">{appt.clinic}</p>
                    <p className="text-xs font-semibold text-indigo-700 mt-1">
                      📅 {appt.date} at {appt.time}
                    </p>
                    <p className="text-[11px] text-slate-600 mt-0.5">{appt.purpose}</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-indigo-100 text-indigo-800 text-[11px] font-bold">
                    Scheduled
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
              <Lock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">Access Restricted</p>
              <p className="text-xs text-slate-500 mt-1">
                {senior.name} has not granted permission to view appointments.
              </p>
            </div>
          )}
        </div>

        {/* Card 3: Health Vitals Summary (Permission-checked) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-rose-700" />
              <h4 className="font-bold text-base text-slate-900">Health Vitals Summary</h4>
            </div>
            <span className="text-xs font-semibold text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-full">
              Permission Granted
            </span>
          </div>

          {senior.permissions.canViewHealthSummary ? (
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
              {healthReadings.map((rec, i) => (
                <div key={i} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {rec.type}
                  </span>
                  <p className="font-black text-xl text-slate-900 mt-1">{rec.value}</p>
                  <p className="text-[10px] text-slate-500 font-semibold">{rec.unit}</p>
                  <span className="text-[9px] text-slate-400 block mt-1">{rec.time}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
              <Lock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">Access Restricted</p>
              <p className="text-xs text-slate-500 mt-1">
                {senior.name} has not granted permission to view health vitals.
              </p>
            </div>
          )}
        </div>

        {/* Card 4: Water Intake (Permission-checked - Demonstrates DENIED State!) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center space-x-2">
              <Droplets className="w-5 h-5 text-sky-700" />
              <h4 className="font-bold text-base text-slate-900">Daily Water Intake</h4>
            </div>
            <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
              Permission Denied
            </span>
          </div>

          {senior.permissions.canViewWaterIntake ? (
            <div className="mt-4 p-4 rounded-2xl bg-sky-50 text-sky-900">
              <p className="font-bold text-lg">5 / 8 Glasses (1,250 ml)</p>
            </div>
          ) : (
            <div className="mt-6 p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center">
              <div className="w-12 h-12 rounded-2xl bg-slate-200 text-slate-500 flex items-center justify-center mx-auto mb-3">
                <Lock className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-700">Access Denied by Senior</p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                {senior.name} has maintained privacy over hydration records. Under our sovereign privacy model, only the senior can enable this permission.
              </p>
            </div>
          )}
        </div>

        {/* Card 5: Calorie Counter & Nutrition Monitoring (SSD User Role: Caregiver) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <Flame className="w-5 h-5 text-orange-600" />
                <h4 className="font-bold text-base text-slate-900">Senior Daily Nutrition & Calories</h4>
              </div>
              <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full">
                Active Monitoring
              </span>
            </div>

            <div className="mt-4 space-y-3">
              <div className="p-3.5 rounded-2xl bg-orange-50/60 border border-orange-200/60 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-orange-900">Today's Calorie Budget</span>
                  <p className="text-lg font-black text-slate-900 mt-0.5">1,250 / 1,800 kcal</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-orange-800">550 kcal left</span>
                  <p className="text-[11px] text-slate-500">69% consumed</p>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold">Breakfast</span>
                  <span className="font-bold text-slate-800">350 kcal</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold">Lunch</span>
                  <span className="font-bold text-slate-800">500 kcal</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold">Snacks</span>
                  <span className="font-bold text-slate-800">150 kcal</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold">Dinner</span>
                  <span className="font-bold text-slate-800">250 kcal</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-100 flex justify-between items-center">
            <span className="text-xs text-slate-500">Caregiver Assistance Enabled</span>
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('calorieCounter')}
                className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer"
              >
                <Utensils className="w-3.5 h-3.5" />
                <span>Log or View Nutrition →</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
