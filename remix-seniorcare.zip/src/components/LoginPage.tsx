import React, { useState } from 'react';
import {
  HeartPulse,
  Lock,
  Mail,
  User as UserIcon,
  Phone,
  ShieldCheck,
  AlertCircle,
  CheckCircle,
  Eye,
  EyeOff,
  KeyRound,
  ArrowRight,
  PhoneCall,
  Users,
  Stethoscope,
  ShieldAlert,
  Briefcase,
  Check,
  HelpCircle,
  Sparkles,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { UserRole, Language, User } from '../types';
import { t } from '../i18n';
import { IndianTimeClock } from './IndianTimeClock';

export interface SavedRoleSession {
  role: UserRole;
  name: string;
  email: string;
  phone: string;
  password?: string;
  pinCode?: string;
  lastLoginAt: string;
  workplace: string;
}

const DEFAULT_ROLE_SESSIONS: Record<UserRole, SavedRoleSession> = {
  senior: {
    role: 'senior',
    name: 'Senior Member',
    email: 'senior@seniorcare.org',
    phone: '+91 98765 43210',
    lastLoginAt: '2026-09-28T07:00:00.000Z',
    workplace: 'Senior Wellness Dashboard',
  },
  family: {
    role: 'family',
    name: 'Family Member',
    email: 'family@seniorcare.org',
    phone: '+91 98765 11223',
    lastLoginAt: '2026-09-28T06:30:00.000Z',
    workplace: 'Family Circle Dashboard',
  },
  caregiver: {
    role: 'caregiver',
    name: 'Caregiver Nurse',
    email: 'caregiver@seniorcare.org',
    phone: '+91 98333 44556',
    lastLoginAt: '2026-09-28T06:00:00.000Z',
    workplace: 'Caregiver Clinical Console',
  },
  admin: {
    role: 'admin',
    name: 'System Administrator',
    email: 'admin@seniorcare.org',
    phone: '+91 98111 22334',
    lastLoginAt: '2026-09-28T05:00:00.000Z',
    workplace: 'Administrator Console',
  },
};

const formatTimeAgo = (isoString?: string) => {
  if (!isoString) return 'Recently active';
  try {
    const diffMs = Date.now() - new Date(isoString).getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  } catch (e) {
    return 'Recently';
  }
};

interface LoginPageProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  fontSize: 'normal' | 'large' | 'xlarge';
  onFontSizeChange: (size: 'normal' | 'large' | 'xlarge') => void;
  onLoginSuccess: (user: User) => void;
  onOpenEmergency: () => void;
  onCancel?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  language,
  onLanguageChange,
  fontSize,
  onFontSizeChange,
  onLoginSuccess,
  onOpenEmergency,
  onCancel,
}) => {
  const [role, setRole] = useState<UserRole>('senior');
  const [mode, setMode] = useState<'signin' | 'signup' | 'pin'>('signin');

  // Saved past role login sessions in localStorage to save user time
  const [savedRoleSessions, setSavedRoleSessions] = useState<Record<UserRole, SavedRoleSession>>(() => {
    try {
      const raw = localStorage.getItem('seniorcare_saved_role_sessions');
      if (raw) {
        const parsed = JSON.parse(raw);
        return { ...DEFAULT_ROLE_SESSIONS, ...parsed };
      }
    } catch (e) {}
    return DEFAULT_ROLE_SESSIONS;
  });

  // Role-specific isolated credentials initialized from saved sessions
  const [roleCredentials, setRoleCredentials] = useState<
    Record<UserRole, { name: string; email: string; phone: string; password: string }>
  >(() => {
    try {
      const raw = localStorage.getItem('seniorcare_saved_role_sessions');
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          senior: {
            name: parsed.senior?.name || DEFAULT_ROLE_SESSIONS.senior.name,
            email: parsed.senior?.email || DEFAULT_ROLE_SESSIONS.senior.email,
            phone: parsed.senior?.phone || DEFAULT_ROLE_SESSIONS.senior.phone,
            password: parsed.senior?.password || '',
          },
          family: {
            name: parsed.family?.name || DEFAULT_ROLE_SESSIONS.family.name,
            email: parsed.family?.email || DEFAULT_ROLE_SESSIONS.family.email,
            phone: parsed.family?.phone || DEFAULT_ROLE_SESSIONS.family.phone,
            password: parsed.family?.password || '',
          },
          caregiver: {
            name: parsed.caregiver?.name || DEFAULT_ROLE_SESSIONS.caregiver.name,
            email: parsed.caregiver?.email || DEFAULT_ROLE_SESSIONS.caregiver.email,
            phone: parsed.caregiver?.phone || DEFAULT_ROLE_SESSIONS.caregiver.phone,
            password: parsed.caregiver?.password || '',
          },
          admin: {
            name: parsed.admin?.name || DEFAULT_ROLE_SESSIONS.admin.name,
            email: parsed.admin?.email || DEFAULT_ROLE_SESSIONS.admin.email,
            phone: parsed.admin?.phone || DEFAULT_ROLE_SESSIONS.admin.phone,
            password: parsed.admin?.password || '',
          },
        };
      }
    } catch (e) {}
    return {
      senior: { ...DEFAULT_ROLE_SESSIONS.senior, password: '' },
      family: { ...DEFAULT_ROLE_SESSIONS.family, password: '' },
      caregiver: { ...DEFAULT_ROLE_SESSIONS.caregiver, password: '' },
      admin: { ...DEFAULT_ROLE_SESSIONS.admin, password: '' },
    };
  });

  const currentCreds = roleCredentials[role] || {
    name: DEFAULT_ROLE_SESSIONS[role]?.name || '',
    email: DEFAULT_ROLE_SESSIONS[role]?.email || '',
    phone: DEFAULT_ROLE_SESSIONS[role]?.phone || '',
    password: '',
  };
  const name = currentCreds.name;
  const email = currentCreds.email;
  const phone = currentCreds.phone;
  const password = currentCreds.password;

  // Persists a role's session to localStorage and component state
  const saveRoleSession = (targetRole: UserRole, sessionData: Partial<SavedRoleSession>) => {
    const fallback = DEFAULT_ROLE_SESSIONS[targetRole];
    const prevSession = savedRoleSessions[targetRole] || fallback;
    const updatedSession: SavedRoleSession = {
      role: targetRole,
      name: sessionData.name || prevSession.name,
      email: sessionData.email || prevSession.email,
      phone: sessionData.phone || prevSession.phone,
      password: sessionData.password !== undefined ? sessionData.password : prevSession.password,
      pinCode: sessionData.pinCode || prevSession.pinCode,
      lastLoginAt: sessionData.lastLoginAt || new Date().toISOString(),
      workplace: fallback.workplace,
    };

    setSavedRoleSessions((prev) => {
      const updated = { ...prev, [targetRole]: updatedSession };
      try {
        localStorage.setItem('seniorcare_saved_role_sessions', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    setRoleCredentials((prev) => ({
      ...prev,
      [targetRole]: {
        name: updatedSession.name,
        email: updatedSession.email,
        phone: updatedSession.phone,
        password: updatedSession.password || '',
      },
    }));
  };

  const updateField = (field: 'name' | 'email' | 'phone' | 'password', value: string) => {
    setRoleCredentials((prev) => {
      const updated = {
        ...prev,
        [role]: {
          ...prev[role],
          [field]: value,
        },
      };

      // Persist draft to savedRoleSessions in localStorage so returning to this tab remembers what was typed
      try {
        const raw = localStorage.getItem('seniorcare_saved_role_sessions');
        const parsed = raw ? JSON.parse(raw) : {};
        parsed[role] = {
          ...(parsed[role] || DEFAULT_ROLE_SESSIONS[role]),
          role,
          [field]: value,
          lastLoginAt: new Date().toISOString(),
        };
        localStorage.setItem('seniorcare_saved_role_sessions', JSON.stringify(parsed));
      } catch (e) {}

      return updated;
    });
  };

  const [pinCode, setPinCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Status & Feedback
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Metadata for all 4 roles that can log in through this single page
  const roles = [
    {
      id: 'senior' as UserRole,
      title: 'Senior Citizen',
      titleLocal: language === 'hi' ? 'वरिष्ठ नागरिक' : language === 'mr' ? 'ज्येष्ठ नागरिक' : 'Senior Citizen',
      subtitle: 'Senior Wellness & Pill Reminders',
      desc: 'Large readable text, pill reminder alerts, water tracker & 1-tap SOS distress button.',
      icon: UserIcon,
      color: 'teal',
      badge: 'Senior Hub',
      badgeClass: 'bg-teal-500/20 text-teal-300 border-teal-500/40',
      activeTabClass: 'border-teal-400 bg-teal-500/15 text-white ring-1 ring-teal-400/50',
      workplace: 'Senior Wellness Dashboard',
      defaultName: 'Senior Member',
      defaultEmail: 'senior@seniorcare.org',
    },
    {
      id: 'family' as UserRole,
      title: 'Family Member',
      titleLocal: language === 'hi' ? 'परिवार सदस्य' : language === 'mr' ? 'कुटुंब सदस्य' : 'Family Member',
      subtitle: 'Family Circle & Oversight',
      desc: 'Monitor senior health vitals in real time, track pill compliance & coordinate doctor appointments.',
      icon: Users,
      color: 'indigo',
      badge: 'Family Portal',
      badgeClass: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
      activeTabClass: 'border-indigo-400 bg-indigo-500/15 text-white ring-1 ring-indigo-400/50',
      workplace: 'Family Circle Dashboard',
      defaultName: 'Family Member',
      defaultEmail: 'family@seniorcare.org',
    },
    {
      id: 'caregiver' as UserRole,
      title: 'Caregiver / Nurse',
      titleLocal: language === 'hi' ? 'देखभालकर्ता / नर्स' : language === 'mr' ? 'काळजीवाहक / नर्स' : 'Caregiver / Nurse',
      subtitle: 'Clinical Care & Patients',
      desc: 'Access patient roster, record blood pressure & glucose vitals, administer medications & write notes.',
      icon: Stethoscope,
      color: 'emerald',
      badge: 'Caregiver Console',
      badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      activeTabClass: 'border-emerald-400 bg-emerald-500/15 text-white ring-1 ring-emerald-400/50',
      workplace: 'Caregiver Clinical Console',
      defaultName: 'Caregiver Nurse',
      defaultEmail: 'caregiver@seniorcare.org',
    },
    {
      id: 'admin' as UserRole,
      title: 'Administrator',
      titleLocal: language === 'hi' ? 'व्यवस्थापक' : language === 'mr' ? 'प्रशासक' : 'Administrator',
      subtitle: 'System & Facility Operations',
      desc: 'Staff directories, emergency protocol audit trails, safety compliance & comprehensive care reporting.',
      icon: ShieldAlert,
      color: 'amber',
      badge: 'Admin Console',
      badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      activeTabClass: 'border-amber-400 bg-amber-500/15 text-white ring-1 ring-amber-400/50',
      workplace: 'Administrator Console',
      defaultName: 'System Administrator',
      defaultEmail: 'admin@seniorcare.org',
    },
  ];

  const currentRole = roles.find((r) => r.id === role) || roles[0];
  const activeSavedSession = savedRoleSessions[role];

  // 1-Click Fast Resume of Past Saved Role Session
  const handleResumePastLogin = async (targetRole: UserRole) => {
    const session = savedRoleSessions[targetRole] || DEFAULT_ROLE_SESSIONS[targetRole];
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: session.name,
          email: session.email,
          phone: session.phone,
          password: session.password || 'standardPass123',
          role: targetRole,
          language,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Login failed');
      }

      const loggedUser: User = {
        ...data.user,
        name: session.name,
        email: session.email,
        phone: session.phone || data.user.phone,
        role: targetRole,
      };

      saveRoleSession(targetRole, {
        name: session.name,
        email: session.email,
        phone: session.phone,
        lastLoginAt: new Date().toISOString(),
      });

      setSuccessMsg(`Welcome back, ${loggedUser.name}! Opening ${session.workplace}...`);
      setTimeout(() => {
        onLoginSuccess(loggedUser);
      }, 400);
    } catch (err: any) {
      setError(err.message || 'Authentication error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // 1-Click Fast Login for any role directly from this single page
  const handleQuickLogin = async (targetRole: UserRole) => {
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    const roleInfo = roles.find((r) => r.id === targetRole) || roles[0];
    const session = savedRoleSessions[targetRole] || DEFAULT_ROLE_SESSIONS[targetRole];
    const targetName = session.name || roleInfo.defaultName;
    const targetEmail = session.email || roleInfo.defaultEmail;

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: targetName,
          email: targetEmail,
          password: session.password || 'standardPass123',
          role: targetRole,
          language,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Login failed');
      }

      const loggedUser: User = {
        ...data.user,
        name: targetName,
        email: targetEmail,
        role: targetRole,
      };

      saveRoleSession(targetRole, {
        name: targetName,
        email: targetEmail,
        phone: session.phone,
        lastLoginAt: new Date().toISOString(),
      });

      setSuccessMsg(`Logged in as ${loggedUser.name}! Opening ${roleInfo.workplace}...`);
      setTimeout(() => {
        onLoginSuccess(loggedUser);
      }, 450);
    } catch (err: any) {
      setError(err.message || 'Authentication error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Senior 4-digit PIN dialer
  const handlePinDigit = (digit: string) => {
    if (pinCode.length < 4) {
      setPinCode((prev) => prev + digit);
    }
  };

  const handlePinBackspace = () => {
    setPinCode((prev) => prev.slice(0, -1));
  };

  // Standard Form Submit (Personalized login with user credentials)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (mode === 'signup') {
        if (!name.trim()) throw new Error('Please enter your full name');
        if (!email.trim() && !phone.trim()) throw new Error('Please enter your email or mobile number');

        const resolvedSignupEmail = email.trim() || `${name.trim().toLowerCase().replace(/\s+/g, '.')}@seniorcare.org`;

        const res = await fetch('/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: name.trim(),
            email: resolvedSignupEmail,
            phone: phone.trim(),
            role,
            language,
          }),
        });

        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.message || 'Account registration failed');
        }

        const newUser: User = {
          ...data.user,
          name: name.trim(),
          email: resolvedSignupEmail,
          role,
        };

        saveRoleSession(role, {
          name: newUser.name,
          email: newUser.email,
          phone: newUser.phone,
          password: password || '',
          lastLoginAt: new Date().toISOString(),
        });

        setSuccessMsg(`Welcome, ${newUser.name}! Your account has been registered.`);
        setTimeout(() => {
          onLoginSuccess(newUser);
        }, 500);
        return;
      }

      // PIN Mode (Senior)
      if (mode === 'pin') {
        if (pinCode.length !== 4) throw new Error('Please enter a 4-digit numeric PIN');

        const resolvedName = name.trim() || activeSavedSession?.name || 'Senior Member';
        const resolvedEmail = email.trim() || activeSavedSession?.email || 'senior@seniorcare.org';

        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: resolvedName,
            email: resolvedEmail,
            password: `pin-${pinCode}`,
            role: 'senior',
            language,
            pin: pinCode,
          }),
        });

        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.message || 'Invalid PIN code');
        }

        const loggedUser: User = {
          ...data.user,
          name: resolvedName,
          email: resolvedEmail,
          role: 'senior',
        };

        saveRoleSession('senior', {
          name: resolvedName,
          email: resolvedEmail,
          pinCode,
          lastLoginAt: new Date().toISOString(),
        });

        setSuccessMsg(`Welcome, ${loggedUser.name}! Opening your Senior Hub...`);
        setTimeout(() => {
          onLoginSuccess(loggedUser);
        }, 450);
        return;
      }

      // Standard Login Mode
      const displayName = name.trim() || currentRole.defaultName;
      const submitEmail = email.trim() || currentRole.defaultEmail;

      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: displayName,
          email: submitEmail,
          phone: phone.trim(),
          password: password || 'customPass123',
          role,
          language,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Login failed. Please check your credentials.');
      }

      const loggedUser: User = {
        ...data.user,
        name: displayName,
        email: submitEmail,
        role,
      };

      saveRoleSession(role, {
        name: displayName,
        email: submitEmail,
        phone: phone.trim() || currentCreds.phone,
        password: password || '',
        lastLoginAt: new Date().toISOString(),
      });

      setSuccessMsg(`Welcome, ${loggedUser.name}! Loading ${currentRole.workplace}...`);
      setTimeout(() => {
        onLoginSuccess(loggedUser);
      }, 450);
    } catch (err: any) {
      setError(err.message || 'An error occurred during authentication');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8">
      {/* Top Header: Logo, Language, Accessibility & Emergency SOS */}
      <header className="max-w-6xl w-full mx-auto flex items-center justify-between py-2">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400/30 flex items-center justify-center text-teal-300 shadow-lg shadow-teal-500/10 backdrop-blur-md">
            <HeartPulse className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-display font-extrabold text-2xl tracking-tight text-white">
                SeniorCare
              </span>
              <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-teal-500/20 text-teal-300 border border-teal-400/30">
                Universal Login
              </span>
            </div>
            <p className="text-xs text-slate-400">
              One Single Sign In for Seniors, Families, Caregivers & Administrators
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Live Indian Standard Time */}
          <IndianTimeClock language={language} compact={true} />

          {/* Language Switcher */}
          <div className="flex items-center bg-slate-800/80 border border-slate-700 rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => onLanguageChange('en')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                language === 'en' ? 'bg-teal-500 text-slate-950' : 'text-slate-300 hover:text-white'
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => onLanguageChange('hi')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                language === 'hi' ? 'bg-teal-500 text-slate-950' : 'text-slate-300 hover:text-white'
              }`}
            >
              हिन्दी
            </button>
            <button
              type="button"
              onClick={() => onLanguageChange('mr')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                language === 'mr' ? 'bg-teal-500 text-slate-950' : 'text-slate-300 hover:text-white'
              }`}
            >
              मराठी
            </button>
          </div>

          {/* Text Size & Legibility Magnifier */}
          <div className="hidden sm:flex items-center bg-slate-800/80 border border-slate-700 rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => onFontSizeChange('normal')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                fontSize === 'normal' ? 'bg-teal-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
              title="Standard Size (16px)"
              aria-label="Standard Font Size (16px)"
            >
              A
            </button>
            <button
              type="button"
              onClick={() => onFontSizeChange('large')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                fontSize === 'large' ? 'bg-teal-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
              title="Large Size (18px) - Recommended for Seniors"
              aria-label="Large Font Size (18px)"
            >
              A+
            </button>
            <button
              type="button"
              onClick={() => onFontSizeChange('xlarge')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                fontSize === 'xlarge' ? 'bg-teal-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
              title="Extra Large (20px) - High Contrast"
              aria-label="Extra Large Font Size (20px)"
            >
              A++
            </button>
          </div>

          {/* Emergency SOS Immediate Access */}
          <button
            type="button"
            onClick={onOpenEmergency}
            className="flex items-center space-x-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-xs sm:text-sm shadow-lg shadow-rose-900/40 transition cursor-pointer animate-pulse"
          >
            <PhoneCall className="w-4 h-4" />
            <span>SOS</span>
          </button>

          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-3.5 py-2 text-xs font-bold text-slate-300 hover:text-white bg-slate-800/80 rounded-xl border border-slate-700 cursor-pointer"
            >
              Back
            </button>
          )}
        </div>
      </header>

      {/* Main Login Card Experience */}
      <main className="max-w-6xl w-full mx-auto my-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        {/* Left Column: Multi-Role Care Sanctuary Information */}
        <div className="lg:col-span-5 bg-gradient-to-b from-teal-900/40 via-slate-900/60 to-slate-900/90 border border-teal-500/20 rounded-3xl p-6 sm:p-8 flex flex-col justify-between backdrop-blur-xl shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-bold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>One Login • All 4 Care Roles</span>
            </div>

            <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-white leading-tight mb-3">
              One Single Login for Every Role.
            </h1>

            <p className="text-slate-300 text-sm leading-relaxed mb-6">
              Every member of the healthcare ecosystem logs in right here. Select your role or click your 1-tap work pass to enter your dedicated console.
            </p>

            {/* Role Breakdown in List */}
            <div className="space-y-2.5">
              {roles.map((r) => {
                const Icon = r.icon;
                const isCurrent = role === r.id;
                return (
                  <div
                    key={r.id}
                    onClick={() => {
                      setRole(r.id);
                      if (r.id !== 'senior' && mode === 'pin') setMode('signin');
                    }}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start space-x-3 ${
                      isCurrent
                        ? `${r.activeTabClass} shadow-md`
                        : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/80 text-slate-300'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                      <Icon className="w-5 h-5 text-teal-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-white">{r.title}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${r.badgeClass}`}>
                          {r.badge}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5 leading-snug truncate">
                        {r.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Trust Badge */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-teal-400" />
              <span>HIPAA Encrypted Healthcare System</span>
            </div>
            <span className="text-[11px] font-mono text-teal-400/80">Active</span>
          </div>
        </div>

        {/* Right Column: 1-Click Role Logins & Credential Sign In Form */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col justify-between">
          <div>
            {/* 1-Click Fast Role Sign In Bar */}
            <div className="mb-5 pb-5 border-b border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Briefcase className="w-4 h-4 text-teal-400" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    ⚡ 1-Click Instant Work Login
                  </span>
                </div>
                <span className="text-[11px] text-slate-400">Direct role pass</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {roles.map((r) => {
                  const Icon = r.icon;
                  const saved = savedRoleSessions[r.id];
                  const hasCustomSave = saved && saved.name && saved.name !== r.defaultName;
                  return (
                    <button
                      key={r.id}
                      type="button"
                      disabled={loading}
                      onClick={() => handleQuickLogin(r.id)}
                      className="p-2.5 rounded-2xl bg-slate-800/80 hover:bg-teal-900/40 border border-slate-700 hover:border-teal-400/50 text-left transition-all cursor-pointer group shadow-sm disabled:opacity-60 flex flex-col justify-between"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="p-1 rounded-lg bg-teal-500/20 text-teal-300">
                          <Icon className="w-3.5 h-3.5" />
                        </span>
                        <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-teal-300 transition-transform group-hover:translate-x-0.5" />
                      </div>
                      <div className="font-bold text-xs text-white group-hover:text-teal-200 leading-tight truncate">
                        {saved?.name || r.title}
                      </div>
                      <div className="text-[9px] text-teal-400/80 mt-0.5 font-medium truncate">
                        {hasCustomSave ? `Saved: ${saved.name.split(' ')[0]}` : `Log in as ${r.badge}`}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Select Role for Custom Login */}
            <div className="mb-4">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Step 1: Choose Your Role to Sign In
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {roles.map((r) => {
                  const Icon = r.icon;
                  const isSelected = role === r.id;
                  const saved = savedRoleSessions[r.id];
                  return (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => {
                        setRole(r.id);
                        if (r.id !== 'senior' && mode === 'pin') setMode('signin');
                      }}
                      className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? r.activeTabClass
                          : 'bg-slate-800/40 border-slate-700/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-teal-400' : 'text-slate-400'}`} />
                        {isSelected && <Check className="w-3.5 h-3.5 text-teal-400 font-bold" />}
                      </div>
                      <div>
                        <div className="font-bold text-xs text-slate-200 leading-tight truncate">
                          {r.title}
                        </div>
                        <div className="text-[10px] text-teal-300 font-semibold truncate mt-0.5">
                          {saved?.name ? `✓ ${saved.name.split(' ')[0]}` : r.badge}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sign In Mode Switcher: Standard vs PIN (Senior) vs Create Account */}
            <div className="flex items-center justify-between pb-3.5 border-b border-slate-800 mb-4">
              <div className="flex space-x-1.5 bg-slate-800/80 p-1 rounded-xl border border-slate-700">
                <button
                  type="button"
                  onClick={() => {
                    setMode('signin');
                    setError(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    mode === 'signin'
                      ? 'bg-teal-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Standard Sign In
                </button>

                {role === 'senior' && (
                  <button
                    type="button"
                    onClick={() => {
                      setMode('pin');
                      setError(null);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center space-x-1 ${
                      mode === 'pin'
                        ? 'bg-teal-500 text-slate-950 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <KeyRound className="w-3 h-3" />
                    <span>4-Digit PIN</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setMode('signup');
                    setError(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    mode === 'signup'
                      ? 'bg-teal-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Create Account
                </button>
              </div>

              <span className="text-[11px] text-teal-400 font-semibold hidden sm:inline">
                Opening: {currentRole.workplace}
              </span>
            </div>

            {/* Saved Past Role Login Session Card */}
            {activeSavedSession && (
              <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-teal-950/80 via-slate-900 to-slate-900 border border-teal-500/40 flex items-center justify-between gap-3 shadow-lg">
                <div className="flex items-center space-x-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300 flex items-center justify-center font-bold text-base shrink-0 shadow-inner">
                    {activeSavedSession.name.charAt(0) || 'U'}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-teal-300 flex items-center">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block mr-1.5 animate-pulse"></span>
                        Past Login Saved
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">
                        • {formatTimeAgo(activeSavedSession.lastLoginAt)}
                      </span>
                    </div>
                    <p className="text-sm font-bold text-white truncate">{activeSavedSession.name}</p>
                    <p className="text-xs text-slate-300 truncate">
                      {activeSavedSession.email || activeSavedSession.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => handleResumePastLogin(role)}
                    className="px-3.5 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 active:scale-95 text-slate-950 font-bold text-xs cursor-pointer shadow-md transition flex items-center space-x-1.5 disabled:opacity-50"
                    title={`Instantly sign in as ${activeSavedSession.name}`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Resume</span>
                  </button>
                </div>
              </div>
            )}

            {/* Error & Success Messages */}
            {error && (
              <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-200 text-xs font-semibold flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-200 text-xs font-semibold flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Authentication Form */}
            <form onSubmit={handleSubmit} className="space-y-3.5">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                  Full Name {mode === 'signup' && <span className="text-teal-400">*</span>}
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required={mode === 'signup'}
                    value={name}
                    onChange={(e) => updateField('name', e.target.value)}
                    placeholder={
                      role === 'senior'
                        ? 'e.g. Senior Member'
                        : role === 'family'
                        ? 'e.g. Family Member'
                        : role === 'caregiver'
                        ? 'e.g. Caregiver Nurse'
                        : 'e.g. System Administrator'
                    }
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:border-teal-400 focus:ring-1 focus:ring-teal-400/20 focus:outline-hidden transition"
                  />
                </div>
              </div>

              {/* Email & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={email}
                      onChange={(e) => updateField('email', e.target.value)}
                      placeholder={
                        role === 'admin'
                          ? 'admin@seniorcare.org'
                          : role === 'caregiver'
                          ? 'caregiver@seniorcare.org'
                          : role === 'family'
                          ? 'family@seniorcare.org'
                          : 'senior@seniorcare.org'
                      }
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:border-teal-400 focus:ring-1 focus:ring-teal-400/20 focus:outline-hidden transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Mobile Phone
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => updateField('phone', e.target.value)}
                      placeholder="+91 98765 00000"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:border-teal-400 focus:ring-1 focus:ring-teal-400/20 focus:outline-hidden transition"
                    />
                  </div>
                </div>
              </div>

              {/* Password */}
              {mode !== 'pin' && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                      {mode === 'signup' ? 'Set Password' : 'Password'}
                    </label>
                    {role === 'senior' && (
                      <button
                        type="button"
                        onClick={() => setMode('pin')}
                        className="text-xs text-teal-400 hover:text-teal-300 font-semibold cursor-pointer"
                      >
                        Use 4-Digit PIN instead?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => updateField('password', e.target.value)}
                      placeholder="Enter your security password"
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:border-teal-400 focus:ring-1 focus:ring-teal-400/20 focus:outline-hidden transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-white cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}

              {/* 4-Digit PIN dial pad for Senior Citizens */}
              {mode === 'pin' && (
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-teal-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-teal-300 uppercase tracking-wider flex items-center space-x-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-teal-400" />
                      <span>Enter Senior 4-Digit PIN</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setPinCode('')}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      Clear
                    </button>
                  </div>

                  <div className="flex justify-center space-x-2.5 mb-3">
                    {[0, 1, 2, 3].map((idx) => {
                      const hasVal = pinCode.length > idx;
                      return (
                        <div
                          key={idx}
                          className={`w-10 h-12 rounded-xl border-2 flex items-center justify-center font-mono text-xl font-extrabold transition-all ${
                            hasVal
                              ? 'border-teal-400 bg-teal-500/20 text-teal-300 shadow-md shadow-teal-500/20'
                              : 'border-slate-700 bg-slate-850 text-slate-600'
                          }`}
                        >
                          {hasVal ? '●' : '—'}
                        </div>
                      );
                    })}
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 max-w-[240px] mx-auto">
                    {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                      <button
                        key={digit}
                        type="button"
                        onClick={() => handlePinDigit(digit)}
                        className="py-2.5 bg-slate-800 hover:bg-teal-600 active:bg-teal-700 hover:text-slate-950 font-extrabold text-base text-white rounded-lg border border-slate-700 transition cursor-pointer"
                      >
                        {digit}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setPinCode('')}
                      className="py-2.5 bg-slate-800 hover:bg-slate-700 font-bold text-xs text-slate-400 rounded-lg border border-slate-700 transition cursor-pointer"
                    >
                      Clear
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePinDigit('0')}
                      className="py-2.5 bg-slate-800 hover:bg-teal-600 active:bg-teal-700 hover:text-slate-950 font-extrabold text-base text-white rounded-lg border border-slate-700 transition cursor-pointer"
                    >
                      0
                    </button>
                    <button
                      type="button"
                      onClick={handlePinBackspace}
                      className="py-2.5 bg-slate-800 hover:bg-slate-700 font-bold text-xs text-rose-300 rounded-lg border border-slate-700 transition cursor-pointer"
                    >
                      ⌫
                    </button>
                  </div>
                </div>
              )}

              {/* Remember me & assistance */}
              <div className="flex items-center justify-between pt-1 text-xs">
                <label className="flex items-center space-x-2 text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded-sm border-slate-700 text-teal-500 focus:ring-teal-400"
                  />
                  <span>Remember login on this computer</span>
                </label>

                {mode === 'signin' && (
                  <button
                    type="button"
                    onClick={() => {
                      setSuccessMsg('Account recovery instructions sent to your registered email or phone.');
                    }}
                    className="text-teal-400 hover:text-teal-300 font-semibold cursor-pointer"
                  >
                    Need Help?
                  </button>
                )}
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 bg-gradient-to-r from-teal-500 via-emerald-500 to-teal-400 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-extrabold text-sm sm:text-base rounded-xl shadow-lg shadow-teal-500/25 transition-all transform hover:scale-[1.01] active:scale-[0.99] cursor-pointer flex items-center justify-center space-x-2 disabled:opacity-60"
                >
                  {loading ? (
                    <span>Authenticating...</span>
                  ) : (
                    <>
                      <span>
                        {mode === 'signup'
                          ? `Register & Open ${currentRole.title} Console`
                          : mode === 'pin'
                          ? `Sign In with PIN as ${currentRole.title}`
                          : `Log In to ${currentRole.title} Workspace`}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Privacy Footnote */}
          <div className="mt-5 pt-3.5 border-t border-slate-800 text-center text-xs text-slate-400 flex items-center justify-center space-x-2">
            <HelpCircle className="w-3.5 h-3.5 text-teal-400" />
            <span>
              Unified single sign-in for all healthcare roles. Role permissions enforce secure medical access.
            </span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-6xl w-full mx-auto text-center py-2 text-xs text-slate-400">
        SeniorCare Medical & Caregiver Network • Single Universal Sign In
      </footer>
    </div>
  );
};
