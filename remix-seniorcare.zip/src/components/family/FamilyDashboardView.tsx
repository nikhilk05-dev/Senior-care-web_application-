import React, { useState } from 'react';
import {
  HeartPulse,
  Pill,
  Droplets,
  Calendar,
  AlertTriangle,
  PhoneCall,
  MessageCircle,
  FileText,
  ShoppingBag,
  Truck,
  Stethoscope,
  Activity,
  CheckCircle2,
  Clock,
  Plus,
  ShieldCheck,
  Send,
  Sparkles,
  MapPin,
  ExternalLink,
  ChevronRight,
  UserCheck,
  Flame,
  Utensils,
} from 'lucide-react';
import {
  User,
  Medicine,
  HealthRecord,
  Appointment,
  WaterDay,
  ServiceRequest,
  EmergencyAlert,
  MedicalDocument,
  DirectMessage,
  ServiceType,
  Language,
} from '../../types';

interface FamilyDashboardViewProps {
  seniorUser: User;
  familyUser: User;
  medicines: Medicine[];
  healthRecords: HealthRecord[];
  appointments: Appointment[];
  waterToday: WaterDay;
  serviceRequests: ServiceRequest[];
  emergencyAlerts: EmergencyAlert[];
  medicalDocuments: MedicalDocument[];
  messages: DirectMessage[];
  language: Language;
  onSendServiceRequest: (service: Partial<ServiceRequest>) => void;
  onSendMessage: (receiverId: string, receiverName: string, text: string) => void;
  onNavigateTab: (tab: string) => void;
  onOpenEmergency: () => void;
}

export const FamilyDashboardView: React.FC<FamilyDashboardViewProps> = ({
  seniorUser,
  familyUser,
  medicines,
  healthRecords,
  appointments,
  waterToday,
  serviceRequests,
  emergencyAlerts,
  medicalDocuments,
  messages,
  language,
  onSendServiceRequest,
  onSendMessage,
  onNavigateTab,
  onOpenEmergency,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'services' | 'messages' | 'documents'>('overview');
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [chatRecipient, setChatRecipient] = useState<'senior' | 'caregiver'>('senior');
  const [chatInput, setChatInput] = useState('');

  // Service modal form state
  const [serviceType, setServiceType] = useState<ServiceType>('medicine_delivery');
  const [serviceTitle, setServiceTitle] = useState('');
  const [serviceDescription, setServiceDescription] = useState('');
  const [servicePriority, setServicePriority] = useState<'normal' | 'urgent'>('normal');
  const [serviceDate, setServiceDate] = useState(new Date().toISOString().split('T')[0]);

  // Vitals calculation
  const latestBP = healthRecords.find((r) => r.type === 'blood_pressure');
  const latestSugar = healthRecords.find((r) => r.type === 'blood_sugar');
  const latestHR = healthRecords.find((r) => r.type === 'heart_rate');
  const latestO2 = healthRecords.find((r) => r.type === 'oxygen');
  const latestWeight = healthRecords.find((r) => r.type === 'weight');
  const latestTemp = healthRecords.find((r) => r.type === 'temperature');

  // Medicines summary
  const allSchedules = medicines.flatMap((m) =>
    (m.schedules || []).map((s) => ({ ...s, medicine: m }))
  );
  const takenCount = allSchedules.filter((s) => s.status === 'taken').length;
  const missedCount = allSchedules.filter((s) => s.status === 'missed').length;
  const pendingCount = allSchedules.filter((s) => s.status === 'due' || s.status === 'upcoming').length;

  // Active SOS alert if any
  const activeSOS = emergencyAlerts.find((a) => a.status === 'active' || a.status === 'acknowledged');

  const handleCreateService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceTitle) return;

    onSendServiceRequest({
      seniorId: seniorUser.id,
      seniorName: seniorUser.name,
      serviceType,
      title: serviceTitle,
      description: serviceDescription,
      requestedDate: serviceDate,
      priority: servicePriority,
    });

    setServiceTitle('');
    setServiceDescription('');
    setShowServiceModal(false);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const receiverId = chatRecipient === 'senior' ? seniorUser.id : 'user_caregiver_1';
    const receiverName = chatRecipient === 'senior' ? seniorUser.name : 'Sister Sunita Rao (Caregiver)';

    onSendMessage(receiverId, receiverName, chatInput.trim());
    setChatInput('');
  };

  // Filter messages for current thread
  const currentChatMessages = messages.filter((m) => {
    if (chatRecipient === 'senior') {
      return (
        (m.senderId === familyUser.id && m.receiverId === seniorUser.id) ||
        (m.senderId === seniorUser.id && m.receiverId === familyUser.id)
      );
    } else {
      return (
        (m.senderId === familyUser.id && m.receiverId === 'user_caregiver_1') ||
        (m.senderId === 'user_caregiver_1' && m.receiverId === familyUser.id)
      );
    }
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner: Remote Senior Status Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-display font-black text-2xl shadow-md shadow-teal-700/20">
              {seniorUser.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center space-x-3">
                <h1 className="font-display font-black text-2xl sm:text-3xl text-slate-900">
                  {seniorUser.name}
                </h1>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center space-x-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
                  <span>Safe & Monitored</span>
                </span>
              </div>
              <p className="text-slate-600 text-sm mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                <span>Age: <strong>{seniorUser.age || 68} yrs</strong></span>
                <span>•</span>
                <span>Blood: <strong>{seniorUser.bloodGroup || 'B+'}</strong></span>
                <span>•</span>
                <span className="flex items-center space-x-1 text-slate-500">
                  <MapPin className="w-3.5 h-3.5 text-teal-600" />
                  <span>Model Colony, Pune</span>
                </span>
                <span>•</span>
                <span>Caregiver: <strong>Sister Sunita Rao</strong></span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href={`tel:${seniorUser.phone}`}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 font-bold text-sm flex items-center space-x-2 transition"
            >
              <PhoneCall className="w-4 h-4 text-teal-700" />
              <span>Call Papa</span>
            </a>
            <button
              onClick={() => {
                setActiveSubTab('services');
                setShowServiceModal(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-sm flex items-center space-x-2 transition cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Order Eldercare Service</span>
            </button>
          </div>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="flex space-x-2 mt-6 pt-6 border-t border-slate-100 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('overview')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'overview'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Health & Medication Overview
          </button>
          <button
            onClick={() => setActiveSubTab('services')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'services'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Eldercare Services ({serviceRequests.length})
          </button>
          <button
            onClick={() => setActiveSubTab('messages')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'messages'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Family & Caregiver Chat
          </button>
          <button
            onClick={() => setActiveSubTab('documents')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'documents'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Medical Vault ({medicalDocuments.length})
          </button>
        </div>
      </div>

      {/* EMERGENCY SOS ALERT BANNER (If Active) */}
      {activeSOS && (
        <div className="bg-rose-50 border-2 border-rose-400 rounded-3xl p-6 shadow-lg shadow-rose-200 animate-pulse">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0">
                <AlertTriangle className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-xl font-black text-rose-900">
                  CRITICAL EMERGENCY SOS TRIGGERED BY {seniorUser.name.toUpperCase()}
                </h2>
                <p className="text-sm text-rose-700 mt-1 font-medium">
                  Triggered at {new Date(activeSOS.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Location: {activeSOS.address}
                </p>
                <div className="flex items-center space-x-2 mt-2">
                  <span className="px-2.5 py-1 rounded-md text-xs font-extrabold bg-rose-200 text-rose-900 uppercase">
                    Status: {activeSOS.status}
                  </span>
                  <span className="text-xs text-rose-800">
                    Ambulance & Care Attendant dispatched
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <a
                href={`tel:${seniorUser.phone}`}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-sm"
              >
                Call Senior Now
              </a>
              <a
                href="tel:108"
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-sm"
              >
                Call 108 Ambulance
              </a>
            </div>
          </div>
        </div>
      )}

      {/* MISSED MEDICINE ESCALATION WARNING (Section 18) */}
      {missedCount > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-3xl p-5 shadow-xs">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">
                  Missed Medication Escalation Alert
                </h3>
                <p className="text-sm text-slate-600">
                  {missedCount} scheduled dose was not confirmed taken on time today. An automated escalation alert has been dispatched.
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  setActiveSubTab('messages');
                  setChatRecipient('senior');
                  setChatInput('Papa, please remember to take your pending medicine with a glass of water.');
                }}
                className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer shadow-xs"
              >
                Send Gentle Nudge
              </button>
              <a
                href="tel:+919833344556"
                className="px-3.5 py-2 rounded-xl bg-white border border-amber-300 text-amber-900 hover:bg-amber-100 font-bold text-xs"
              >
                Call Caregiver
              </a>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 1. OVERVIEW */}
      {activeSubTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Vitals Snapshot with Normal Count Brackets */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    Blood Pressure
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
                    <HeartPulse className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                    {latestBP?.value || '120/80'}
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">mmHg</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200 mt-2 block">
                (Normal: 120/80 mmHg | Required: 90/60 – 120/80)
              </span>
            </div>

            <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    Blood Sugar
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center">
                    <Activity className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                    {latestSugar?.value || '110'}
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">mg/dL</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200 mt-2 block">
                (Normal: 70–140 mg/dL | Fasting: 70–99)
              </span>
            </div>

            <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    SpO2 Oxygen
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-cyan-100 text-cyan-700 flex items-center justify-center">
                    <Activity className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                    {latestO2?.value || '98'}
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">%</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200 mt-2 block">
                (Normal: 95%–100% | Required: ≥95%)
              </span>
            </div>

            <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    Heart Rate (Health Rate)
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
                    <Activity className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                    {latestHR?.value || '72'}
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">BPM</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200 mt-2 block">
                (Normal: 60–100 bpm | Required: 60–100 bpm)
              </span>
            </div>

            <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    Body Weight
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <Activity className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                    {latestWeight?.value || '68'}
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">kg</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200 mt-2 block">
                (Normal: 50–80 kg | BMI: 18.5–24.9)
              </span>
            </div>

            <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    Temperature
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center">
                    <Activity className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                    {latestTemp?.value || '98.6'}
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">°F</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200 mt-2 block">
                (Normal: 97.8°F–99.1°F | Required: ~98.6°F)
              </span>
            </div>
          </div>

          {/* Today's Medication Tracker */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <h2 className="font-extrabold text-lg text-slate-900">Today's Medication Schedule</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Real-time status of doctor-prescribed doses</p>
                </div>
              </div>

              <div className="mt-5 space-y-3.5">
                {medicines.map((med) => (
                  <div
                    key={med.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between gap-4 transition"
                  >
                    <div className="flex items-center space-x-3.5">
                      <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                        <Pill className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900">{med.name}</h4>
                        <p className="text-xs text-slate-500 font-medium">
                          {med.dosage} • {med.frequency} • {med.timing.replace('_', ' ')}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      {med.schedules && med.schedules.length > 0 ? (
                        med.schedules.map((sch) => (
                          <div key={sch.id} className="text-right">
                            <span className="text-[11px] font-bold text-slate-500 block">{sch.time}</span>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase ${
                                sch.status === 'taken'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : sch.status === 'missed'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {sch.status}
                            </span>
                          </div>
                        ))
                      ) : (
                        <span className="text-xs text-slate-400 font-medium">Daily</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upcoming Doctor Appointments */}
            <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <h2 className="font-extrabold text-lg text-slate-900">Doctor Visits</h2>
                  <button
                    onClick={() => onNavigateTab('appointments')}
                    className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                  >
                    Manage
                  </button>
                </div>

                <div className="mt-5 space-y-4">
                  {appointments.slice(0, 2).map((apt) => (
                    <div key={apt.id} className="p-4 rounded-2xl bg-teal-50/50 border border-teal-100">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-teal-800">{apt.doctorName}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-200 text-teal-900 uppercase">
                          {apt.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 font-medium">{apt.clinic}</p>
                      <div className="mt-2.5 pt-2 border-t border-teal-100 text-xs text-slate-500 flex items-center justify-between">
                        <span>📅 {apt.appointmentDate}</span>
                        <span>⏰ {apt.appointmentTime}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100">
                <button
                  onClick={() => {
                    setActiveSubTab('services');
                    setServiceType('doctor_visit');
                    setServiceTitle('Doctor Home Visit Consultation');
                    setShowServiceModal(true);
                  }}
                  className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Stethoscope className="w-4 h-4 text-teal-700" />
                  <span>Request Home Doctor Visit</span>
                </button>
              </div>
            </div>
          </div>

          {/* Senior Calorie & Nutrition Monitoring Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                <Flame className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-extrabold uppercase tracking-wide bg-orange-100 text-orange-800 px-2 py-0.5 rounded-md">
                    Nutrition Monitoring
                  </span>
                  <span className="text-xs text-slate-400">Daily Goal: 1800 kcal</span>
                </div>
                <h3 className="font-extrabold text-lg text-slate-900 mt-1">
                  Senior Calorie Counter & Meal Intake
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Monitor food intake, check breakfast, lunch, snacks & dinner, and view weekly nutritional history.
                </p>
              </div>
            </div>

            <button
              onClick={() => onNavigateTab('calorieCounter')}
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-xs transition flex items-center space-x-1.5 shrink-0 cursor-pointer"
            >
              <Utensils className="w-4 h-4" />
              <span>Open Calorie Counter →</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 2. ELDERCARE SERVICE REQUESTS (Section 23) */}
      {activeSubTab === 'services' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-extrabold text-2xl text-slate-900">Eldercare Concierge Services</h2>
              <p className="text-slate-600 text-sm mt-0.5">
                Request verified medical refills, groceries, nursing, physiotherapy, and assisted mobility for your elder.
              </p>
            </div>
            <button
              onClick={() => setShowServiceModal(true)}
              className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md shadow-teal-700/20 flex items-center space-x-2 cursor-pointer transition"
            >
              <Plus className="w-5 h-5" />
              <span>Request New Service</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {serviceRequests.map((srv) => (
              <div
                key={srv.id}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        srv.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : srv.status === 'in_progress'
                          ? 'bg-sky-100 text-sky-800'
                          : srv.status === 'assigned'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {srv.status.replace('_', ' ')}
                    </span>
                    <span className="text-xs font-bold text-slate-400">
                      📅 {srv.requestedDate}
                    </span>
                  </div>

                  <h3 className="font-extrabold text-lg text-slate-900 leading-snug">{srv.title}</h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">{srv.description}</p>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400 block font-semibold">Assigned Care Partner</span>
                    <span className="font-bold text-slate-800">{srv.assignedTo || 'Assigning Coordinator...'}</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[11px] font-bold uppercase ${
                      srv.priority === 'urgent'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {srv.priority} Priority
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: 3. FAMILY & CAREGIVER CHAT */}
      {activeSubTab === 'messages' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-6 border-b border-slate-100 flex items-center justify-between flex-wrap gap-4">
            <div>
              <h2 className="font-extrabold text-xl text-slate-900">Direct Family & Care Messaging</h2>
              <p className="text-xs text-slate-500 mt-0.5">Stay connected in real time with your loved one and care circle</p>
            </div>

            <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
              <button
                onClick={() => setChatRecipient('senior')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  chatRecipient === 'senior' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
                }`}
              >
                Papa ({seniorUser.name})
              </button>
              <button
                onClick={() => setChatRecipient('caregiver')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  chatRecipient === 'caregiver' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
                }`}
              >
                Caregiver (Sister Sunita)
              </button>
            </div>
          </div>

          {/* Chat message stream */}
          <div className="p-6 h-96 overflow-y-auto space-y-4 bg-slate-50/50">
            {currentChatMessages.length === 0 ? (
              <div className="text-center py-16 text-sm text-slate-400">
                No previous messages in this conversation. Start by saying hello!
              </div>
            ) : (
              currentChatMessages.map((msg) => {
                const isMe = msg.senderId === familyUser.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <span className="text-[11px] font-bold text-slate-400 mb-1 px-1">
                      {msg.senderName}
                    </span>
                    <div
                      className={`max-w-md p-4 rounded-2xl text-sm leading-relaxed ${
                        isMe
                          ? 'bg-teal-600 text-white rounded-br-xs shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-800 rounded-bl-xs shadow-xs'
                      }`}
                    >
                      {msg.message}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 px-1">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Chat input */}
          <form onSubmit={handleSendChat} className="p-4 border-t border-slate-100 flex items-center space-x-3 bg-white">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder={`Message ${chatRecipient === 'senior' ? seniorUser.name : 'Sister Sunita'}...`}
              className="flex-1 px-4 py-3 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-600 text-sm"
            />
            <button
              type="submit"
              disabled={!chatInput.trim()}
              className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold text-sm flex items-center space-x-1.5 transition cursor-pointer shadow-xs"
            >
              <Send className="w-4 h-4" />
              <span>Send</span>
            </button>
          </form>
        </div>
      )}

      {/* TAB CONTENT: 4. MEDICAL DOCUMENT VAULT */}
      {activeSubTab === 'documents' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-extrabold text-2xl text-slate-900">Senior's Medical Document Vault</h2>
              <p className="text-slate-600 text-sm mt-0.5">
                Centralized, confidential archive of doctor prescriptions, diagnostic lab reports, and insurance documents.
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('medicalVault')}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center space-x-2 transition cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>Open Document Vault View</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {medicalDocuments.map((doc) => (
              <div
                key={doc.id}
                className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase bg-teal-100 text-teal-800">
                      {doc.documentType.replace('_', ' ')}
                    </span>
                    <span className="text-[11px] text-slate-400 font-semibold">{doc.fileSize}</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 leading-snug">{doc.title}</h4>
                  <p className="text-xs text-slate-500 mt-1">{doc.description}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                  <span>📅 {new Date(doc.uploadedAt).toLocaleDateString()}</span>
                  <span className="text-teal-700 font-bold hover:underline cursor-pointer">
                    View PDF
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: Request Eldercare Service */}
      {showServiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200">
            <h3 className="font-display font-black text-2xl text-slate-900 mb-1">
              Request Eldercare Service
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Our eldercare care managers will dispatch certified professionals directly to {seniorUser.name}'s home.
            </p>

            <form onSubmit={handleCreateService} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Service Type</label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value as ServiceType)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-teal-600"
                >
                  <option value="medicine_delivery">💊 Prescription Medicine Refill & Delivery</option>
                  <option value="grocery_delivery">🥦 Fresh Organic Low-Sodium Groceries</option>
                  <option value="doctor_visit">🩺 Doctor Home Visit / Geriatric Consultation</option>
                  <option value="home_nurse">👩‍⚕️ Certified Home Nurse / Attendant Round</option>
                  <option value="physiotherapy">🏃 Elder Physiotherapy & Mobility Session</option>
                  <option value="elder_transport">🚗 Assisted Cab with Wheelchair & Escort</option>
                  <option value="home_repair">🔧 Elder Home Safety & Grab-Bar Repair</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Service Title / Need</label>
                <input
                  type="text"
                  required
                  value={serviceTitle}
                  onChange={(e) => setServiceTitle(e.target.value)}
                  placeholder="e.g. Monthly Blood Pressure Medicine Refill"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Special Instructions for Care Manager</label>
                <textarea
                  rows={3}
                  value={serviceDescription}
                  onChange={(e) => setServiceDescription(e.target.value)}
                  placeholder="e.g. Please deliver by Thursday 2 PM. Ring doorbell gently."
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Requested Date</label>
                  <input
                    type="date"
                    value={serviceDate}
                    onChange={(e) => setServiceDate(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Priority</label>
                  <select
                    value={servicePriority}
                    onChange={(e) => setServicePriority(e.target.value as any)}
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium"
                  >
                    <option value="normal">Normal</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowServiceModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm cursor-pointer shadow-md"
                >
                  Confirm & Dispatch Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
