import React, { useState, useEffect } from 'react';
import { Clock, Calendar as CalendarIcon, Globe, Sunrise, Sunset, Sparkles, ChevronRight } from 'lucide-react';
import { Language } from '../types';

interface IndianTimeClockProps {
  language: Language;
  onOpenCalendar?: () => void;
  compact?: boolean;
  showDetailsModal?: boolean;
}

export const IndianTimeClock: React.FC<IndianTimeClockProps> = ({
  language,
  onOpenCalendar,
  compact = false,
}) => {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [showPopover, setShowPopover] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Format time in Asia/Kolkata timezone (IST: UTC +05:30)
  const istTimeFormatted = currentTime.toLocaleTimeString(
    language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-IN',
    {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }
  );

  const istShortTime = currentTime.toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const istDateFormatted = currentTime.toLocaleDateString(
    language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-IN',
    {
      timeZone: 'Asia/Kolkata',
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }
  );

  const istFullDate = currentTime.toLocaleDateString(
    language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-IN',
    {
      timeZone: 'Asia/Kolkata',
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }
  );

  // Indian season / traditional indicator
  const getIndianSeason = () => {
    const month = parseInt(
      currentTime.toLocaleDateString('en-US', { timeZone: 'Asia/Kolkata', month: 'numeric' }),
      10
    );
    if (month >= 3 && month <= 4) return { en: 'Vasanta (Spring)', hi: 'वसंत ऋतु', mr: 'वसंत ऋतू' };
    if (month >= 5 && month <= 6) return { en: 'Grishma (Summer)', hi: 'ग्रीष्म ऋतु', mr: 'ग्रीष्म ऋतू' };
    if (month >= 7 && month <= 8) return { en: 'Varsha (Monsoon)', hi: 'वर्षा ऋतु', mr: 'वर्षा ऋतू' };
    if (month >= 9 && month <= 10) return { en: 'Sharad (Autumn)', hi: 'शरद ऋतु', mr: 'शरद ऋतू' };
    if (month >= 11 && month <= 12) return { en: 'Hemanta (Pre-Winter)', hi: 'हेमंत ऋतु', mr: 'हेमंत ऋतू' };
    return { en: 'Shishira (Winter)', hi: 'शिशिर ऋतु', mr: 'शिशिर ऋतू' };
  };

  const season = getIndianSeason();
  const seasonLabel = language === 'hi' ? season.hi : language === 'mr' ? season.mr : season.en;

  const titleIST =
    language === 'hi'
      ? 'भारतीय मानक समय (IST)'
      : language === 'mr'
      ? 'भारतीय प्रमाणवेळ (IST)'
      : 'Indian Standard Time (IST)';

  if (compact) {
    return (
      <div className="relative inline-block">
        <button
          onClick={() => setShowPopover(!showPopover)}
          className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl bg-orange-50 hover:bg-orange-100/80 border border-orange-200/80 text-orange-900 transition-all cursor-pointer shadow-2xs group"
          title="Indian Standard Time (IST • UTC+05:30)"
        >
          <span className="text-sm font-emoji" role="img" aria-label="India Flag">
            🇮🇳
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping inline-block" />
          <span className="font-mono font-extrabold text-xs tracking-tight text-slate-800 group-hover:text-orange-950">
            {istShortTime}
          </span>
          <span className="text-[10px] font-bold text-orange-700 uppercase hidden xl:inline">
            IST
          </span>
        </button>

        {showPopover && (
          <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white rounded-2xl shadow-2xl border border-orange-200 p-4 z-50 text-slate-800 animate-in fade-in slide-in-from-top-2 duration-150">
            <div className="flex items-center justify-between pb-2.5 border-b border-orange-100">
              <div className="flex items-center space-x-2">
                <span className="text-xl">🇮🇳</span>
                <div>
                  <h4 className="font-bold text-xs text-orange-950">{titleIST}</h4>
                  <span className="text-[10px] text-slate-500 font-mono">UTC +05:30 (Asia/Kolkata)</span>
                </div>
              </div>
              <button
                onClick={() => setShowPopover(false)}
                className="text-xs text-slate-400 hover:text-slate-700 font-bold px-1.5 py-0.5"
              >
                ✕
              </button>
            </div>

            <div className="my-3 p-3 bg-gradient-to-r from-orange-50 via-amber-50 to-emerald-50 rounded-xl border border-orange-100 flex items-center justify-between">
              <div>
                <div className="text-[10px] font-bold text-orange-700 uppercase tracking-wider">
                  Live Indian Time
                </div>
                <div className="font-mono text-2xl font-black text-slate-900 tracking-tight">
                  {istTimeFormatted}
                </div>
                <div className="text-xs text-slate-600 font-medium mt-0.5">
                  {istFullDate}
                </div>
              </div>
            </div>

            <div className="space-y-1.5 text-xs text-slate-600 pb-3 border-b border-slate-100">
              <div className="flex items-center justify-between">
                <span className="flex items-center space-x-1.5 text-slate-500">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Indian Season / ऋतू:</span>
                </span>
                <span className="font-bold text-slate-800">{seasonLabel}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center space-x-1.5 text-slate-500">
                  <Sunrise className="w-3.5 h-3.5 text-orange-500" />
                  <span>Est. Sunrise / Sunset:</span>
                </span>
                <span className="font-semibold text-slate-700">~6:12 AM / ~6:28 PM</span>
              </div>
            </div>

            {onOpenCalendar && (
              <button
                onClick={() => {
                  setShowPopover(false);
                  onOpenCalendar();
                }}
                className="mt-3 w-full py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl flex items-center justify-center space-x-1.5 transition cursor-pointer shadow-xs"
              >
                <CalendarIcon className="w-3.5 h-3.5" />
                <span>
                  {language === 'hi'
                    ? 'स्वास्थ्य कैलेंडर खोलें'
                    : language === 'mr'
                    ? 'आरोग्य दिनदर्शिका उघडा'
                    : 'Open Health Calendar'}
                </span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
      </div>
    );
  }

  // Expanded card format (for Banner / Dashboard / Calendar headers)
  return (
    <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-emerald-500/10 border border-orange-400/30 backdrop-blur-md shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-orange-500/20 border border-orange-400/30 flex items-center justify-center text-2xl shadow-xs">
            🇮🇳
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-orange-700 uppercase tracking-wider">
                {titleIST}
              </span>
              <span className="px-1.5 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-mono font-bold">
                UTC +05:30
              </span>
            </div>
            <div className="font-mono text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-0.5 flex items-center space-x-2">
              <span>{istTimeFormatted}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <div className="text-xs sm:text-sm text-slate-600 font-medium">
              {istFullDate} • <span className="text-orange-800 font-semibold">{seasonLabel}</span>
            </div>
          </div>
        </div>

        {onOpenCalendar && (
          <button
            onClick={onOpenCalendar}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs flex items-center justify-center space-x-2 transition cursor-pointer self-start sm:self-auto"
          >
            <CalendarIcon className="w-4 h-4" />
            <span>
              {language === 'hi'
                ? 'कैलेंडर देखें'
                : language === 'mr'
                ? 'दिनदर्शिका पहा'
                : 'View Calendar'}
            </span>
          </button>
        )}
      </div>
    </div>
  );
};
