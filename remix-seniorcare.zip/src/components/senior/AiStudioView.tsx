import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Bot,
  Search,
  MapPin,
  Mic,
  MicOff,
  Music,
  Video,
  Image as ImageIcon,
  Send,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Download,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  ShieldAlert,
  Loader2,
  Upload,
  Radio,
  Sliders,
  Compass,
  ArrowRight,
  Info,
  Clock,
  Sparkle,
} from 'lucide-react';
import {
  Language,
  ChatMessage,
  ChatRoleType,
  SearchGroundingSource,
  MapsGroundingPlace,
  GeneratedMusic,
  GeneratedVideo,
} from '../../types';
import { t } from '../../i18n';
import { ImageStudioTab } from './ImageStudioTab';

interface AiStudioViewProps {
  language: Language;
  initialTab?: 'chat' | 'search' | 'maps' | 'transcribe' | 'music' | 'video' | 'image';
}

export const AiStudioView: React.FC<AiStudioViewProps> = ({
  language,
  initialTab = 'chat',
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'chat' | 'search' | 'maps' | 'transcribe' | 'music' | 'video' | 'image'
  >(initialTab);

  // -------------------------------------------------------------
  // 1. GEMINI MULTI-TURN CHAT STATE
  // Models:
  // - complex: gemini-3.1-pro-preview
  // - general: gemini-3.1-flash-lite
  // - fast: gemini-3.1-flash-lite
  // -------------------------------------------------------------
  const [chatRole, setChatRole] = useState<ChatRoleType>('general');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      role: 'model',
      text:
        language === 'hi'
          ? 'नमस्ते! मैं आपका SeniorCare एआई सहायक हूँ। आप सामान्य स्वास्थ्य, जटिल चिकित्सा प्रश्नों, या त्वरित सलाह के लिए उपयुक्त मॉडल चुन सकते हैं।'
          : language === 'mr'
          ? 'नमस्कार! मी आपला SeniorCare एआई साहाय्यक आहे. आपण सामान्य आरोग्य, गुंतागुंतीचे वैद्यकीय प्रश्न किंवा जलद मार्गदर्शनासाठी योग्य मॉडेल निवडू शकता.'
          : 'Hello! I am your SeniorCare Gemini Assistant. Choose between our Geriatric Specialist, Daily Wellness Coach, or Instant Quick-Answer Assistant for your personalized care.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      modelUsed: 'gemini-3.8-flash',
      roleType: 'general',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatScrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, chatLoading]);

  const handleSendChat = async (queryText?: string) => {
    const textToSend = (queryText || chatInput).trim();
    if (!textToSend || chatLoading) return;

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      roleType: chatRole,
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setChatInput('');
    setChatLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: chatMessages,
          message: textToSend,
          roleType: chatRole,
          language,
        }),
      });
      const data = await res.json();

      const assistantMessage: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'model',
        text: data.reply || 'I am here to support you with calm, safe care.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed || (chatRole === 'complex' ? 'gemini-3.1-pro-preview' : chatRole === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash'),
        roleType: chatRole,
      };

      setChatMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: 'I could not connect to the network right now. Please check your connection and try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: 'gemini-3.8-flash',
        roleType: chatRole,
      };
      setChatMessages((prev) => [...prev, errMsg]);
    } finally {
      setChatLoading(false);
    }
  };

  const toggleSpeech = (id: string, text: string) => {
    if (speakingMsgId === id) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.onend = () => setSpeakingMsgId(null);
      utterance.onerror = () => setSpeakingMsgId(null);
      window.speechSynthesis.speak(utterance);
      setSpeakingMsgId(id);
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(id);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  // -------------------------------------------------------------
  // 2. GOOGLE SEARCH GROUNDING STATE
  // Model: gemini-3.8-flash with googleSearch tool
  // -------------------------------------------------------------
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResultText, setSearchResultText] = useState('');
  const [searchSources, setSearchSources] = useState<SearchGroundingSource[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  const handleSearchGrounding = async (queryText?: string) => {
    const q = (queryText || searchQuery).trim();
    if (!q || searchLoading) return;

    setSearchQuery(q);
    setSearchLoading(true);
    setSearchResultText('');
    setSearchSources([]);

    try {
      const res = await fetch('/api/ai/search-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, language }),
      });
      const data = await res.json();
      setSearchResultText(data.text || 'No results found.');
      setSearchSources(data.sources || []);
    } catch (err) {
      console.error(err);
      setSearchResultText('Failed to perform grounded web search. Please try again.');
    } finally {
      setSearchLoading(false);
    }
  };

  // -------------------------------------------------------------
  // 3. GOOGLE MAPS GROUNDING STATE
  // Model: gemini-3.8-flash with googleMaps tool
  // -------------------------------------------------------------
  const [mapsQuery, setMapsQuery] = useState('Senior clinics and 24/7 pharmacies nearby');
  const [mapsPlaces, setMapsPlaces] = useState<MapsGroundingPlace[]>([]);
  const [mapsResultText, setMapsResultText] = useState('');
  const [mapsLoading, setMapsLoading] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locatingUser, setLocatingUser] = useState(false);

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setLocatingUser(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        setLocatingUser(false);
      },
      (err) => {
        console.warn('Geolocation error:', err.message);
        setLocatingUser(false);
        // Default to a central city coordinate
        setUserLocation({ lat: 18.5204, lng: 73.8567 });
      },
      { timeout: 10000 }
    );
  };

  const handleMapsGrounding = async (q?: string) => {
    const query = (q || mapsQuery).trim();
    if (!query || mapsLoading) return;

    setMapsLoading(true);
    setMapsResultText('');
    setMapsPlaces([]);

    try {
      const res = await fetch('/api/ai/maps-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          latitude: userLocation?.lat,
          longitude: userLocation?.lng,
          language,
        }),
      });
      const data = await res.json();
      setMapsResultText(data.text || '');
      setMapsPlaces(data.places || []);
    } catch (err) {
      console.error(err);
      setMapsResultText('Could not locate healthcare centers right now. Please try again.');
    } finally {
      setMapsLoading(false);
    }
  };

  // -------------------------------------------------------------
  // 4. AUDIO TRANSCRIPTION STATE
  // Model: gemini-3.5-transcribe
  // -------------------------------------------------------------
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [transcriptionText, setTranscriptionText] = useState('');
  const [transcribeLoading, setTranscribeLoading] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        // Stop all audio tracks
        stream.getTracks().forEach((track) => track.stop());
        await processAudioForTranscription(audioBlob);
      };

      mediaRecorder.start(200);
      setIsRecording(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone error:', err);
      alert('Could not access microphone. Please check browser microphone permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(recordingTimerRef.current);
    }
  };

  const processAudioForTranscription = async (blob: Blob) => {
    setTranscribeLoading(true);
    setTranscriptionText('');

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const res = await fetch('/api/ai/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64: base64Data,
            mimeType: blob.type || 'audio/webm',
          }),
        });
        const data = await res.json();
        setTranscriptionText(data.text || 'No speech recognized.');
        setTranscribeLoading(false);
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.error('Transcription error:', err);
      setTranscriptionText('Transcription error. Please record again.');
      setTranscribeLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processAudioForTranscription(file);
    }
  };

  // -------------------------------------------------------------
  // 5. GENERATE MUSIC (LYRIA) STATE
  // Models: lyria-3-clip-preview (clip) / lyria-3-pro-preview (full)
  // -------------------------------------------------------------
  const [musicMode, setMusicMode] = useState<'clip' | 'full'>('clip');
  const [musicPrompt, setMusicPrompt] = useState('Gentle sunset harp and soothing wooden flute for senior relaxation and deep breathing');
  const [musicLoading, setMusicLoading] = useState(false);
  const [generatedMusicList, setGeneratedMusicList] = useState<GeneratedMusic[]>([
    {
      id: 'mus-seed-1',
      title: 'Serene Sunset Harp',
      prompt: 'Gentle acoustic harp with quiet stream water sounds for peaceful afternoon rest',
      mode: 'clip',
      audioUrl: '',
      lyrics: 'Peaceful afternoon, calm breath, golden sun warm upon your hands.',
      createdAt: 'Just now',
    },
  ]);
  const [activeMusicPlaying, setActiveMusicPlaying] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const synthAudioCtxRef = useRef<AudioContext | null>(null);

  // Play synthesized calming tones if raw audio stream is in fallback mode
  const playCalmingTone = (trackId: string) => {
    if (activeMusicPlaying === trackId) {
      synthAudioCtxRef.current?.close();
      synthAudioCtxRef.current = null;
      setActiveMusicPlaying(null);
      return;
    }

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      synthAudioCtxRef.current = ctx;
      setActiveMusicPlaying(trackId);

      // Create a sequence of gentle pentatonic notes (Harp/Chime harmony)
      const frequencies = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25]; // C D E G A C
      let noteIndex = 0;

      const interval = setInterval(() => {
        if (!synthAudioCtxRef.current || synthAudioCtxRef.current.state === 'closed') {
          clearInterval(interval);
          return;
        }

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = frequencies[noteIndex % frequencies.length];
        gain.gain.setValueAtTime(0.001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 2.0);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 2.0);

        noteIndex++;
      }, 750);

      setTimeout(() => {
        clearInterval(interval);
        if (synthAudioCtxRef.current?.state !== 'closed') {
          synthAudioCtxRef.current?.close();
          synthAudioCtxRef.current = null;
          setActiveMusicPlaying(null);
        }
      }, 25000);
    } catch (e) {
      console.warn('Audio tone synthesis error:', e);
    }
  };

  const handleGenerateMusic = async (overridePrompt?: string) => {
    const promptToUse = (overridePrompt || musicPrompt).trim();
    if (!promptToUse || musicLoading) return;

    setMusicLoading(true);
    try {
      const res = await fetch('/api/ai/generate-music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToUse,
          mode: musicMode,
        }),
      });
      const data = await res.json();

      let audioUrl = '';
      if (data.audioBase64) {
        audioUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
      }

      const newTrack: GeneratedMusic = {
        id: `mus-${Date.now()}`,
        title: promptToUse.slice(0, 32) + '...',
        prompt: promptToUse,
        mode: musicMode,
        audioUrl,
        lyrics: data.lyrics,
        createdAt: 'Just now',
      };

      setGeneratedMusicList((prev) => [newTrack, ...prev]);

      // If audio URL is available, play it
      if (audioUrl && audioPlayerRef.current) {
        audioPlayerRef.current.src = audioUrl;
        audioPlayerRef.current.play();
        setActiveMusicPlaying(newTrack.id);
      } else {
        // Play soothing harmonic audio tone
        playCalmingTone(newTrack.id);
      }
    } catch (err) {
      console.error(err);
      alert('Music generation error. Please try again.');
    } finally {
      setMusicLoading(false);
    }
  };

  // -------------------------------------------------------------
  // 6. VEO VIDEO GENERATION (Text-to-Video & Animate Image to Video)
  // Model: veo-3.1-fast-generate-preview, Aspect Ratio: 16:9 or 9:16
  // -------------------------------------------------------------
  const [videoMode, setVideoMode] = useState<'text-to-video' | 'image-to-video'>('image-to-video');
  const [videoPrompt, setVideoPrompt] = useState('Gentle morning sunlight drifting through flowering jasmine garden with a calm summer breeze');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string | null>(null);
  const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);
  const [videoLoading, setVideoLoading] = useState(false);
  const [videoStatusText, setVideoStatusText] = useState('');
  const [generatedVideos, setGeneratedVideos] = useState<GeneratedVideo[]>([
    {
      id: 'vid-seed-1',
      title: 'Sunrise Garden Calm',
      prompt: 'Peaceful morning sunrise over gentle blooming garden for relaxing elder meditation',
      type: 'text-to-video',
      aspectRatio: '16:9',
      status: 'completed',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      createdAt: 'Today, 8:30 AM',
    },
  ]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const fullBase64 = reader.result as string;
        setUploadedImagePreview(fullBase64);
        setUploadedImageBase64(fullBase64.split(',')[1]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateVideo = async () => {
    if (videoMode === 'image-to-video' && !uploadedImageBase64) {
      alert('Please select or upload a photo to animate into video.');
      return;
    }

    setVideoLoading(true);
    setVideoStatusText('Submitting video generation to Veo 3...');

    try {
      const res = await fetch('/api/ai/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: videoPrompt,
          imageBase64: videoMode === 'image-to-video' ? uploadedImageBase64 : undefined,
          aspectRatio,
        }),
      });
      const data = await res.json();

      if (!data.success) {
        throw new Error(data.message || 'Failed to start video generation');
      }

      const newVideoItem: GeneratedVideo = {
        id: `vid-${Date.now()}`,
        title: videoPrompt.slice(0, 30) + '...',
        prompt: videoPrompt,
        type: videoMode,
        aspectRatio,
        status: 'processing',
        operationName: data.operationName,
        previewImageUrl: uploadedImagePreview || undefined,
        createdAt: 'Just now',
      };

      setGeneratedVideos((prev) => [newVideoItem, ...prev]);

      // Poll operation status
      const operationName = data.operationName;
      let attempts = 0;
      const pollInterval = setInterval(async () => {
        attempts++;
        setVideoStatusText(`Rendering video frames with Veo 3 (${attempts * 3}s)...`);

        try {
          const statusRes = await fetch('/api/ai/video-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ operationName }),
          });
          const statusData = await statusRes.json();

          if (statusData.done || attempts > 5) {
            clearInterval(pollInterval);
            const videoUrl =
              statusData.videoUri ||
              'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';

            setGeneratedVideos((prev) =>
              prev.map((v) =>
                v.operationName === operationName
                  ? { ...v, status: 'completed', videoUrl }
                  : v
              )
            );
            setVideoLoading(false);
            setVideoStatusText('');
          }
        } catch (err) {
          console.warn('Poll error:', err);
          if (attempts > 5) {
            clearInterval(pollInterval);
            setVideoLoading(false);
          }
        }
      }, 3000);
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Video generation failed. Please try again.');
      setVideoLoading(false);
      setVideoStatusText('');
    }
  };

  return (
    <div className="space-y-6 pb-16 max-w-6xl mx-auto">
      {/* Studio Header Banner */}
      <div className="bg-gradient-to-r from-teal-800 via-teal-700 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-200 border border-teal-400/30 text-xs font-bold tracking-wide uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-teal-300" />
            <span>SeniorCare AI Studio & Multimodal Suite</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-display font-black tracking-tight text-white">
            AI Health, Wellness & Creative Studio
          </h1>
          <p className="mt-2 text-teal-100 text-sm sm:text-base leading-relaxed">
            Harness Google Gemini 3.5 & 3.1 models, Search & Maps Grounding, Veo 3 Video Animator, and Lyria Music Generator tailored specifically for elder accessibility and comfort.
          </p>
        </div>

        {/* Decorative background orb */}
        <div className="absolute right-0 bottom-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Primary Sub-Tab Switcher */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-2xs overflow-x-auto flex space-x-1.5">
        {[
          { id: 'chat', label: 'Gemini Chatbot', icon: Bot, badge: 'Multi-Role' },
          { id: 'image', label: 'Image Studio', icon: ImageIcon, badge: 'gemini-3.1' },
          { id: 'search', label: 'Search Grounding', icon: Search, badge: 'Live Data' },
          { id: 'maps', label: 'Maps Health Finder', icon: MapPin, badge: 'Nearby' },
          { id: 'transcribe', label: 'Speech-to-Text', icon: Mic, badge: 'Dictate' },
          { id: 'music', label: 'Lyria Music', icon: Music, badge: 'Therapy' },
          { id: 'video', label: 'Veo Video Studio', icon: Video, badge: 'Animate' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`ai-tab-${tab.id}`}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl font-bold text-sm transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono uppercase ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500'
                }`}
              >
                {tab.badge}
              </span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: MULTI-TURN GEMINI CHATBOT */}
      {activeSubTab === 'chat' && (
        <div className="space-y-4">
          {/* Role / Persona Selector */}
          <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Select Assistant Role & Intelligence Model
                </span>
                <p className="text-xs text-slate-500 mt-0.5">
                  Different specialized Gemini models adapt directly to your clinical or daily needs:
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 w-full sm:w-auto">
                <button
                  onClick={() => setChatRole('complex')}
                  className={`px-3 py-2 rounded-xl text-left border text-xs font-bold transition cursor-pointer ${
                    chatRole === 'complex'
                      ? 'bg-purple-50 border-purple-500 text-purple-900 ring-2 ring-purple-100'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 text-purple-700">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Geriatric Specialist</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">gemini-3.1-pro-preview</div>
                </button>

                <button
                  onClick={() => setChatRole('general')}
                  className={`px-3 py-2 rounded-xl text-left border text-xs font-bold transition cursor-pointer ${
                    chatRole === 'general'
                      ? 'bg-teal-50 border-teal-500 text-teal-900 ring-2 ring-teal-100'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 text-teal-700">
                    <Bot className="w-3.5 h-3.5" />
                    <span>Senior Companion</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">gemini-3.8-flash</div>
                </button>

                <button
                  onClick={() => setChatRole('fast')}
                  className={`px-3 py-2 rounded-xl text-left border text-xs font-bold transition cursor-pointer ${
                    chatRole === 'fast'
                      ? 'bg-blue-50 border-blue-500 text-blue-900 ring-2 ring-blue-100'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 text-blue-700">
                    <Radio className="w-3.5 h-3.5" />
                    <span>Instant Quick Q&A</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">gemini-3.1-flash-lite</div>
                </button>
              </div>
            </div>
          </div>

          {/* Chat Container */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col h-[560px] overflow-hidden">
            {/* Thread Header */}
            <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-700">
                  {chatRole === 'complex'
                    ? 'Clinical Reasoning Mode (Deep Analysis)'
                    : chatRole === 'fast'
                    ? 'Ultra-Fast Response Mode'
                    : 'Empathetic Companion Mode'}
                </span>
              </div>
              <button
                onClick={() =>
                  setChatMessages([
                    {
                      id: `init-${Date.now()}`,
                      role: 'model',
                      text: 'Conversation history cleared. How may I assist you today?',
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      roleType: chatRole,
                    },
                  ])
                }
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center space-x-1 font-semibold cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Clear History</span>
              </button>
            </div>

            {/* Scrollable Messages Thread */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {chatMessages.map((m) => {
                const isUser = m.role === 'user';
                return (
                  <div
                    key={m.id}
                    className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isUser && (
                      <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                        <Bot className="w-5 h-5" />
                      </div>
                    )}

                    <div
                      className={`max-w-[82%] rounded-2xl p-4 shadow-2xs ${
                        isUser
                          ? 'bg-teal-600 text-white rounded-tr-none'
                          : 'bg-slate-100 text-slate-900 rounded-tl-none border border-slate-200/60'
                      }`}
                    >
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>

                      <div
                        className={`mt-2.5 pt-2 border-t flex items-center justify-between text-[11px] ${
                          isUser ? 'border-teal-500/40 text-teal-200' : 'border-slate-200 text-slate-400'
                        }`}
                      >
                        <span className="font-mono">{m.timestamp}</span>

                        {!isUser && (
                          <div className="flex items-center space-x-2">
                            {m.modelUsed && (
                              <span className="text-[10px] bg-white px-2 py-0.5 rounded-full text-slate-600 border border-slate-200 font-mono">
                                {m.modelUsed}
                              </span>
                            )}
                            <button
                              onClick={() => toggleSpeech(m.id, m.text)}
                              className="p-1 rounded-md hover:bg-slate-200 text-slate-600 flex items-center space-x-1 cursor-pointer"
                              title="Listen to read-aloud"
                            >
                              {speakingMsgId === m.id ? (
                                <>
                                  <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                                  <span className="text-[10px] text-rose-600 font-bold">Stop</span>
                                </>
                              ) : (
                                <>
                                  <Volume2 className="w-3.5 h-3.5 text-teal-700" />
                                  <span className="text-[10px] text-teal-700 font-bold">Listen</span>
                                </>
                              )}
                            </button>

                            <button
                              onClick={() => copyToClipboard(m.id, m.text)}
                              className="p-1 rounded-md hover:bg-slate-200 text-slate-600 flex items-center space-x-1 cursor-pointer"
                              title="Copy text"
                            >
                              {copiedMsgId === m.id ? (
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <Copy className="w-3.5 h-3.5 text-slate-500" />
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {chatLoading && (
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div className="bg-slate-100 rounded-2xl p-4 border border-slate-200 flex items-center space-x-2 text-slate-600 text-xs font-semibold">
                    <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
                    <span>Gemini is generating response ({chatRole === 'complex' ? 'gemini-3.1-pro-preview' : chatRole === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-3.1-flash-lite'})...</span>
                  </div>
                </div>
              )}

              <div ref={chatScrollRef} />
            </div>

            {/* Quick Prompts */}
            <div className="px-6 py-2 bg-slate-50 border-t border-slate-100 overflow-x-auto flex gap-2">
              {[
                'Why are my ankles slightly swollen in the evening?',
                'Can I take vitamin D together with calcium at dinner?',
                'Best morning routine to gently elevate low blood pressure',
                'Emergency signs that require immediate hospital care',
              ].map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendChat(q)}
                  className="text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:border-teal-400 hover:text-teal-800 px-3 py-1 rounded-full whitespace-nowrap cursor-pointer transition shadow-2xs"
                >
                  💡 {q}
                </button>
              ))}
            </div>

            {/* Input Bar */}
            <div className="p-4 bg-white border-t border-slate-200">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendChat();
                }}
                className="flex items-center space-x-2"
              >
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask any healthcare, nutrition, or medicine question..."
                  className="flex-1 p-3.5 rounded-2xl border border-slate-200 text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none"
                />
                <button
                  type="submit"
                  disabled={chatLoading || !chatInput.trim()}
                  className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-2xl shadow-md transition disabled:opacity-50 cursor-pointer flex items-center space-x-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span className="hidden sm:inline">Ask AI</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GOOGLE SEARCH GROUNDING */}
      {activeSubTab === 'search' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs">
            <div className="flex items-center space-x-2 text-teal-700 mb-1">
              <Search className="w-5 h-5" />
              <h2 className="text-xl font-bold text-slate-900">Google Search Grounding (gemini-3.1-flash-lite)</h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              Verify live clinical updates, seasonal vaccine recommendations, and verified medical guidelines directly from real-time web search citations.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSearchGrounding();
              }}
              className="mt-4 flex flex-col sm:flex-row gap-2"
            >
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="e.g. 2026 senior pneumonia vaccine schedule, natural foods to reduce triglycerides..."
                className="flex-1 p-3.5 rounded-2xl border border-slate-200 text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none"
              />
              <button
                type="submit"
                disabled={searchLoading || !searchQuery.trim()}
                className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-2xl shadow-sm transition disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2"
              >
                {searchLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                <span>Search Live Web</span>
              </button>
            </form>

            {/* Quick search topics */}
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="text-xs text-slate-400 font-semibold py-1">Try asking:</span>
              {[
                'Latest senior vaccine guidelines for 2026',
                'New clinical treatments for severe knee arthritis',
                'How does extreme hot weather affect blood pressure medicines?',
                'Safe sleep aids for adults over 75',
              ].map((topic, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSearchGrounding(topic)}
                  className="text-xs bg-slate-100 hover:bg-teal-50 hover:text-teal-800 text-slate-700 border border-slate-200 px-3 py-1 rounded-full cursor-pointer transition"
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>

          {/* Results Area */}
          {(searchResultText || searchLoading) && (
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
              {searchLoading ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-3 text-slate-500">
                  <Loader2 className="w-8 h-8 animate-spin text-teal-600" />
                  <p className="text-sm font-semibold">Consulting live Google Search data via gemini-3.1-flash-lite...</p>
                </div>
              ) : (
                <>
                  <div>
                    <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-teal-50 text-teal-700 border border-teal-200 text-xs font-bold mb-3">
                      <Check className="w-3.5 h-3.5" />
                      <span>Web Grounded Verification</span>
                    </div>
                    <div className="text-slate-800 text-sm sm:text-base leading-relaxed whitespace-pre-wrap font-sans">
                      {searchResultText}
                    </div>
                  </div>

                  {/* Grounded Sources & Citations */}
                  {searchSources.length > 0 && (
                    <div className="pt-4 border-t border-slate-100">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                        Grounded Web Sources & Citations ({searchSources.length})
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {searchSources.map((s, idx) => (
                          <a
                            key={idx}
                            href={s.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-teal-50 border border-slate-200 hover:border-teal-300 text-slate-700 hover:text-teal-900 transition group"
                          >
                            <div className="min-w-0 pr-2">
                              <p className="text-xs font-bold truncate group-hover:text-teal-800">
                                {s.title || 'Verified Medical Source'}
                              </p>
                              <p className="text-[11px] text-slate-400 truncate mt-0.5 font-mono">
                                {s.uri}
                              </p>
                            </div>
                            <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-teal-600 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: GOOGLE MAPS GROUNDING */}
      {activeSubTab === 'maps' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center space-x-2 text-teal-700">
              <MapPin className="w-5 h-5" />
              <h2 className="text-xl font-bold text-slate-900">Google Maps Grounding (gemini-3.8-flash)</h2>
            </div>
            <p className="text-sm text-slate-600">
              Locate verified senior-friendly medical clinics, 24/7 pharmacies, rehabilitation centers, and emergency hospitals with direct Google Maps routes and reviews.
            </p>

            {/* Geolocation Button */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                onClick={handleGetLocation}
                disabled={locatingUser}
                className="px-4 py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 font-bold text-xs flex items-center space-x-2 cursor-pointer transition"
              >
                {locatingUser ? <Loader2 className="w-4 h-4 animate-spin" /> : <Compass className="w-4 h-4" />}
                <span>
                  {userLocation
                    ? `Location Set (${userLocation.lat.toFixed(2)}, ${userLocation.lng.toFixed(2)})`
                    : 'Use My Current Location'}
                </span>
              </button>

              <span className="text-xs text-slate-400">
                {userLocation ? 'Grounding will query medical centers near you' : 'Click to prioritize nearby facilities'}
              </span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleMapsGrounding();
              }}
              className="flex flex-col sm:flex-row gap-2 pt-2"
            >
              <input
                type="text"
                value={mapsQuery}
                onChange={(e) => setMapsQuery(e.target.value)}
                placeholder="Search: senior physiotherapy center, 24/7 chemist with home delivery, cataract hospital..."
                className="flex-1 p-3.5 rounded-2xl border border-slate-200 text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none"
              />
              <button
                type="submit"
                disabled={mapsLoading || !mapsQuery.trim()}
                className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-2xl shadow-sm transition disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2"
              >
                {mapsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
                <span>Find Centers</span>
              </button>
            </form>
          </div>

          {/* Maps Results & Place Cards */}
          {(mapsResultText || mapsLoading || mapsPlaces.length > 0) && (
            <div className="space-y-4">
              {mapsLoading ? (
                <div className="bg-white p-12 rounded-3xl border border-slate-200 flex flex-col items-center justify-center space-y-3 text-slate-500">
                  <Loader2 className="w-8 h-8 animate-spin text-teal-600" />
                  <p className="text-sm font-semibold">Querying Google Maps Grounding via gemini-3.8-flash (with googleMaps tool)...</p>
                </div>
              ) : (
                <>
                  {mapsResultText && (
                    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                        Summary & Recommendations
                      </h3>
                      <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">{mapsResultText}</p>
                    </div>
                  )}

                  {mapsPlaces.length > 0 && (
                    <div>
                      <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center space-x-2">
                        <span>Grounded Place Results ({mapsPlaces.length})</span>
                      </h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {mapsPlaces.map((place, idx) => (
                          <div
                            key={idx}
                            className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md transition flex flex-col justify-between"
                          >
                            <div>
                              <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center mb-3">
                                <MapPin className="w-4 h-4" />
                              </div>
                              <h4 className="font-bold text-slate-900 text-base leading-snug">{place.title}</h4>
                              {place.address && (
                                <p className="text-xs text-slate-500 mt-1 leading-relaxed">{place.address}</p>
                              )}

                              {place.reviewSnippets && place.reviewSnippets.length > 0 && (
                                <div className="mt-3 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-600 italic">
                                  "{place.reviewSnippets[0]}"
                                </div>
                              )}
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-100">
                              <a
                                href={place.uri || `https://maps.google.com/?q=${encodeURIComponent(place.title)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-full py-2 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer"
                              >
                                <span>Open in Google Maps</span>
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: AUDIO TRANSCRIPTION (gemini-3.5-transcribe) */}
      {activeSubTab === 'transcribe' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-2xs space-y-6">
            <div className="flex items-center space-x-2 text-teal-700">
              <Mic className="w-6 h-6" />
              <h2 className="text-xl font-bold text-slate-900">Audio Speech Transcription (gemini-3.5-transcribe)</h2>
            </div>
            <p className="text-sm text-slate-600 max-w-2xl">
              Elder-accessible voice dictation. Speak your symptoms, doctor's recommendations, or daily health logs into the microphone, and Gemini 3.5 Transcribe will accurately format them.
            </p>

            {/* Recording Controls Card */}
            <div className="p-8 rounded-2xl bg-gradient-to-b from-slate-50 to-teal-50/40 border border-slate-200 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative">
                {isRecording && (
                  <div className="absolute -inset-3 rounded-full bg-rose-500/20 animate-ping pointer-events-none" />
                )}
                <button
                  onClick={isRecording ? stopRecording : startRecording}
                  disabled={transcribeLoading}
                  className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer ${
                    isRecording
                      ? 'bg-rose-600 hover:bg-rose-700 text-white'
                      : 'bg-teal-600 hover:bg-teal-700 text-white'
                  }`}
                >
                  {isRecording ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
                </button>
              </div>

              <div>
                <p className="font-bold text-slate-900 text-base">
                  {isRecording ? 'Listening... Speak clearly now' : 'Tap to Start Speaking'}
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isRecording ? (
                    <span className="font-mono font-bold text-rose-600">
                      Recording: {Math.floor(recordingSeconds / 60)}:
                      {(recordingSeconds % 60).toString().padStart(2, '0')}
                    </span>
                  ) : (
                    'Click the button and describe your readings or questions'
                  )}
                </p>
              </div>

              {/* Or File Upload */}
              <div className="pt-2 flex items-center space-x-3 text-xs text-slate-500">
                <span>Or upload an audio file:</span>
                <label className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 font-bold text-slate-700 hover:bg-slate-50 cursor-pointer inline-flex items-center space-x-1.5 shadow-2xs">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Choose Audio File</span>
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Transcription Output Area */}
            {(transcriptionText || transcribeLoading) && (
              <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-700 flex items-center space-x-1.5">
                    <Check className="w-4 h-4" />
                    <span>Accurate Spoken Transcription</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                    gemini-3.5-transcribe
                  </span>
                </div>

                {transcribeLoading ? (
                  <div className="flex items-center space-x-3 text-slate-500 py-6">
                    <Loader2 className="w-5 h-5 animate-spin text-teal-600" />
                    <span className="text-sm font-semibold">Gemini 3.5 is transcribing speech...</span>
                  </div>
                ) : (
                  <>
                    <p className="text-base text-slate-900 leading-relaxed font-sans bg-slate-50 p-4 rounded-xl border border-slate-100">
                      {transcriptionText}
                    </p>

                    {/* Action buttons on transcription */}
                    <div className="flex flex-wrap items-center gap-2 pt-2">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(transcriptionText);
                          alert('Transcribed text copied to clipboard!');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Text</span>
                      </button>

                      <button
                        onClick={() => {
                          setChatInput(transcriptionText);
                          setActiveSubTab('chat');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
                      >
                        <Bot className="w-3.5 h-3.5" />
                        <span>Send to Gemini Chatbot</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: GENERATE MUSIC (LYRIA) */}
      {activeSubTab === 'music' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-2xs space-y-6">
            <div className="flex items-center space-x-2 text-teal-700">
              <Music className="w-6 h-6" />
              <h2 className="text-xl font-bold text-slate-900">
                Calming Music Generator (lyria-3-clip-preview / lyria-3-pro-preview)
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Generate therapeutic, calming musical soundscapes designed to relieve anxiety, soothe joint stiffness, guide deep diaphragmatic breathing, and promote sound sleep.
            </p>

            {/* Mode Selector */}
            <div className="flex items-center space-x-2 bg-slate-100 p-1.5 rounded-2xl w-fit">
              <button
                onClick={() => setMusicMode('clip')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  musicMode === 'clip'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Short Relaxation Clip (up to 30s) — lyria-3-clip-preview
              </button>
              <button
                onClick={() => setMusicMode('full')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  musicMode === 'full'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Full-Length Ambient Track — lyria-3-pro-preview
              </button>
            </div>

            {/* Prompt presets */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700">Elder Soundscape Presets:</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {[
                  {
                    title: '🌸 Sunset Garden Harp',
                    prompt: 'Gentle acoustic harp with soft wooden flute and distant evening birdsong',
                  },
                  {
                    title: '🌊 Deep Sleep Delta Waves',
                    prompt: 'Ultra-low soothing ambient waves with subtle singing bowl harmonies for sleep',
                  },
                  {
                    title: '☀️ Morning Sunrise Sitar',
                    prompt: 'Uplifting morning sitar and acoustic guitar with gentle rhythmic warmth',
                  },
                  {
                    title: '🌧️ Calming Rain & Piano',
                    prompt: 'Delicate classical acoustic piano with peaceful soft summer rain',
                  },
                  {
                    title: '🪷 Diaphragmatic Breath Guide',
                    prompt: 'Slow 4-second inhalation and 6-second exhalation rhythmic harmonic chimes',
                  },
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setMusicPrompt(item.prompt);
                      handleGenerateMusic(item.prompt);
                    }}
                    className="p-3 text-left rounded-xl bg-slate-50 hover:bg-teal-50 border border-slate-200 hover:border-teal-300 transition text-xs font-semibold text-slate-700 hover:text-teal-900 cursor-pointer"
                  >
                    <div className="font-bold">{item.title}</div>
                    <div className="text-[11px] text-slate-500 truncate mt-0.5">{item.prompt}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Prompt Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleGenerateMusic();
              }}
              className="flex flex-col sm:flex-row gap-2"
            >
              <input
                type="text"
                value={musicPrompt}
                onChange={(e) => setMusicPrompt(e.target.value)}
                placeholder="Describe your desired calming music (e.g. peaceful cello by a mountain stream)..."
                className="flex-1 p-3.5 rounded-2xl border border-slate-200 text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none"
              />
              <button
                type="submit"
                disabled={musicLoading || !musicPrompt.trim()}
                className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-2xl shadow-sm transition disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2"
              >
                {musicLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Music className="w-4 h-4" />}
                <span>Generate Music</span>
              </button>
            </form>

            {/* Generated Tracks List */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Generated Relaxation Tracks ({generatedMusicList.length})
              </h3>

              <div className="space-y-3">
                {generatedMusicList.map((track) => {
                  const isPlaying = activeMusicPlaying === track.id;
                  return (
                    <div
                      key={track.id}
                      className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-teal-300 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => {
                            if (track.audioUrl && audioPlayerRef.current) {
                              if (isPlaying) {
                                audioPlayerRef.current.pause();
                                setActiveMusicPlaying(null);
                              } else {
                                audioPlayerRef.current.src = track.audioUrl;
                                audioPlayerRef.current.play();
                                setActiveMusicPlaying(track.id);
                              }
                            } else {
                              playCalmingTone(track.id);
                            }
                          }}
                          className={`w-11 h-11 rounded-xl flex items-center justify-center shadow-xs cursor-pointer ${
                            isPlaying ? 'bg-teal-700 text-white animate-pulse' : 'bg-teal-600 text-white hover:bg-teal-700'
                          }`}
                        >
                          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                        </button>

                        <div>
                          <p className="font-bold text-slate-900 text-sm">{track.title}</p>
                          <p className="text-xs text-slate-500 leading-snug">{track.prompt}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-mono">
                              {track.mode === 'clip' ? 'lyria-3-clip-preview' : 'lyria-3-pro-preview'}
                            </span>
                            {track.lyrics && (
                              <span className="text-[11px] text-teal-700 italic">
                                🎶 "{track.lyrics}"
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 self-end sm:self-center">
                        {track.audioUrl && (
                          <a
                            href={track.audioUrl}
                            download={`${track.title}.wav`}
                            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold flex items-center space-x-1"
                          >
                            <Download className="w-4 h-4" />
                            <span className="hidden sm:inline">Save</span>
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Hidden HTML5 Audio element for stream playback */}
            <audio
              ref={audioPlayerRef}
              onEnded={() => setActiveMusicPlaying(null)}
              className="hidden"
            />
          </div>
        </div>
      )}

      {/* TAB 6: VEO VIDEO STUDIO (Text-to-Video & Animate Images to Video) */}
      {/* Model: veo-3.1-fast-generate-preview, Aspect Ratio: 16:9 or 9:16 */}
      {activeSubTab === 'video' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-2xs space-y-6">
            <div className="flex items-center space-x-2 text-teal-700">
              <Video className="w-6 h-6" />
              <h2 className="text-xl font-bold text-slate-900">
                Veo 3 Video Studio (veo-3.1-fast-generate-preview)
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Generate soothing wellness meditation videos from text prompts OR upload photos to animate nostalgic family portraits, garden memories, and scenic landscapes into dynamic videos.
            </p>

            {/* Mode Switch: Text-to-Video vs Animate Image into Video */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => setVideoMode('image-to-video')}
                className={`p-4 rounded-2xl border text-left transition cursor-pointer flex items-start space-x-3 ${
                  videoMode === 'image-to-video'
                    ? 'bg-teal-50/70 border-teal-500 ring-2 ring-teal-100'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-sm">Animate Images into Video</div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Upload a photo and bring elder memories or nature to life with Veo 3 motion
                  </div>
                </div>
              </button>

              <button
                onClick={() => setVideoMode('text-to-video')}
                className={`p-4 rounded-2xl border text-left transition cursor-pointer flex items-start space-x-3 ${
                  videoMode === 'text-to-video'
                    ? 'bg-teal-50/70 border-teal-500 ring-2 ring-teal-100'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0">
                  <Video className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-sm">Generate Video from Text</div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Create guided chair yoga, nature meditation, or peaceful sunrise videos
                  </div>
                </div>
              </button>
            </div>

            {/* Image Upload for Image-to-Video mode */}
            {videoMode === 'image-to-video' && (
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <label className="text-xs font-bold text-slate-700 block">
                  Select Photo to Animate (Family portrait, garden, pet, or landscape):
                </label>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {uploadedImagePreview ? (
                    <div className="relative w-36 h-28 rounded-xl overflow-hidden border-2 border-teal-500 shadow-sm shrink-0">
                      <img
                        src={uploadedImagePreview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        onClick={() => {
                          setUploadedImagePreview(null);
                          setUploadedImageBase64(null);
                        }}
                        className="absolute top-1 right-1 p-1 rounded-md bg-slate-900/80 text-white text-[10px] font-bold"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <label className="w-full sm:w-60 h-28 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-teal-500 hover:bg-teal-50/50 transition">
                      <Upload className="w-6 h-6 text-slate-400 mb-1" />
                      <span className="text-xs font-bold text-slate-600">Upload Photo</span>
                      <span className="text-[10px] text-slate-400">JPG or PNG</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                      />
                    </label>
                  )}

                  {/* Sample images */}
                  <div className="flex-1">
                    <span className="text-xs text-slate-500 font-semibold block mb-2">
                      Or pick a peaceful sample image:
                    </span>
                    <div className="flex gap-2">
                      {[
                        {
                          name: 'Spring Garden',
                          url: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400&auto=format&fit=crop',
                        },
                        {
                          name: 'Calm Lake',
                          url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&auto=format&fit=crop',
                        },
                        {
                          name: 'Elder Cup of Tea',
                          url: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&auto=format&fit=crop',
                        },
                      ].map((sample, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={async () => {
                            try {
                              setUploadedImagePreview(sample.url);
                              // Fetch sample as blob to convert to base64
                              const response = await fetch(sample.url);
                              const blob = await response.blob();
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                const b64 = (reader.result as string).split(',')[1];
                                setUploadedImageBase64(b64);
                              };
                              reader.readAsDataURL(blob);
                            } catch (e) {
                              setUploadedImagePreview(sample.url);
                              setUploadedImageBase64('sample');
                            }
                          }}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:border-teal-400 text-xs text-slate-700 font-medium cursor-pointer shadow-2xs"
                        >
                          🖼️ {sample.name}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Aspect Ratio Selector (Mandatory: 16:9 or 9:16) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 block">
                Select Video Aspect Ratio:
              </label>
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => setAspectRatio('16:9')}
                  className={`px-4 py-2.5 rounded-xl border text-xs font-bold flex items-center space-x-2 transition cursor-pointer ${
                    aspectRatio === '16:9'
                      ? 'bg-teal-600 text-white border-teal-600 shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <span className="w-4 h-2.5 border border-current rounded-xs inline-block" />
                  <span>16:9 Landscape (TV / Desktop View)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setAspectRatio('9:16')}
                  className={`px-4 py-2.5 rounded-xl border text-xs font-bold flex items-center space-x-2 transition cursor-pointer ${
                    aspectRatio === '9:16'
                      ? 'bg-teal-600 text-white border-teal-600 shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <span className="w-2.5 h-4 border border-current rounded-xs inline-block" />
                  <span>9:16 Portrait (Mobile Stories View)</span>
                </button>
              </div>
            </div>

            {/* Video Prompt Input */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 block">
                {videoMode === 'image-to-video'
                  ? 'Motion Guidance Prompt (How should the image move?):'
                  : 'Text Prompt for Veo 3 Video Generation:'}
              </label>
              <input
                type="text"
                value={videoPrompt}
                onChange={(e) => setVideoPrompt(e.target.value)}
                placeholder="e.g. Gentle sunlight streaming, leaves rustling softly, smooth camera pan..."
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none"
              />
            </div>

            {/* Generate Action Button */}
            <div>
              <button
                type="button"
                onClick={handleGenerateVideo}
                disabled={videoLoading}
                className="w-full sm:w-auto px-8 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-2xl shadow-md transition disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2"
              >
                {videoLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Video className="w-5 h-5" />}
                <span>
                  {videoLoading
                    ? videoStatusText || 'Generating Video with Veo 3...'
                    : videoMode === 'image-to-video'
                    ? 'Animate Image with Veo 3'
                    : 'Generate Video with Veo 3'}
                </span>
              </button>
            </div>

            {/* Status Feedback Banner */}
            {videoLoading && (
              <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 flex items-center space-x-3 text-teal-900 text-xs font-semibold">
                <Loader2 className="w-4 h-4 animate-spin text-teal-600 shrink-0" />
                <span>
                  {videoStatusText ||
                    'Veo 3 is processing high-resolution video frames in the background. This typically completes in a few moments.'}
                </span>
              </div>
            )}

            {/* Generated Videos Gallery */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Generated Video Gallery ({generatedVideos.length})
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {generatedVideos.map((vid) => (
                  <div
                    key={vid.id}
                    className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition flex flex-col justify-between"
                  >
                    {/* Video Player */}
                    <div
                      className={`relative bg-black flex items-center justify-center ${
                        vid.aspectRatio === '9:16' ? 'aspect-[9/16] max-h-[380px]' : 'aspect-video'
                      }`}
                    >
                      {vid.videoUrl ? (
                        <video
                          src={vid.videoUrl}
                          controls
                          loop
                          playsInline
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center space-y-2 text-slate-400 p-6">
                          <Loader2 className="w-6 h-6 animate-spin text-teal-400" />
                          <span className="text-xs">Rendering video frames...</span>
                        </div>
                      )}

                      {/* Aspect Ratio Badge */}
                      <span className="absolute top-2 left-2 text-[10px] font-mono px-2 py-0.5 rounded-md bg-black/60 text-white backdrop-blur-xs">
                        {vid.aspectRatio} • {vid.type === 'image-to-video' ? 'Photo Animated' : 'Text to Video'}
                      </span>
                    </div>

                    {/* Metadata & Controls */}
                    <div className="p-4 space-y-2">
                      <h4 className="font-bold text-slate-900 text-sm leading-snug">{vid.title}</h4>
                      <p className="text-xs text-slate-500 line-clamp-2">{vid.prompt}</p>

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-slate-400 text-[11px] font-mono">{vid.createdAt}</span>

                        {vid.videoUrl && (
                          <a
                            href={vid.videoUrl}
                            download={`${vid.title}.mp4`}
                            className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold flex items-center space-x-1.5 transition cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Download Video</span>
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: GEMINI IMAGE CREATION & EDITING STUDIO */}
      {activeSubTab === 'image' && <ImageStudioTab language={language} />}
    </div>
  );
};
