import React, { useState } from 'react';
import {
  Pill,
  Plus,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Calendar,
  Sparkles,
  Edit2,
  Trash2,
  Check,
  AlertCircle,
} from 'lucide-react';
import { Medicine, Language } from '../../types';
import { t } from '../../i18n';

interface MedicineViewProps {
  medicines: Medicine[];
  language: Language;
  onAddMedicine: (med: Partial<Medicine>) => void;
  onEditMedicine: (id: string, med: Partial<Medicine>) => void;
  onDeleteMedicine: (id: string) => void;
  onTakeDose: (medId: string) => void;
  onSkipDose: (medId: string) => void;
}

export const MedicineView: React.FC<MedicineViewProps> = ({
  medicines,
  language,
  onAddMedicine,
  onEditMedicine,
  onDeleteMedicine,
  onTakeDose,
  onSkipDose,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMed, setEditingMed] = useState<Medicine | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [frequency, setFrequency] = useState('Once daily');
  const [category, setCategory] = useState('Blood Pressure');
  const [timing, setTiming] = useState<'before_food' | 'after_food' | 'with_food' | 'anytime'>('after_food');
  const [timesStr, setTimesStr] = useState('08:00 AM');
  const [prescribingDoctor, setPrescribingDoctor] = useState('');
  const [notes, setNotes] = useState('');
  const [quantityRemaining, setQuantityRemaining] = useState(30);
  const [refillThreshold, setRefillThreshold] = useState(7);

  const allSchedules = medicines.flatMap((m) => m.schedules || []);
  const takenCount = allSchedules.filter((s) => s.status === 'taken').length;

  const openAdd = () => {
    setName('');
    setDosage('');
    setFrequency('Once daily');
    setCategory('Blood Pressure');
    setTiming('after_food');
    setTimesStr('08:00 AM');
    setPrescribingDoctor('');
    setNotes('');
    setQuantityRemaining(30);
    setRefillThreshold(7);
    setEditingMed(null);
    setShowAddModal(true);
  };

  const openEdit = (med: Medicine) => {
    setEditingMed(med);
    setName(med.name);
    setDosage(med.dosage);
    setFrequency(med.frequency);
    setCategory(med.category);
    setTiming(med.timing);
    setTimesStr(med.times.join(', '));
    setPrescribingDoctor(med.prescribingDoctor || '');
    setNotes(med.notes || '');
    setQuantityRemaining(med.quantityRemaining);
    setRefillThreshold(med.refillThreshold);
    setShowAddModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !dosage) return;

    const timesArray = timesStr.split(',').map((s) => s.trim()).filter(Boolean);

    const payload: Partial<Medicine> = {
      name,
      dosage,
      frequency,
      category,
      timing,
      times: timesArray.length > 0 ? timesArray : ['08:00 AM'],
      prescribingDoctor,
      notes,
      quantityRemaining: Number(quantityRemaining),
      refillThreshold: Number(refillThreshold),
    };

    if (editingMed) {
      onEditMedicine(editingMed.id, payload);
    } else {
      onAddMedicine(payload);
    }
    setShowAddModal(false);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('medicines', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Manage your daily doses, refill warnings, and medicine schedules.
          </p>
        </div>

        <button
          id="add-medicine-modal-btn"
          onClick={openAdd}
          className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-md shadow-teal-700/20 flex items-center space-x-2 cursor-pointer transition"
        >
          <Plus className="w-5 h-5" />
          <span>{t('addMedicine', language)}</span>
        </button>
      </div>

      {/* Medicine Cards List */}
      <div className="space-y-4">
        <h3 className="font-bold text-xl text-slate-900">{t('allMedicines', language)}</h3>

        {medicines.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
            <Pill className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-700 font-bold text-lg">No medicines added yet.</p>
            <p className="text-slate-500 text-sm mt-1 mb-4">
              Add your first prescription to receive audio reminders and timing schedules.
            </p>
            <button
              onClick={openAdd}
              className="px-6 py-2.5 bg-teal-600 text-white font-bold rounded-xl cursor-pointer"
            >
              + Add Medicine
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {medicines.map((med) => {
              const isLowRefill = med.quantityRemaining <= med.refillThreshold;
              return (
                <div
                  key={med.id}
                  className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-teal-300 transition flex flex-col justify-between"
                >
                  <div>
                    {/* Top Row: Category + Refill Alert */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-700 font-bold text-xs">
                        {med.category}
                      </span>
                      {isLowRefill ? (
                        <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 font-bold text-xs flex items-center space-x-1 animate-pulse">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Refill Alert ({med.quantityRemaining} left)</span>
                        </span>
                      ) : (
                        <span className="text-xs text-slate-500 font-semibold">
                          {med.quantityRemaining} pills remaining
                        </span>
                      )}
                    </div>

                    {/* Medicine details */}
                    <div className="mt-4 flex items-start space-x-3">
                      <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                        <Pill className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-display font-extrabold text-lg text-slate-900 leading-tight">
                          {med.name}
                        </h4>
                        <p className="text-sm font-bold text-teal-700 mt-0.5">{med.dosage}</p>
                        <p className="text-xs text-slate-600 mt-1">
                          <strong>Frequency:</strong> {med.frequency} •{' '}
                          <span className="capitalize">
                            {med.timing === 'after_food'
                              ? t('afterFood', language)
                              : med.timing === 'before_food'
                              ? t('beforeFood', language)
                              : med.timing}
                          </span>
                        </p>
                        {med.prescribingDoctor && (
                          <p className="text-xs text-slate-500 mt-0.5">
                            <strong>Doctor:</strong> {med.prescribingDoctor}
                          </p>
                        )}
                        {med.notes && (
                          <p className="text-xs text-slate-500 italic mt-1 bg-slate-50 p-2 rounded-xl">
                            “{med.notes}”
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Today's Schedule Times */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                        Today’s Doses:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {(med.schedules || []).map((sch) => (
                          <div
                            key={sch.id}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 ${
                              sch.status === 'taken'
                                ? 'bg-emerald-100 text-emerald-800'
                                : sch.status === 'skipped'
                                ? 'bg-slate-100 text-slate-500 line-through'
                                : 'bg-amber-100 text-amber-900 border border-amber-200'
                            }`}
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>{sch.time}</span>
                            <span>
                              {sch.status === 'taken'
                                ? '✓ Taken'
                                : sch.status === 'skipped'
                                ? 'Skipped'
                                : 'Due'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Actions footer */}
                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => openEdit(med)}
                        className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl cursor-pointer"
                        title="Edit Medicine"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete ${med.name}?`)) {
                            onDeleteMedicine(med.id);
                          }
                        }}
                        className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-xl cursor-pointer"
                        title="Delete Medicine"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => onSkipDose(med.id)}
                        className="px-3 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 cursor-pointer"
                      >
                        {t('markSkipped', language)}
                      </button>
                      <button
                        onClick={() => onTakeDose(med.id)}
                        className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 flex items-center space-x-1.5 shadow-xs cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>{t('markTaken', language)}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add / Edit Medicine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-display font-bold text-xl text-slate-900">
                {editingMed ? 'Edit Medicine' : t('addMedicine', language)}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t('medicineName', language)} *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Telmisartan 40mg, Metformin"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t('dosage', language)} *
                  </label>
                  <input
                    type="text"
                    required
                    value={dosage}
                    onChange={(e) => setDosage(e.target.value)}
                    placeholder="e.g. 1 Tablet (500mg)"
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t('category', language)}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-white"
                  >
                    <option value="Blood Pressure">Blood Pressure</option>
                    <option value="Diabetes">Diabetes</option>
                    <option value="Heart">Heart & Cholesterol</option>
                    <option value="Vitamins & Bone Health">Vitamins & Bone Health</option>
                    <option value="Thyroid">Thyroid</option>
                    <option value="Pain Relief">Pain Relief</option>
                    <option value="General">General</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t('frequency', language)}
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-white"
                  >
                    <option value="Once daily">Once daily</option>
                    <option value="Twice daily">Twice daily</option>
                    <option value="Thrice daily">Thrice daily</option>
                    <option value="Alternate days">Alternate days</option>
                    <option value="As needed (SOS)">As needed (SOS)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t('timing', language)}
                  </label>
                  <select
                    value={timing}
                    onChange={(e) => setTiming(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-white"
                  >
                    <option value="after_food">{t('afterFood', language)}</option>
                    <option value="before_food">{t('beforeFood', language)}</option>
                    <option value="with_food">{t('withFood', language)}</option>
                    <option value="anytime">{t('anytime', language)}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Daily Times (comma separated)
                </label>
                <input
                  type="text"
                  value={timesStr}
                  onChange={(e) => setTimesStr(e.target.value)}
                  placeholder="08:00 AM, 08:30 PM"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Quantity Remaining
                  </label>
                  <input
                    type="number"
                    value={quantityRemaining}
                    onChange={(e) => setQuantityRemaining(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Refill Alert Threshold
                  </label>
                  <input
                    type="number"
                    value={refillThreshold}
                    onChange={(e) => setRefillThreshold(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Prescribing Doctor
                </label>
                <input
                  type="text"
                  value={prescribingDoctor}
                  onChange={(e) => setPrescribingDoctor(e.target.value)}
                  placeholder="e.g. Dr. R. K. Joshi"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Notes / Instructions
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Take with warm water, avoid grapefruit..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md cursor-pointer"
                >
                  {editingMed ? 'Update Medicine' : 'Save Medicine'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
