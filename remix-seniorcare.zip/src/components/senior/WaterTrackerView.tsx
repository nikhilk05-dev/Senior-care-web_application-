import React, { useState } from 'react';
import {
  Droplets,
  Plus,
  Minus,
  RotateCcw,
  Settings,
  Sparkles,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';
import { WaterDay, Language } from '../../types';
import { t } from '../../i18n';
import { HydrationChart } from './HydrationChart';

interface WaterTrackerViewProps {
  waterToday: WaterDay;
  waterHistory?: WaterDay[];
  language: Language;
  onAddGlass: () => void;
  onRemoveGlass: () => void;
  onReset: () => void;
  onUpdateTarget: (targetMl: number) => void;
}

export const WaterTrackerView: React.FC<WaterTrackerViewProps> = ({
  waterToday,
  waterHistory,
  language,
  onAddGlass,
  onRemoveGlass,
  onReset,
  onUpdateTarget,
}) => {
  const safeWater: WaterDay = waterToday || {
    date: new Date().toISOString().split('T')[0],
    glasses: 0,
    consumedMl: 0,
    targetMl: 2000,
  };

  const [showTargetModal, setShowTargetModal] = useState(false);
  const [newTarget, setNewTarget] = useState(safeWater.targetMl || 2000);

  // Keep target input updated when prop changes
  React.useEffect(() => {
    if (waterToday?.targetMl) {
      setNewTarget(waterToday.targetMl);
    }
  }, [waterToday?.targetMl]);

  const targetMl = safeWater.targetMl > 0 ? safeWater.targetMl : 2000;
  const consumedMl = safeWater.consumedMl || 0;
  const glasses = safeWater.glasses || 0;
  const percentage = Math.min(100, Math.max(0, Math.round((consumedMl / targetMl) * 100)));
  const totalGlassesTarget = Math.round(targetMl / 250) || 8;

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('waterTracker', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Regular hydration supports kidney health, prevents dizziness, and regulates blood pressure.
          </p>
        </div>

        <button
          onClick={() => setShowTargetModal(true)}
          className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
        >
          <Settings className="w-4 h-4 text-slate-500" />
          <span>Adjust Daily Target ({targetMl} ml)</span>
        </button>
      </div>

      {/* Main Glass Visual & Tracker Card (Section 14) */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Animated Visual Water Glass */}
        <div className="lg:col-span-5 flex justify-center">
          <div className="relative w-48 h-72 rounded-b-3xl border-4 border-sky-400 bg-sky-50/40 p-2 overflow-hidden shadow-inner flex flex-col justify-end">
            {/* Water Wave Fill */}
            <div
              className="w-full bg-gradient-to-t from-sky-600 via-sky-500 to-sky-400 transition-all duration-700 rounded-b-2xl relative"
              style={{ height: `${percentage}%` }}
            >
              {/* Shine highlight */}
              <div className="absolute inset-x-0 top-0 h-2 bg-white/40 blur-xs" />
            </div>

            {/* Glass Markers */}
            <div className="absolute inset-y-4 right-2 flex flex-col justify-between text-[10px] font-mono font-bold text-sky-800 pointer-events-none">
              <span>{targetMl}ml</span>
              <span>{Math.round(targetMl * 0.75)}ml</span>
              <span>{Math.round(targetMl * 0.5)}ml</span>
              <span>{Math.round(targetMl * 0.25)}ml</span>
              <span>0ml</span>
            </div>

            {/* Percentage Display */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="font-display font-black text-4xl text-slate-900 drop-shadow-xs">
                {percentage}%
              </span>
              <span className="text-xs font-bold text-slate-700">of daily goal</span>
            </div>
          </div>
        </div>

        {/* Counter & Action Controls */}
        <div className="lg:col-span-7 space-y-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-3 py-1 rounded-full border border-sky-200">
              Today’s Hydration Progress
            </span>
            <div className="mt-3 flex items-baseline space-x-3">
              <span className="font-display font-black text-5xl text-slate-900">
                {consumedMl}
              </span>
              <span className="text-xl font-bold text-slate-500">/ {targetMl} ml</span>
            </div>
            <p className="text-base font-semibold text-slate-700 mt-2">
              💧 <strong>{glasses}</strong> of <strong>{totalGlassesTarget}</strong> glasses
              drank (250 ml each)
            </p>
          </div>

          {/* Large Senior-Friendly Controls */}
          <div className="flex flex-wrap gap-3 pt-2">
            <button
              id="water-add-btn"
              onClick={onAddGlass}
              className="flex-1 py-4 px-6 rounded-2xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-extrabold text-base shadow-lg shadow-sky-600/25 flex items-center justify-center space-x-2 cursor-pointer transition hover:scale-102"
            >
              <Plus className="w-6 h-6" />
              <span>{t('addGlass', language)} (+250ml)</span>
            </button>

            <button
              onClick={onRemoveGlass}
              disabled={glasses <= 0}
              className="py-4 px-5 rounded-2xl border-2 border-slate-200 bg-white hover:bg-slate-100 active:bg-slate-200 text-slate-700 font-bold text-base cursor-pointer disabled:opacity-40"
              title="Undo last glass"
            >
              <Minus className="w-5 h-5" />
            </button>

            <button
              onClick={onReset}
              className="py-4 px-4 rounded-2xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-500 hover:text-slate-800 cursor-pointer"
              title="Reset today's water"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {percentage >= 100 && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center space-x-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="font-bold text-sm">
                Congratulations! You have reached your recommended daily hydration goal!
              </span>
            </div>
          )}
        </div>
      </div>

      {/* 7-Day Hydration Progress vs Goal (Recharts Integration) */}
      <HydrationChart
        waterToday={waterToday}
        waterHistory={waterHistory}
        language={language}
        onAddGlass={onAddGlass}
      />

      {/* Target Modal */}
      {showTargetModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="font-bold text-lg text-slate-900 mb-1">Set Daily Hydration Target</h3>
            <p className="text-xs text-slate-500 mb-4">
              Physicians typically recommend 1,500 ml to 2,500 ml for senior adults unless fluid-restricted.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Target Volume (ml)
                </label>
                <input
                  type="number"
                  step="250"
                  min="500"
                  max="4000"
                  value={newTarget}
                  onChange={(e) => setNewTarget(Number(e.target.value))}
                  className="w-full p-3 rounded-xl border border-slate-200 text-lg font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowTargetModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    onUpdateTarget(newTarget);
                    setShowTargetModal(false);
                  }}
                  className="px-5 py-2 rounded-xl bg-teal-600 text-white font-bold text-xs shadow-md"
                >
                  Save Target
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
