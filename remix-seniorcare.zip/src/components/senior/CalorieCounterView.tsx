import React, { useState, useMemo } from 'react';
import {
  Utensils,
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Flame,
  CheckCircle2,
  Coffee,
  Sun,
  Sunset,
  Moon,
  Info,
  Sliders,
  X,
  History,
  Check,
  Sparkles,
} from 'lucide-react';
import { User, Language, CalorieRecord, FoodItem, MealType } from '../../types';

interface CalorieCounterViewProps {
  user: User;
  language: Language;
  calorieRecords: CalorieRecord[];
  foods?: FoodItem[];
  onAddRecord: (record: Omit<CalorieRecord, 'id' | 'createdAt'>) => Promise<void> | void;
  onUpdateRecord?: (id: string, updates: Partial<CalorieRecord>) => Promise<void> | void;
  onDeleteRecord: (id: string) => Promise<void> | void;
  onUpdateProfile: (profile: {
    age?: number;
    gender?: string;
    height?: number;
    weight?: number;
    activityLevel?: 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active';
    dailyCalorieGoal?: number;
  }) => Promise<void> | void;
  onAddFoodToDatabase?: (food: Omit<FoodItem, 'id'>) => Promise<void> | void;
  isCaregiverOrFamily?: boolean;
  seniorName?: string;
}

// 12 Common, wholesome senior foods for instant 1-tap logging
const POPULAR_SENIOR_FOODS = [
  { name: 'Oatmeal with Milk', calories: 180, icon: '🥣', meal: 'breakfast' as MealType },
  { name: 'Boiled Egg', calories: 78, icon: '🥚', meal: 'breakfast' as MealType },
  { name: 'Toast & Butter', calories: 120, icon: '🍞', meal: 'breakfast' as MealType },
  { name: 'Roti & Dal', calories: 250, icon: '🫓', meal: 'lunch' as MealType },
  { name: 'Rice & Vegetables', calories: 280, icon: '🍚', meal: 'lunch' as MealType },
  { name: 'Vegetable Khichdi', calories: 220, icon: '🥘', meal: 'lunch' as MealType },
  { name: 'Fresh Banana', calories: 105, icon: '🍌', meal: 'snacks' as MealType },
  { name: 'Fresh Apple', calories: 95, icon: '🍎', meal: 'snacks' as MealType },
  { name: 'Chai / Tea', calories: 40, icon: '☕', meal: 'snacks' as MealType },
  { name: 'Plain Curd / Yogurt', calories: 100, icon: '🥛', meal: 'snacks' as MealType },
  { name: 'Clear Vegetable Soup', calories: 80, icon: '🍲', meal: 'dinner' as MealType },
  { name: 'Warm Turmeric Milk', calories: 130, icon: '🥛', meal: 'dinner' as MealType },
];

export const CalorieCounterView: React.FC<CalorieCounterViewProps> = ({
  user,
  calorieRecords,
  onAddRecord,
  onDeleteRecord,
  onUpdateProfile,
  isCaregiverOrFamily,
  seniorName,
}) => {
  // Selected Date (defaults to today)
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);

  // Tab: 'tracker' or 'history'
  const [activeTab, setActiveTab] = useState<'tracker' | 'history'>('tracker');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [targetMeal, setTargetMeal] = useState<MealType>('breakfast');
  const [customFoodName, setCustomFoodName] = useState('');
  const [customCalories, setCustomCalories] = useState<number>(150);

  // Direct quick calorie logger state
  const [quickCalAmount, setQuickCalAmount] = useState<string>('');
  const [quickMealTarget, setQuickMealTarget] = useState<MealType>('snacks');

  // Goal modal state
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [goalInput, setGoalInput] = useState<number>(user.dailyCalorieGoal || 1800);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const dailyGoal = user.dailyCalorieGoal || 1800;

  // Filter records for selected date
  const recordsForDate = useMemo(() => {
    return calorieRecords.filter((r) => r.date === selectedDate);
  }, [calorieRecords, selectedDate]);

  // Total calories eaten today
  const totalCaloriesEaten = useMemo(() => {
    return recordsForDate.reduce((sum, r) => sum + (r.calories || 0), 0);
  }, [recordsForDate]);

  const caloriesRemaining = Math.max(0, dailyGoal - totalCaloriesEaten);
  const progressPercent = Math.min(100, Math.round((totalCaloriesEaten / dailyGoal) * 100));

  // Meal breakdown
  const mealRecords = useMemo(() => {
    return {
      breakfast: recordsForDate.filter((r) => (r.mealType || '').toLowerCase() === 'breakfast'),
      lunch: recordsForDate.filter((r) => (r.mealType || '').toLowerCase() === 'lunch'),
      snacks: recordsForDate.filter((r) => (r.mealType || '').toLowerCase() === 'snacks'),
      dinner: recordsForDate.filter((r) => (r.mealType || '').toLowerCase() === 'dinner'),
    };
  }, [recordsForDate]);

  const mealCalories = useMemo(() => {
    return {
      breakfast: mealRecords.breakfast.reduce((sum, r) => sum + (r.calories || 0), 0),
      lunch: mealRecords.lunch.reduce((sum, r) => sum + (r.calories || 0), 0),
      snacks: mealRecords.snacks.reduce((sum, r) => sum + (r.calories || 0), 0),
      dinner: mealRecords.dinner.reduce((sum, r) => sum + (r.calories || 0), 0),
    };
  }, [mealRecords]);

  // Date controls
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const formattedDateTitle = useMemo(() => {
    if (selectedDate === todayStr) return 'Today';
    const parts = selectedDate.split('-');
    if (parts.length === 3) {
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    }
    return selectedDate;
  }, [selectedDate, todayStr]);

  // 1-Tap Quick Add popular food
  const handleQuickAddFood = async (item: typeof POPULAR_SENIOR_FOODS[0]) => {
    await onAddRecord({
      userId: user.id || 'user_senior_1',
      date: selectedDate,
      foodName: item.name,
      mealType: item.meal,
      quantity: 1,
      servingUnit: 'serving',
      calories: item.calories,
    });
    showToast(`Added ${item.name} (${item.calories} kcal) to ${item.meal.toUpperCase()}!`);
  };

  // Direct quick calorie entry
  const handleDirectAddCalories = async (cals: number, meal: MealType) => {
    if (cals <= 0) return;
    await onAddRecord({
      userId: user.id || 'user_senior_1',
      date: selectedDate,
      foodName: `Quick Entry (${cals} kcal)`,
      mealType: meal,
      quantity: 1,
      servingUnit: 'entry',
      calories: cals,
    });
    setQuickCalAmount('');
    showToast(`Added ${cals} kcal to ${meal.toUpperCase()}!`);
  };

  // Open custom food modal
  const handleOpenAddModal = (meal: MealType) => {
    setTargetMeal(meal);
    setCustomFoodName('');
    setCustomCalories(150);
    setIsAddModalOpen(true);
  };

  // Save custom food
  const handleSaveCustomFood = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customFoodName.trim() || customCalories <= 0) return;

    await onAddRecord({
      userId: user.id || 'user_senior_1',
      date: selectedDate,
      foodName: customFoodName.trim(),
      mealType: targetMeal,
      quantity: 1,
      servingUnit: 'serving',
      calories: Math.round(customCalories),
    });

    setIsAddModalOpen(false);
    showToast(`Added ${customFoodName} (${customCalories} kcal) to ${targetMeal}!`);
  };

  // Save Goal
  const handleSaveGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (goalInput < 1000 || goalInput > 3500) return;
    await onUpdateProfile({ dailyCalorieGoal: goalInput });
    setIsGoalModalOpen(false);
    showToast(`Daily calorie target set to ${goalInput} kcal!`);
  };

  // 7-day history list
  const pastSevenDays = useMemo(() => {
    const list: { dateStr: string; label: string; calories: number; isToday: boolean }[] = [];
    const base = new Date();
    for (let i = 0; i < 7; i++) {
      const d = new Date(base);
      d.setDate(d.getDate() - i);
      const iso = d.toISOString().split('T')[0];
      const dayName = i === 0 ? 'Today' : i === 1 ? 'Yesterday' : d.toLocaleDateString('en-US', { weekday: 'long' });
      const dayCalories = calorieRecords
        .filter((r) => r.date === iso)
        .reduce((sum, r) => sum + (r.calories || 0), 0);
      list.push({
        dateStr: iso,
        label: `${dayName} (${iso})`,
        calories: dayCalories,
        isToday: i === 0,
      });
    }
    return list;
  }, [calorieRecords]);

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 flex items-center space-x-2 px-5 py-3 rounded-2xl bg-teal-700 text-white font-bold text-sm shadow-xl animate-fade-in border border-teal-500">
          <CheckCircle2 className="w-5 h-5 text-teal-200" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-orange-100 text-orange-800 border border-orange-200 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-orange-600" />
              <span>Simple Calorie Tracker</span>
            </span>
            {isCaregiverOrFamily && seniorName && (
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200">
                Viewing for: {seniorName}
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-display font-black text-slate-900 mt-1">
            Easy Daily Calorie Counter
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-0.5">
            Simple 1-tap food logging designed for beginners and seniors.
          </p>
        </div>

        {/* Date Selector & Goal Button */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Day Navigator */}
          <div className="flex items-center bg-slate-100 rounded-2xl p-1 border border-slate-200">
            <button
              onClick={handlePrevDay}
              className="p-2 rounded-xl text-slate-700 hover:bg-white transition cursor-pointer"
              title="Previous Day"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="px-3 py-1 text-center min-w-[120px]">
              <span className="text-sm font-extrabold text-slate-900 block">{formattedDateTitle}</span>
              <span className="text-[10px] text-slate-500 font-mono block">{selectedDate}</span>
            </div>
            <button
              onClick={handleNextDay}
              className="p-2 rounded-xl text-slate-700 hover:bg-white transition cursor-pointer"
              title="Next Day"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {selectedDate !== todayStr && (
            <button
              onClick={() => setSelectedDate(todayStr)}
              className="px-3 py-2 text-xs font-bold text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-xl transition cursor-pointer"
            >
              Today
            </button>
          )}

          {/* Goal Shortcut Button */}
          <button
            onClick={() => {
              setGoalInput(dailyGoal);
              setIsGoalModalOpen(true);
            }}
            className="flex items-center space-x-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs sm:text-sm font-bold shadow-xs transition cursor-pointer"
          >
            <span>Goal: {dailyGoal} kcal</span>
            <Sliders className="w-3.5 h-3.5 text-orange-400" />
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex space-x-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('tracker')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-sm font-bold transition cursor-pointer ${
            activeTab === 'tracker'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Utensils className="w-4 h-4" />
          <span>Today's Meals</span>
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-sm font-bold transition cursor-pointer ${
            activeTab === 'history'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Past 7 Days History</span>
        </button>
      </div>

      {activeTab === 'tracker' ? (
        <>
          {/* BIG FRIENDLY CALORIE METER (Beginner Friendly) */}
          <div className="bg-gradient-to-r from-teal-800 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-white/10 gap-2">
              <div>
                <span className="text-xs uppercase font-extrabold tracking-wider text-teal-200 block">
                  Daily Calorie Balance
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-white mt-0.5">
                  {formattedDateTitle} Summary
                </h2>
              </div>
              <div className="text-xs text-teal-200 bg-white/10 px-3.5 py-1.5 rounded-full border border-white/10 self-start sm:self-auto font-medium">
                Standard senior range: 1,600 – 2,000 kcal / day
              </div>
            </div>

            {/* 3 Big Numbers */}
            <div className="grid grid-cols-3 gap-3 sm:gap-4 mt-5 text-center">
              {/* Daily Target */}
              <div className="bg-white/10 border border-white/10 rounded-2xl p-3 sm:p-4">
                <span className="text-[11px] sm:text-xs text-slate-300 font-bold uppercase tracking-wider block">
                  Daily Goal
                </span>
                <span className="text-2xl sm:text-3xl font-black text-white mt-1 block">
                  {dailyGoal}
                </span>
                <span className="text-[10px] sm:text-xs text-slate-300 font-semibold">kcal target</span>
              </div>

              {/* Consumed */}
              <div className="bg-teal-600/40 border border-teal-400/40 rounded-2xl p-3 sm:p-4">
                <span className="text-[11px] sm:text-xs text-teal-200 font-bold uppercase tracking-wider block">
                  Eaten Today
                </span>
                <span className="text-2xl sm:text-3xl font-black text-teal-100 mt-1 block">
                  {totalCaloriesEaten}
                </span>
                <span className="text-[10px] sm:text-xs text-teal-200 font-semibold">kcal consumed</span>
              </div>

              {/* Remaining */}
              <div className="bg-white/10 border border-white/10 rounded-2xl p-3 sm:p-4">
                <span className="text-[11px] sm:text-xs text-slate-300 font-bold uppercase tracking-wider block">
                  Left To Eat
                </span>
                <span className="text-2xl sm:text-3xl font-black text-orange-300 mt-1 block">
                  {caloriesRemaining}
                </span>
                <span className="text-[10px] sm:text-xs text-slate-300 font-semibold">kcal remaining</span>
              </div>
            </div>

            {/* Progress Bar & Gentle Guidance */}
            <div className="mt-5 space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-slate-200">
                <span>Progress: {progressPercent}% of goal</span>
                <span>
                  {totalCaloriesEaten >= dailyGoal
                    ? 'Target reached! 🎉 Great job eating healthy.'
                    : `${caloriesRemaining} kcal remaining today`}
                </span>
              </div>

              <div className="w-full h-4 bg-black/40 rounded-full overflow-hidden border border-white/10">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    progressPercent >= 100
                      ? 'bg-emerald-400'
                      : progressPercent >= 75
                      ? 'bg-teal-400'
                      : 'bg-orange-400'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* 1-TAP QUICK FOOD ADDER (Designed for Beginners) */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-orange-500" />
                <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                  1-Tap Popular Senior Foods
                </h3>
              </div>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                Tap any food to add it instantly
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
              {POPULAR_SENIOR_FOODS.map((item) => (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => handleQuickAddFood(item)}
                  className="p-3 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-teal-50 hover:border-teal-300 transition text-left flex items-center space-x-3 cursor-pointer group active:scale-95"
                >
                  <span className="text-2xl shrink-0 group-hover:scale-110 transition">{item.icon}</span>
                  <div className="overflow-hidden">
                    <span className="text-xs font-bold text-slate-800 block truncate group-hover:text-teal-900">
                      {item.name}
                    </span>
                    <span className="text-[11px] font-semibold text-orange-700 block">
                      +{item.calories} kcal ({item.meal})
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* QUICK DIRECT CALORIE LOGGER */}
          <div className="bg-gradient-to-r from-orange-50/80 to-amber-50/60 rounded-3xl p-5 border border-orange-200/80 shadow-2xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-orange-950">
                  Quick Calorie Logger (No food name required)
                </h3>
                <p className="text-xs text-orange-800">
                  Know the calories? Tap a quick button or type an amount.
                </p>
              </div>

              {/* Meal Selector for Quick Entry */}
              <div className="flex items-center space-x-1 bg-white p-1 rounded-xl border border-orange-200 self-start sm:self-auto">
                {(['breakfast', 'lunch', 'snacks', 'dinner'] as MealType[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setQuickMealTarget(m)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase transition cursor-pointer ${
                      quickMealTarget === m
                        ? 'bg-orange-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:bg-orange-50'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick buttons */}
            <div className="flex flex-wrap items-center gap-2">
              {[50, 100, 150, 200, 250, 300].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => handleDirectAddCalories(c, quickMealTarget)}
                  className="px-3.5 py-2 rounded-xl bg-white hover:bg-orange-100 text-orange-900 font-bold text-xs border border-orange-300 shadow-2xs transition cursor-pointer active:scale-95"
                >
                  +{c} kcal
                </button>
              ))}

              {/* Custom direct input */}
              <div className="flex items-center space-x-1.5 ml-auto">
                <input
                  type="number"
                  placeholder="e.g. 180"
                  value={quickCalAmount}
                  onChange={(e) => setQuickCalAmount(e.target.value)}
                  className="w-24 px-3 py-1.5 rounded-xl border border-orange-300 bg-white text-xs font-bold outline-none focus:ring-2 focus:ring-orange-200"
                />
                <button
                  type="button"
                  onClick={() => {
                    const num = parseInt(quickCalAmount, 10);
                    if (num > 0) handleDirectAddCalories(num, quickMealTarget);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-2xs cursor-pointer"
                >
                  Add
                </button>
              </div>
            </div>
          </div>

          {/* 4 SIMPLE MEAL CARDS (Breakfast, Lunch, Snacks, Dinner) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Breakfast */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center space-x-2.5">
                    <span className="p-2.5 rounded-2xl bg-amber-100 text-amber-800">
                      <Coffee className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-lg text-slate-900">Breakfast</h3>
                      <p className="text-xs text-slate-500">Morning Meal</p>
                    </div>
                  </div>
                  <span className="text-sm font-extrabold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                    {mealCalories.breakfast} kcal
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  {mealRecords.breakfast.length === 0 ? (
                    <p className="text-xs text-slate-400 py-5 text-center italic">
                      No breakfast recorded yet.
                    </p>
                  ) : (
                    mealRecords.breakfast.map((rec) => (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900 block text-sm">
                            {rec.foodName}
                          </span>
                          <span className="text-slate-500">
                            {rec.calories} kcal
                          </span>
                        </div>
                        <button
                          onClick={() => onDeleteRecord(rec.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <button
                onClick={() => handleOpenAddModal('breakfast')}
                className="mt-4 w-full py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:bg-teal-200 text-teal-800 font-bold text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer border border-teal-200"
              >
                <Plus className="w-4 h-4" />
                <span>+ Add Item to Breakfast</span>
              </button>
            </div>

            {/* Lunch */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center space-x-2.5">
                    <span className="p-2.5 rounded-2xl bg-orange-100 text-orange-800">
                      <Sun className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-lg text-slate-900">Lunch</h3>
                      <p className="text-xs text-slate-500">Afternoon Meal</p>
                    </div>
                  </div>
                  <span className="text-sm font-extrabold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                    {mealCalories.lunch} kcal
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  {mealRecords.lunch.length === 0 ? (
                    <p className="text-xs text-slate-400 py-5 text-center italic">
                      No lunch recorded yet.
                    </p>
                  ) : (
                    mealRecords.lunch.map((rec) => (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900 block text-sm">
                            {rec.foodName}
                          </span>
                          <span className="text-slate-500">
                            {rec.calories} kcal
                          </span>
                        </div>
                        <button
                          onClick={() => onDeleteRecord(rec.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <button
                onClick={() => handleOpenAddModal('lunch')}
                className="mt-4 w-full py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:bg-teal-200 text-teal-800 font-bold text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer border border-teal-200"
              >
                <Plus className="w-4 h-4" />
                <span>+ Add Item to Lunch</span>
              </button>
            </div>

            {/* Snacks */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center space-x-2.5">
                    <span className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800">
                      <Sunset className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-lg text-slate-900">Snacks & Tea</h3>
                      <p className="text-xs text-slate-500">Evening Refreshment</p>
                    </div>
                  </div>
                  <span className="text-sm font-extrabold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                    {mealCalories.snacks} kcal
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  {mealRecords.snacks.length === 0 ? (
                    <p className="text-xs text-slate-400 py-5 text-center italic">
                      No snacks recorded yet.
                    </p>
                  ) : (
                    mealRecords.snacks.map((rec) => (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900 block text-sm">
                            {rec.foodName}
                          </span>
                          <span className="text-slate-500">
                            {rec.calories} kcal
                          </span>
                        </div>
                        <button
                          onClick={() => onDeleteRecord(rec.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <button
                onClick={() => handleOpenAddModal('snacks')}
                className="mt-4 w-full py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:bg-teal-200 text-teal-800 font-bold text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer border border-teal-200"
              >
                <Plus className="w-4 h-4" />
                <span>+ Add Item to Snacks</span>
              </button>
            </div>

            {/* Dinner */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center space-x-2.5">
                    <span className="p-2.5 rounded-2xl bg-indigo-100 text-indigo-800">
                      <Moon className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-lg text-slate-900">Dinner</h3>
                      <p className="text-xs text-slate-500">Light Night Meal</p>
                    </div>
                  </div>
                  <span className="text-sm font-extrabold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                    {mealCalories.dinner} kcal
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  {mealRecords.dinner.length === 0 ? (
                    <p className="text-xs text-slate-400 py-5 text-center italic">
                      No dinner recorded yet.
                    </p>
                  ) : (
                    mealRecords.dinner.map((rec) => (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900 block text-sm">
                            {rec.foodName}
                          </span>
                          <span className="text-slate-500">
                            {rec.calories} kcal
                          </span>
                        </div>
                        <button
                          onClick={() => onDeleteRecord(rec.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <button
                onClick={() => handleOpenAddModal('dinner')}
                className="mt-4 w-full py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:bg-teal-200 text-teal-800 font-bold text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer border border-teal-200"
              >
                <Plus className="w-4 h-4" />
                <span>+ Add Item to Dinner</span>
              </button>
            </div>
          </div>
        </>
      ) : (
        /* SIMPLE 7-DAY HISTORY VIEW */
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-xl font-bold text-slate-900">Last 7 Days History</h3>
              <p className="text-xs text-slate-500">Click any day to view or edit meals.</p>
            </div>
            <span className="text-xs font-bold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
              Daily Target: {dailyGoal} kcal
            </span>
          </div>

          <div className="space-y-3">
            {pastSevenDays.map((d) => {
              const pct = Math.min(100, Math.round((d.calories / dailyGoal) * 100));
              const isSelected = d.dateStr === selectedDate;

              return (
                <div
                  key={d.dateStr}
                  onClick={() => {
                    setSelectedDate(d.dateStr);
                    setActiveTab('tracker');
                  }}
                  className={`p-4 rounded-2xl border transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-teal-50 border-teal-400 ring-2 ring-teal-200'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div>
                    <span className="font-extrabold text-slate-900 text-sm sm:text-base block">
                      {d.label}
                    </span>
                    <span className="text-xs text-slate-500">
                      {d.calories > 0 ? `${d.calories} kcal recorded` : 'No food logged'}
                    </span>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="w-32 bg-slate-200 rounded-full h-2.5 overflow-hidden">
                      <div
                        className="bg-teal-600 h-full rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-xs font-bold text-slate-700 min-w-[50px] text-right">
                      {pct}%
                    </span>
                    <span className="text-xs font-bold text-teal-700 hover:underline">
                      View →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Helpful Friendly Tip */}
      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-center space-x-3">
        <Info className="w-5 h-5 text-amber-700 shrink-0" />
        <p className="leading-relaxed">
          <strong>Doctor & Wellness Note:</strong> Calorie goals are approximate recommendations for senior wellness. If you have specific dietary guidelines from your doctor (for diabetes, blood pressure, or kidney care), always prioritize those.
        </p>
      </div>

      {/* ======================================================== */}
      {/* SIMPLE ADD FOOD MODAL */}
      {/* ======================================================== */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 bg-teal-800 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-lg sm:text-xl">
                  Add Item to {targetMeal.toUpperCase()}
                </h3>
                <p className="text-xs text-teal-200">
                  Type what you ate and approximate calories
                </p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 text-teal-200 hover:text-white rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomFood} className="p-5 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Food Name
                </label>
                <input
                  type="text"
                  required
                  value={customFoodName}
                  onChange={(e) => setCustomFoodName(e.target.value)}
                  placeholder="e.g. Vegetable Soup, Chapati, Glass of Milk"
                  className="w-full p-3 rounded-xl border border-slate-200 text-sm font-semibold focus:border-teal-600 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Estimated Calories (kcal)
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  value={customCalories}
                  onChange={(e) => setCustomCalories(Math.max(1, Number(e.target.value)))}
                  className="w-full p-3 rounded-xl border border-slate-200 text-base font-extrabold focus:border-teal-600 outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-md cursor-pointer flex items-center space-x-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Save Food</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SIMPLE DAILY GOAL MODAL */}
      {/* ======================================================== */}
      {isGoalModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-lg">Set Daily Calorie Target</h3>
                <p className="text-xs text-slate-400">Pick a senior preset or enter your custom goal</p>
              </div>
              <button
                onClick={() => setIsGoalModalOpen(false)}
                className="p-2 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGoal} className="p-5 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-2">
                  1-Tap Standard Senior Presets:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: '1,600 kcal', desc: 'Gentle', val: 1600 },
                    { label: '1,800 kcal', desc: 'Standard', val: 1800 },
                    { label: '2,000 kcal', desc: 'Active', val: 2000 },
                  ].map((preset) => (
                    <button
                      type="button"
                      key={preset.val}
                      onClick={() => setGoalInput(preset.val)}
                      className={`p-3 rounded-xl border text-center transition cursor-pointer ${
                        goalInput === preset.val
                          ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                          : 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-teal-50'
                      }`}
                    >
                      <span className="font-black text-sm block">{preset.label}</span>
                      <span className={`text-[10px] ${goalInput === preset.val ? 'text-teal-100' : 'text-slate-500'}`}>
                        {preset.desc}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Custom Daily Calorie Target (kcal):
                </label>
                <input
                  type="number"
                  required
                  min={1000}
                  max={3500}
                  value={goalInput}
                  onChange={(e) => setGoalInput(Number(e.target.value))}
                  className="w-full p-3 rounded-xl border border-slate-200 text-base font-extrabold focus:border-teal-600 outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsGoalModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md cursor-pointer"
                >
                  Save Target
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
