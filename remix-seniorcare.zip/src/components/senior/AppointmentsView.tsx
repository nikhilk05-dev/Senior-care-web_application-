import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  MapPin,
  FileText,
  CheckCircle,
  XCircle,
  Bell,
  Trash2,
} from 'lucide-react';
import { Appointment, Language } from '../../types';
import { t } from '../../i18n';

interface AppointmentsViewProps {
  appointments: Appointment[];
  language: Language;
  onAddAppointment: (appt: Partial<Appointment>) => void;
  onCancelAppointment: (id: string) => void;
  onCompleteAppointment: (id: string) => void;
  onToggleReminder: (id: string) => void;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  appointments,
  language,
  onAddAppointment,
  onCancelAppointment,
  onCompleteAppointment,
  onToggleReminder,
}) => {
  const [filter, setFilter] = useState<'upcoming' | 'completed' | 'cancelled'>('upcoming');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [doctorName, setDoctorName] = useState('');
  const [clinic, setClinic] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [appointmentTime, setAppointmentTime] = useState('');
  const [purpose, setPurpose] = useState('');
  const [preparationNotes, setPreparationNotes] = useState('');

  const filteredAppointments = appointments.filter((a) => a.status === filter);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!doctorName || !appointmentDate || !appointmentTime) return;

    onAddAppointment({
      doctorName,
      clinic,
      appointmentDate,
      appointmentTime,
      purpose,
      preparationNotes,
      status: 'upcoming',
      reminderNotification: true,
    });

    setDoctorName('');
    setClinic('');
    setAppointmentDate('');
    setAppointmentTime('');
    setPurpose('');
    setPreparationNotes('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('appointments', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Organize doctor visits, clinic appointments, and diagnostic lab tests.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-md shadow-teal-700/20 flex items-center space-x-2 cursor-pointer transition"
        >
          <Plus className="w-5 h-5" />
          <span>{t('bookAppointment', language)}</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex space-x-2 border-b border-slate-200 pb-3">
        {(['upcoming', 'completed', 'cancelled'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-xl font-bold text-sm capitalize transition cursor-pointer ${
              filter === status
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {status} ({appointments.filter((a) => a.status === status).length})
          </button>
        ))}
      </div>

      {/* Appointment Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAppointments.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white rounded-3xl border border-slate-200">
            <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-700 font-bold text-lg">No {filter} appointments.</p>
          </div>
        ) : (
          filteredAppointments.map((appt) => (
            <div
              key={appt.id}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold capitalize ${
                      appt.status === 'upcoming'
                        ? 'bg-teal-100 text-teal-800'
                        : appt.status === 'completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {appt.status}
                  </span>

                  <button
                    onClick={() => onToggleReminder(appt.id)}
                    className={`p-1.5 rounded-xl border flex items-center space-x-1 text-xs cursor-pointer ${
                      appt.reminderNotification
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-slate-50 text-slate-400 border-slate-200'
                    }`}
                    title="Toggle Reminder Notification"
                  >
                    <Bell className="w-3.5 h-3.5" />
                    <span>{appt.reminderNotification ? 'Alert On' : 'Alert Off'}</span>
                  </button>
                </div>

                <div className="mt-4 flex items-start space-x-3">
                  <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                    <Calendar className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-lg text-slate-900">{appt.doctorName}</h3>
                    <p className="text-sm font-semibold text-slate-600 flex items-center space-x-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{appt.clinic}</span>
                    </p>
                    <p className="text-xs font-bold text-teal-700 mt-2">
                      📅 {appt.appointmentDate} at {appt.appointmentTime}
                    </p>
                  </div>
                </div>

                {appt.purpose && (
                  <p className="text-xs text-slate-700 mt-3 font-medium">
                    <strong>Purpose:</strong> {appt.purpose}
                  </p>
                )}

                {appt.preparationNotes && (
                  <div className="mt-3 p-3 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-xs text-amber-900">
                    <strong>Preparation Notes:</strong> {appt.preparationNotes}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              {appt.status === 'upcoming' && (
                <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end gap-2">
                  <button
                    onClick={() => onCancelAppointment(appt.id)}
                    className="px-3.5 py-2 rounded-xl text-xs font-bold text-rose-700 hover:bg-rose-50 border border-rose-200 cursor-pointer"
                  >
                    Cancel Visit
                  </button>
                  <button
                    onClick={() => onCompleteAppointment(appt.id)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 cursor-pointer shadow-xs"
                  >
                    Mark Completed
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Add Appointment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-display font-bold text-xl text-slate-900">
                {t('bookAppointment', language)}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Doctor / Specialist Name *
                </label>
                <input
                  type="text"
                  required
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  placeholder="e.g. Dr. A. K. Joshi (Cardiologist)"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Hospital / Clinic Address
                </label>
                <input
                  type="text"
                  value={clinic}
                  onChange={(e) => setClinic(e.target.value)}
                  placeholder="e.g. City Care Hospital, 2nd Floor, Room 204"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Time *
                  </label>
                  <input
                    type="time"
                    required
                    value={appointmentTime}
                    onChange={(e) => setAppointmentTime(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Purpose of Visit
                </label>
                <input
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Routine 3-month Hypertension Review"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Preparation Instructions
                </label>
                <textarea
                  rows={2}
                  value={preparationNotes}
                  onChange={(e) => setPreparationNotes(e.target.value)}
                  placeholder="e.g. Fasting 10 hours required for lipid panel, bring past ECG reports..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md cursor-pointer"
                >
                  Schedule Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
