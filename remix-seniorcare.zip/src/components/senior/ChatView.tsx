import React, { useState } from 'react';
import {
  Send,
  User,
  Heart,
  PhoneCall,
  Smile,
  CheckCheck,
  Clock,
  Sparkles,
  Type,
} from 'lucide-react';
import { DirectMessage, Language } from '../../types';

interface ChatViewProps {
  currentUserId: string;
  currentUserName: string;
  currentUserRole: string;
  messages: DirectMessage[];
  language: Language;
  onSendMessage: (receiverId: string, receiverName: string, text: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  currentUserId,
  currentUserName,
  currentUserRole,
  messages,
  language,
  onSendMessage,
}) => {
  const [activePartner, setActivePartner] = useState<'family' | 'caregiver'>('family');
  const [inputText, setInputText] = useState('');
  const [largeTextMode, setLargeTextMode] = useState(false);

  const familyId = 'user_family_1';
  const familyName = 'Priya Patel (Daughter)';

  const caregiverId = 'user_caregiver_1';
  const caregiverName = 'Sister Sunita Rao (Caregiver)';

  const targetId = activePartner === 'family' ? familyId : caregiverId;
  const targetName = activePartner === 'family' ? familyName : caregiverName;

  // Filter messages for active chat partner
  const currentThread = messages.filter(
    (m) =>
      (m.senderId === currentUserId && m.receiverId === targetId) ||
      (m.senderId === targetId && m.receiverId === currentUserId)
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    onSendMessage(targetId, targetName, inputText.trim());
    setInputText('');
  };

  const handleQuickSend = (text: string) => {
    onSendMessage(targetId, targetName, text);
  };

  // Senior Quick Reply Presets
  const quickResponses = [
    { label: 'Taken Tablets', text: 'I took all my scheduled tablets with water! Feeling good.' },
    { label: 'Feeling Healthy', text: 'Good morning beta! I am feeling active and peaceful today.' },
    { label: 'Please Call Me', text: 'When you are free, please give me a quick phone call.' },
    { label: 'Water Done', text: 'I have finished 5 glasses of warm water already today.' },
    { label: 'Medicine Refill', text: 'My BP tablets have only 4 days supply remaining. Can you order refill?' },
  ];

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            Family & Caregiver Messages
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Stay in warm, direct contact with your daughter Priya and care attendant Sister Sunita.
          </p>
        </div>

        {/* Accessibility Large Font Toggle */}
        <button
          onClick={() => setLargeTextMode(!largeTextMode)}
          className={`px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center space-x-2 border transition cursor-pointer ${
            largeTextMode
              ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Type className="w-4 h-4" />
          <span>{largeTextMode ? 'Large Senior Font: ON' : 'Standard Font'}</span>
        </button>
      </div>

      {/* Main Chat Box */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[640px]">
        {/* Chat partner selection header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              {activePartner === 'family' ? 'P' : 'S'}
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">{targetName}</h3>
              <p className="text-xs text-emerald-600 font-bold flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Active & Caring</span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActivePartner('family')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activePartner === 'family'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Daughter (Priya)
            </button>
            <button
              onClick={() => setActivePartner('caregiver')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activePartner === 'caregiver'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Caregiver (Sunita)
            </button>

            <a
              href={activePartner === 'family' ? 'tel:+919876543211' : 'tel:+919833344556'}
              className="p-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-700 transition"
              title="Call on Phone"
            >
              <PhoneCall className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/40">
          {currentThread.length === 0 ? (
            <div className="text-center py-20 text-slate-400 text-sm">
              No previous messages with {targetName}. Send a quick message below!
            </div>
          ) : (
            currentThread.map((msg) => {
              const isMe = msg.senderId === currentUserId;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <span className="text-[11px] font-bold text-slate-400 mb-1 px-1">
                    {msg.senderName}
                  </span>
                  <div
                    className={`max-w-lg p-4 rounded-3xl leading-relaxed shadow-xs ${
                      largeTextMode ? 'text-lg font-medium' : 'text-sm'
                    } ${
                      isMe
                        ? 'bg-teal-600 text-white rounded-br-xs'
                        : 'bg-white border border-slate-200 text-slate-800 rounded-bl-xs'
                    }`}
                  >
                    {msg.message}
                  </div>
                  <div className="flex items-center space-x-1 mt-1 px-1 text-[10px] text-slate-400">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    {isMe && <CheckCheck className="w-3.5 h-3.5 text-teal-600" />}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Elder Quick Responses Carousel */}
        <div className="px-5 py-3 border-t border-slate-100 bg-white flex items-center space-x-2 overflow-x-auto">
          <span className="text-[11px] font-bold uppercase text-slate-400 shrink-0">Quick Tap:</span>
          {quickResponses.map((qr, idx) => (
            <button
              key={idx}
              onClick={() => handleQuickSend(qr.text)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-teal-50 hover:text-teal-800 hover:border-teal-200 border border-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0"
            >
              {qr.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-4 border-t border-slate-100 flex items-center space-x-3 bg-white">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Type gentle message to ${targetName}...`}
            className={`flex-1 px-5 py-3.5 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-600 ${
              largeTextMode ? 'text-base font-semibold' : 'text-sm'
            }`}
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="px-6 py-3.5 rounded-2xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold text-sm flex items-center space-x-2 cursor-pointer shadow-md shadow-teal-700/20 transition"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
