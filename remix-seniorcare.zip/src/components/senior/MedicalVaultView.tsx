import React, { useState } from 'react';
import {
  FileText,
  UploadCloud,
  Download,
  Eye,
  Trash2,
  Filter,
  Search,
  Plus,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Building2,
  User as UserIcon,
  Tag,
  X,
} from 'lucide-react';
import { MedicalDocument, DocumentType, Language } from '../../types';

interface MedicalVaultViewProps {
  documents: MedicalDocument[];
  language: Language;
  onUploadDocument: (doc: Partial<MedicalDocument>) => void;
  onDeleteDocument: (id: string) => void;
}

export const MedicalVaultView: React.FC<MedicalVaultViewProps> = ({
  documents,
  language,
  onUploadDocument,
  onDeleteDocument,
}) => {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<MedicalDocument | null>(null);

  // Upload Form State
  const [title, setTitle] = useState('');
  const [docType, setDocType] = useState<DocumentType>('prescription');
  const [doctorName, setDoctorName] = useState('');
  const [hospitalClinic, setHospitalClinic] = useState('');
  const [description, setDescription] = useState('');
  const [fileSize, setFileSize] = useState('1.5 MB');
  const [fileName, setFileName] = useState('');

  const filteredDocs = documents.filter((doc) => {
    const matchesType = selectedType === 'all' || doc.documentType === selectedType;
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (doc.doctorName && doc.doctorName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (doc.hospitalClinic && doc.hospitalClinic.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (doc.tags && doc.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())));
    return matchesType && matchesSearch;
  });

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    onUploadDocument({
      title,
      documentType: docType,
      fileName: fileName || `${title.replace(/\s+/g, '_')}.pdf`,
      fileSize: fileSize || '1.8 MB',
      doctorName,
      hospitalClinic,
      description,
      tags: [docType.replace('_', ' '), 'Confidential Health Record'],
    });

    setTitle('');
    setDoctorName('');
    setHospitalClinic('');
    setDescription('');
    setFileName('');
    setShowUploadModal(false);
  };

  const getDocTypeBadge = (type: DocumentType) => {
    switch (type) {
      case 'prescription':
        return { label: 'Prescription', color: 'bg-emerald-100 text-emerald-800' };
      case 'blood_report':
        return { label: 'Blood Report', color: 'bg-sky-100 text-sky-800' };
      case 'xray_scan':
        return { label: 'X-Ray / Scan', color: 'bg-indigo-100 text-indigo-800' };
      case 'discharge_summary':
        return { label: 'Discharge Summary', color: 'bg-purple-100 text-purple-800' };
      case 'insurance_card':
        return { label: 'Insurance Policy', color: 'bg-amber-100 text-amber-800' };
      default:
        return { label: 'Medical Document', color: 'bg-slate-100 text-slate-800' };
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
              Medical Document Vault
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-teal-100 text-teal-800 flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-700" />
              <span>HIPAA-Encrypted</span>
            </span>
          </div>
          <p className="text-slate-600 text-sm mt-1">
            Store, view, and share doctor prescriptions, diagnostic reports, discharge summaries, and health cards.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-md shadow-teal-700/20 flex items-center space-x-2 cursor-pointer transition"
        >
          <UploadCloud className="w-5 h-5" />
          <span>Upload Medical Document</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto">
          {[
            { id: 'all', label: 'All Records' },
            { id: 'prescription', label: 'Prescriptions' },
            { id: 'blood_report', label: 'Blood Reports' },
            { id: 'xray_scan', label: 'X-Rays & Scans' },
            { id: 'discharge_summary', label: 'Discharge Summaries' },
            { id: 'insurance_card', label: 'Insurance' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedType(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                selectedType === tab.id
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by doctor, test, or hospital..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-teal-600"
          />
        </div>
      </div>

      {/* Document Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDocs.length === 0 ? (
          <div className="col-span-full bg-white rounded-3xl p-12 text-center border border-slate-200">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="font-extrabold text-lg text-slate-700">No documents found</h3>
            <p className="text-xs text-slate-400 mt-1">Upload a prescription or lab report to keep it securely archived.</p>
          </div>
        ) : (
          filteredDocs.map((doc) => {
            const badge = getDocTypeBadge(doc.documentType);
            return (
              <div
                key={doc.id}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${badge.color}`}>
                      {badge.label}
                    </span>
                    <span className="text-[11px] font-bold text-slate-400">{doc.fileSize}</span>
                  </div>

                  <h3 className="font-extrabold text-base text-slate-900 leading-snug">{doc.title}</h3>
                  <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">{doc.description}</p>

                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                    {doc.doctorName && (
                      <div className="flex items-center space-x-2">
                        <UserIcon className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                        <span className="font-medium">{doc.doctorName}</span>
                      </div>
                    )}
                    {doc.hospitalClinic && (
                      <div className="flex items-center space-x-2">
                        <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-medium">{doc.hospitalClinic}</span>
                      </div>
                    )}
                    <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Uploaded: {new Date(doc.uploadedAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setPreviewDoc(doc)}
                    className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer transition"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Record</span>
                  </button>

                  <div className="flex items-center space-x-2">
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        alert(`Downloading verified copy of ${doc.fileName}...`);
                      }}
                      className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
                      title="Download PDF"
                    >
                      <Download className="w-4 h-4" />
                    </a>
                    <button
                      onClick={() => onDeleteDocument(doc.id)}
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL: Upload Medical Document */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200">
            <h3 className="font-display font-black text-2xl text-slate-900 mb-1">
              Add Medical Record to Vault
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Documents are encrypted and accessible only to you, authorized family members, and verified care doctors.
            </p>

            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Document Type</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value as DocumentType)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-teal-600"
                >
                  <option value="prescription">💊 Doctor Prescription (Rx)</option>
                  <option value="blood_report">🧪 Blood / Pathology Lab Report</option>
                  <option value="xray_scan">🩻 X-Ray / CT / MRI Scan Report</option>
                  <option value="discharge_summary">🏥 Hospital Discharge Summary</option>
                  <option value="insurance_card">🛡️ Health Insurance Policy / Card</option>
                  <option value="vaccination_cert">💉 Vaccination Certificate</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Cardiology OPD Prescription - Dr. Joshi"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Doctor Name</label>
                  <input
                    type="text"
                    value={doctorName}
                    onChange={(e) => setDoctorName(e.target.value)}
                    placeholder="e.g. Dr. A. K. Joshi"
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Hospital / Lab</label>
                  <input
                    type="text"
                    value={hospitalClinic}
                    onChange={(e) => setHospitalClinic(e.target.value)}
                    placeholder="e.g. Apollo Hospital"
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Key Diagnostic Findings / Notes</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Blood pressure 120/80 mmHg. Medication adjusted to Telmisartan 40mg."
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div className="border-2 border-dashed border-slate-300 hover:border-teal-600 rounded-2xl p-4 text-center cursor-pointer transition">
                <UploadCloud className="w-8 h-8 text-slate-400 mx-auto mb-1" />
                <span className="text-xs font-bold text-slate-700 block">Click to select PDF or image file</span>
                <span className="text-[10px] text-slate-400">PDF, JPG, PNG up to 25 MB</span>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm cursor-pointer shadow-md"
                >
                  Save to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: View Document Preview */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase bg-teal-100 text-teal-800">
                  {previewDoc.documentType.replace('_', ' ')}
                </span>
                <h3 className="font-display font-black text-xl text-slate-900 mt-1">{previewDoc.title}</h3>
                <p className="text-xs text-slate-500">{previewDoc.fileName} • {previewDoc.fileSize}</p>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-2 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Digital Reader Mockup */}
            <div className="my-6 p-8 bg-slate-50 rounded-2xl border border-slate-200 min-h-[260px] flex flex-col justify-between">
              <div className="border-b border-slate-200 pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">{previewDoc.hospitalClinic || 'Apex Elder Medical Center'}</h4>
                    <p className="text-xs text-slate-500">{previewDoc.doctorName || 'Senior Healthcare Specialist'}</p>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">CONFIDENTIAL RECORD</span>
                </div>
              </div>

              <div className="py-6">
                <p className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-2">Record Summary & Observations</p>
                <p className="text-sm text-slate-700 leading-relaxed font-medium bg-white p-4 rounded-xl border border-slate-200">
                  {previewDoc.description || 'Verified authentic healthcare documentation on file.'}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                <span>Digitally signed & verified</span>
                <span>Uploaded: {new Date(previewDoc.uploadedAt).toLocaleString()}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-slate-400">Status: Verified Official Copy</span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    alert(`Downloading ${previewDoc.fileName}...`);
                  }}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center space-x-1.5 cursor-pointer shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Document</span>
                </button>
                <button
                  onClick={() => setPreviewDoc(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
