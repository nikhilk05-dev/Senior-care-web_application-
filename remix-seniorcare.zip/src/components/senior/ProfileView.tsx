import React, { useState } from 'react';
import {
  User as UserIcon,
  Phone,
  Mail,
  Globe,
  Type,
  Shield,
  Trash2,
  Download,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { User, Language } from '../../types';
import { t } from '../../i18n';

interface ProfileViewProps {
  user: User;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  fontSize: 'normal' | 'large' | 'xlarge';
  onFontSizeChange: (size: 'normal' | 'large' | 'xlarge') => void;
  onUpdateProfile: (data: Partial<User>) => void;
  onLogout: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  language,
  onLanguageChange,
  fontSize,
  onFontSizeChange,
  onUpdateProfile,
  onLogout,
}) => {
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone || '');
  const [age, setAge] = useState(user.age || 68);
  const [bloodGroup, setBloodGroup] = useState(user.bloodGroup || 'B+');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name,
      phone,
      age: Number(age),
      bloodGroup,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-8 pb-12 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
          {t('profile', language)} & Settings
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Manage your personal details, language, text readability, and privacy preferences.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-sm flex items-center space-x-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>Profile updated successfully!</span>
        </div>
      )}

      {/* Personal Info Form */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
        <h3 className="font-bold text-xl text-slate-900 mb-6">Personal Details</h3>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Email Address (Registered)
              </label>
              <input
                type="email"
                disabled
                value={user.email}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-slate-100 text-slate-500 cursor-not-allowed"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Age
              </label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Blood Group
              </label>
              <input
                type="text"
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-sm font-bold text-rose-600"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl text-sm shadow-md cursor-pointer"
            >
              Save Profile Details
            </button>
          </div>
        </form>
      </div>

      {/* Accessibility & Language Preferences (Section 18 & 19) */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6">
        <h3 className="font-bold text-xl text-slate-900">Accessibility & Language Preferences</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Language Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-2 flex items-center space-x-1.5">
              <Globe className="w-4 h-4 text-teal-700" />
              <span>{t('language', language)}</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'en', label: 'English' },
                { id: 'hi', label: 'हिन्दी' },
                { id: 'mr', label: 'मराठी' },
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => onLanguageChange(lang.id as Language)}
                  className={`py-2.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                    language === lang.id
                      ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          {/* Text Size & Legibility Accessibility */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-2 flex items-center space-x-1.5">
              <Type className="w-4 h-4 text-teal-700" />
              <span>{t('textLegibility', language) || t('fontSize', language)}</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {[
                {
                  id: 'normal',
                  label: t('fontSizeNormal', language),
                  desc: t('fontSizeStandardBadge', language),
                },
                {
                  id: 'large',
                  label: t('fontSizeLarge', language),
                  desc: t('fontSizeRecommendedBadge', language),
                },
                {
                  id: 'xlarge',
                  label: t('fontSizeXLarge', language),
                  desc: t('fontSizeHighContrastBadge', language),
                },
              ].map((fs) => (
                <button
                  key={fs.id}
                  onClick={() => onFontSizeChange(fs.id as any)}
                  className={`p-3 rounded-2xl text-xs font-bold border transition cursor-pointer text-left flex flex-col justify-between ${
                    fontSize === fs.id
                      ? 'bg-teal-700 text-white border-teal-700 shadow-md ring-2 ring-teal-200'
                      : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                  }`}
                >
                  <span className="text-sm font-bold">{fs.label}</span>
                  <span
                    className={`text-xs mt-1 font-semibold ${
                      fontSize === fs.id ? 'text-teal-100' : 'text-slate-600'
                    }`}
                  >
                    {fs.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Sovereign Privacy & Account Control (Section 19) */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center space-x-2">
          <Shield className="w-5 h-5 text-teal-700" />
          <h3 className="font-bold text-xl text-slate-900">Privacy & Data Governance</h3>
        </div>

        <p className="text-sm text-slate-600">
          SeniorCare guarantees sovereign senior privacy. Your health data is never shared with third parties or advertisers.
        </p>

        <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex space-x-3">
            <button
              onClick={() => alert('All your data is locally encrypted and private under your senior profile.')}
              className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold cursor-pointer"
            >
              Review Stored Data
            </button>
            <button
              onClick={() => alert('Data summary downloaded successfully.')}
              className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold cursor-pointer flex items-center space-x-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export All Records</span>
            </button>
          </div>

          <button
            onClick={() => setShowDeleteModal(true)}
            className="px-4 py-2.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold cursor-pointer flex items-center space-x-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Account</span>
          </button>
        </div>
      </div>

      {/* SECTION 19 DELETE ACCOUNT CONFIRMATION MODAL */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border-2 border-rose-300 text-center">
            <div className="w-14 h-14 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="font-display font-extrabold text-2xl text-slate-900 mb-2">
              Permanently Delete Account?
            </h3>

            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              Are you sure you want to delete your SeniorCare account? All your medicine schedules, vitals history, and emergency contacts will be permanently removed. This action cannot be undone.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="py-3 px-4 rounded-xl border-2 border-slate-200 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  onLogout();
                }}
                className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
