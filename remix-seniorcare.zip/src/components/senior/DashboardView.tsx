import React, { useState } from 'react';
import {
  Pill,
  Droplets,
  Activity,
  Calendar,
  Heart,
  Plus,
  Volume2,
  VolumeX,
  CheckCircle2,
  Clock,
  AlertCircle,
  Users,
  ChevronRight,
  TrendingUp,
  Sparkles,
  Flame,
  Utensils,
} from 'lucide-react';
import {
  User,
  Medicine,
  HealthRecord,
  Appointment,
  WaterDay,
  WellnessRecord,
  HealthTip,
  Language,
  CalorieRecord,
} from '../../types';
import { t } from '../../i18n';
import { HydrationChart } from './HydrationChart';

interface DashboardViewProps {
  user: User;
  language: Language;
  medicines: Medicine[];
  healthRecords: HealthRecord[];
  appointments: Appointment[];
  waterToday: WaterDay;
  waterHistory?: WaterDay[];
  wellness: WellnessRecord | null;
  dailyTip: HealthTip | null;
  calorieRecords?: CalorieRecord[];
  onTakeDose: (medId: string) => void;
  onAddWaterGlass: () => void;
  onNavigateTab: (tab: string) => void;
  onOpenAddMedicine: () => void;
  onOpenAddReading: () => void;
  onOpenBookAppointment: () => void;
  onOpenEmergency: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  language,
  medicines,
  healthRecords,
  appointments,
  waterToday,
  waterHistory,
  wellness,
  dailyTip,
  calorieRecords = [],
  onTakeDose,
  onAddWaterGlass,
  onNavigateTab,
  onOpenAddMedicine,
  onOpenAddReading,
  onOpenBookAppointment,
  onOpenEmergency,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Time of day greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t('goodMorning', language);
    if (hour < 17) return t('goodAfternoon', language);
    return t('goodEvening', language);
  };

  // Next medicine logic
  const allSchedules = medicines.flatMap((m) =>
    (m.schedules || []).map((s) => ({ ...s, medicine: m }))
  );
  const nextDue = allSchedules.find((s) => s.status === 'due' || s.status === 'upcoming');
  const takenCount = allSchedules.filter((s) => s.status === 'taken').length;
  const missedCount = allSchedules.filter((s) => s.status === 'missed' || s.status === 'due').length;

  // Text to speech for Daily Health Tip (Section 13)
  const handleToggleTipAudio = () => {
    if (!dailyTip) return;
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(`${dailyTip.title}. ${dailyTip.content}`);
      utterance.rate = 0.9; // Friendly, clear pace for seniors
      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);
      window.speechSynthesis.speak(utterance);
      setIsPlayingAudio(true);
    }
  };

  const todayDateFormatted = new Date().toLocaleDateString(
    language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-IN',
    {
      timeZone: 'Asia/Kolkata',
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }
  );

  const upcomingAppts = appointments.filter((a) => a.status === 'upcoming').slice(0, 2);

  return (
    <div className="space-y-8 pb-12">
      {/* Greeting & Date Banner */}
      <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-teal-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-teal-900/10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-200">
                {t('todayIs', language)}: {todayDateFormatted}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-orange-500/30 text-orange-200 border border-orange-400/40 text-[10px] font-bold font-mono">
                IST 🇮🇳
              </span>
            </div>
            <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-white mt-1">
              {getGreeting()}, {user.name}
            </h1>
            <p className="text-teal-100 text-sm sm:text-base mt-1">
              Wishing you a peaceful, healthy, and energized day ahead.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="px-4 py-2 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/20 text-center">
              <span className="text-xs text-teal-200 block uppercase font-bold">Wellness Score</span>
              <span className="text-2xl font-black text-white">{wellness?.wellnessScore || 88}/100</span>
            </div>
          </div>
        </div>

        {/* Quick Actions (Section 7) */}
        <div className="mt-6 pt-6 border-t border-teal-600/60">
          <p className="text-xs font-bold text-teal-200 uppercase tracking-wider mb-3">
            {t('quickActions', language)}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            <button
              onClick={onOpenAddMedicine}
              className="p-3 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-2xl text-left border border-white/15 transition cursor-pointer"
            >
              <Pill className="w-5 h-5 text-teal-200 mb-1" />
              <span className="text-xs font-bold text-white block">{t('addMedicine', language)}</span>
            </button>
            <button
              onClick={onOpenAddReading}
              className="p-3 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-2xl text-left border border-white/15 transition cursor-pointer"
            >
              <Activity className="w-5 h-5 text-teal-200 mb-1" />
              <span className="text-xs font-bold text-white block">{t('addHealthReading', language)}</span>
            </button>
            <button
              onClick={onAddWaterGlass}
              className="p-3 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-2xl text-left border border-white/15 transition cursor-pointer"
            >
              <Droplets className="w-5 h-5 text-sky-300 mb-1" />
              <span className="text-xs font-bold text-white block">+ 1 Glass Water</span>
            </button>
            <button
              onClick={() => onNavigateTab('calendar')}
              className="p-3 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-2xl text-left border border-white/15 transition cursor-pointer"
            >
              <Calendar className="w-5 h-5 text-orange-300 mb-1" />
              <span className="text-xs font-bold text-white block">{t('calendar', language)}</span>
            </button>
            <button
              onClick={onOpenBookAppointment}
              className="p-3 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-2xl text-left border border-white/15 transition cursor-pointer"
            >
              <Calendar className="w-5 h-5 text-teal-200 mb-1" />
              <span className="text-xs font-bold text-white block">{t('bookAppointment', language)}</span>
            </button>
            <button
              onClick={() => onNavigateTab('familyConnect')}
              className="p-3 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-2xl text-left border border-white/15 transition cursor-pointer"
            >
              <Users className="w-5 h-5 text-teal-200 mb-1" />
              <span className="text-xs font-bold text-white block">{t('familyConnect', language)}</span>
            </button>
            <button
              id="dashboard-sos-btn"
              onClick={onOpenEmergency}
              className="relative p-3 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-2xl text-left border-2 border-rose-300 shadow-md shadow-rose-900/30 transition-all cursor-pointer animate-pulse hover:animate-none focus:outline-hidden focus:ring-4 focus:ring-rose-300"
              title="Emergency SOS"
            >
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-300 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500 border border-white"></span>
              </span>
              <Heart className="w-5 h-5 text-white mb-1 fill-white" />
              <span className="text-xs font-bold text-white block">Emergency SOS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Next Medicine + Water Tracker + Daily Health Tip */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Next Medicine Due Card (Section 7) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {t('nextMedicine', language)}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                {nextDue ? nextDue.time : 'None Pending'}
              </span>
            </div>

            {nextDue ? (
              <div className="mt-4 space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                    <Pill className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-lg text-slate-900 leading-snug">
                      {nextDue.medicine.name}
                    </h3>
                    <p className="text-sm font-semibold text-teal-700">{nextDue.medicine.dosage}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {nextDue.medicine.timing === 'after_food'
                        ? t('afterFood', language)
                        : t('beforeFood', language)}{' '}
                      • {nextDue.medicine.notes}
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <span>Stock remaining:</span>
                  <span className="font-bold text-slate-900">
                    {nextDue.medicine.quantityRemaining} pills
                  </span>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-slate-500 text-sm">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                <p className="font-semibold text-slate-800">{t('noNextMedicine', language)}</p>
              </div>
            )}
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex gap-2">
            {nextDue ? (
              <button
                onClick={() => onTakeDose(nextDue.medicine.id)}
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold rounded-xl shadow-sm text-sm flex items-center justify-center space-x-2 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{t('markTaken', language)}</span>
              </button>
            ) : (
              <button
                onClick={() => onNavigateTab('medicines')}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
              >
                View Full Medicine Schedule
              </button>
            )}
          </div>
        </div>

        {/* Water Intake Quick Card (Section 7 & 14) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {t('waterIntakeToday', language)}
              </span>
              <span className="text-xs font-bold text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded-full border border-sky-200">
                {waterToday?.targetMl ? Math.min(100, Math.round(((waterToday.consumedMl || 0) / waterToday.targetMl) * 100)) : 0}%
              </span>
            </div>

            <div className="mt-4 flex items-center space-x-4">
              <div className="w-16 h-16 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                <Droplets className="w-8 h-8" />
              </div>
              <div>
                <p className="font-black text-3xl text-slate-900">
                  {waterToday?.glasses || 0} <span className="text-sm font-semibold text-slate-500">glasses</span>
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {waterToday?.consumedMl || 0} ml of {waterToday?.targetMl || 2000} ml target
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-4 w-full h-3 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-sky-500 transition-all duration-500 rounded-full"
                style={{
                  width: `${Math.min(100, waterToday?.targetMl ? Math.round(((waterToday.consumedMl || 0) / waterToday.targetMl) * 100) : 0)}%`,
                }}
              />
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex gap-2">
            <button
              onClick={onAddWaterGlass}
              className="flex-1 py-3 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-bold rounded-xl shadow-sm text-sm flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t('addGlass', language)}</span>
            </button>
            <button
              onClick={() => onNavigateTab('waterTracker')}
              className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
            >
              History
            </button>
          </div>
        </div>

        {/* Daily Health Tip Card with Speech Read Aloud (Section 13) */}
        <div className="bg-gradient-to-br from-amber-50/70 to-orange-50/50 rounded-3xl p-6 border border-amber-200/80 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-amber-200/50">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>{t('dailyHealthTip', language)}</span>
              </span>
              <button
                onClick={handleToggleTipAudio}
                className="px-2.5 py-1 rounded-xl bg-white/80 hover:bg-white text-amber-800 font-bold text-xs flex items-center space-x-1 border border-amber-200 cursor-pointer shadow-2xs"
                title="Read tip aloud in clear audio"
              >
                {isPlayingAudio ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                    <span>{t('stopAudio', language)}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-amber-700" />
                    <span>{t('listenTip', language)}</span>
                  </>
                )}
              </button>
            </div>

            {dailyTip && (
              <div className="mt-4">
                <h4 className="font-bold text-base text-slate-900 leading-snug">{dailyTip.title}</h4>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  {dailyTip.content}
                </p>
              </div>
            )}
          </div>

          <div className="mt-5 pt-3 border-t border-amber-200/50 flex justify-between items-center text-xs">
            <span className="font-semibold text-amber-800">
              Category: {dailyTip?.category || 'Wellness'}
            </span>
            <button
              onClick={() => onNavigateTab('healthTips')}
              className="text-amber-900 font-bold hover:underline cursor-pointer"
            >
              Browse all tips →
            </button>
          </div>
        </div>
      </div>

      {/* Health & Nutrition: Calorie Counter Summary Card (SSD FR2, FR7) */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold uppercase tracking-wide bg-orange-100 text-orange-800 border border-orange-200 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-orange-600" />
                <span>Health & Nutrition</span>
              </span>
              <span className="text-xs text-slate-500 font-semibold">Today's Calorie Balance</span>
            </div>
            <h3 className="text-xl font-display font-extrabold text-slate-900 mt-1">
              Daily Calorie & Meal Intake
            </h3>
          </div>

          <button
            onClick={() => onNavigateTab('calorieCounter')}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-2xl text-xs sm:text-sm font-bold shadow-xs transition cursor-pointer self-start sm:self-auto"
          >
            <Utensils className="w-4 h-4" />
            <span>Open Calorie Counter →</span>
          </button>
        </div>

        {(() => {
          const todayIso = new Date().toISOString().split('T')[0];
          const todayCalRecords = calorieRecords.filter((r) => r.date === todayIso);
          const consumedToday = todayCalRecords.reduce((sum, r) => sum + r.calories, 0);
          const goalToday = user.dailyCalorieGoal || 1800;
          const remaining = Math.max(0, goalToday - consumedToday);
          const pct = Math.min(100, Math.round((consumedToday / goalToday) * 100));

          const breakfastCal = todayCalRecords.filter((r) => r.mealType === 'breakfast').reduce((s, r) => s + r.calories, 0);
          const lunchCal = todayCalRecords.filter((r) => r.mealType === 'lunch').reduce((s, r) => s + r.calories, 0);
          const snacksCal = todayCalRecords.filter((r) => r.mealType === 'snacks').reduce((s, r) => s + r.calories, 0);
          const dinnerCal = todayCalRecords.filter((r) => r.mealType === 'dinner').reduce((s, r) => s + r.calories, 0);

          return (
            <div className="mt-5 space-y-5">
              {/* Metrics Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 text-center">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Daily Goal</span>
                  <span className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5 block">{goalToday}</span>
                  <span className="text-[10px] text-slate-500">kcal</span>
                </div>
                <div className="bg-teal-50/70 border border-teal-200 rounded-2xl p-3.5 text-center">
                  <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">Consumed</span>
                  <span className="text-xl sm:text-2xl font-black text-teal-800 mt-0.5 block">{consumedToday}</span>
                  <span className="text-[10px] text-teal-600">kcal</span>
                </div>
                <div className="bg-orange-50/70 border border-orange-200 rounded-2xl p-3.5 text-center">
                  <span className="text-[11px] font-bold text-orange-800 uppercase tracking-wider block">Remaining</span>
                  <span className="text-xl sm:text-2xl font-black text-orange-700 mt-0.5 block">{remaining}</span>
                  <span className="text-[10px] text-orange-600">kcal</span>
                </div>
                <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 text-center">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Progress</span>
                  <span className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5 block">{pct}%</span>
                  <span className="text-[10px] text-slate-500">of daily goal</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                  <span>Daily Calorie Budget: {consumedToday} / {goalToday} kcal</span>
                  <span className="text-teal-700">{pct}% Complete</span>
                </div>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-teal-500 to-teal-600 transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              {/* Meal Pills Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Breakfast</span>
                  <span className="text-sm font-extrabold text-slate-900 mt-0.5 block">{breakfastCal} kcal</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Lunch</span>
                  <span className="text-sm font-extrabold text-slate-900 mt-0.5 block">{lunchCal} kcal</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Snacks</span>
                  <span className="text-sm font-extrabold text-slate-900 mt-0.5 block">{snacksCal} kcal</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Dinner</span>
                  <span className="text-sm font-extrabold text-slate-900 mt-0.5 block">{dinnerCal} kcal</span>
                </div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* 7-Day Hydration Progress vs Goal (Recharts Integration) */}
      <HydrationChart
        waterToday={waterToday}
        waterHistory={waterHistory}
        language={language}
        onAddGlass={onAddWaterGlass}
      />

      {/* Second Row: Latest Health Readings & Upcoming Appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Latest Health Readings (Section 9) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-lg text-slate-900">{t('latestReadings', language)}</h3>
              <p className="text-xs text-slate-500">Tracked Vitals & Biometrics</p>
            </div>
            <button
              onClick={onOpenAddReading}
              className="px-3.5 py-1.5 rounded-xl bg-teal-50 text-teal-700 hover:bg-teal-100 font-bold text-xs border border-teal-200 flex items-center space-x-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('addHealthReading', language)}</span>
            </button>
          </div>

          <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {healthRecords.slice(0, 6).map((rec) => {
              const normalBracket =
                rec.type === 'blood_pressure'
                  ? '(Normal: 120/80 mmHg | Required: 90/60 – 120/80 mmHg)'
                  : rec.type === 'blood_sugar'
                  ? '(Normal: 70–140 mg/dL | Fasting: 70–99 mg/dL)'
                  : rec.type === 'oxygen'
                  ? '(Normal: 95%–100% | Required: ≥95%)'
                  : rec.type === 'heart_rate'
                  ? '(Normal: 60–100 bpm | Required: 60–100 bpm)'
                  : rec.type === 'weight'
                  ? '(Normal: 50–80 kg | BMI: 18.5–24.9)'
                  : rec.type === 'temperature'
                  ? '(Normal: 97.8°F–99.1°F | Required: ~98.6°F)'
                  : '';

              return (
                <div
                  key={rec.id}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-teal-300 transition flex flex-col justify-between"
                >
                  <div>
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      {rec.type === 'blood_pressure'
                        ? 'Blood Pressure'
                        : rec.type === 'blood_sugar'
                        ? 'Blood Sugar'
                        : rec.type === 'oxygen'
                        ? 'SpO2 Oxygen'
                        : rec.type === 'heart_rate'
                        ? 'Heart Rate (Health Rate)'
                        : rec.type === 'weight'
                        ? 'Weight'
                        : rec.type === 'temperature'
                        ? 'Temperature'
                        : rec.type}
                    </span>
                    <p className="font-black text-2xl text-slate-900 mt-1">{rec.value}</p>
                    <p className="text-xs text-slate-600 font-bold">{rec.unit}</p>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-100">
                    {normalBracket && (
                      <span className="text-xs font-bold text-teal-900 bg-teal-50 px-2.5 py-1 rounded-lg inline-block border border-teal-200 leading-snug">
                        {normalBracket}
                      </span>
                    )}
                    <span className="text-xs text-slate-600 font-medium block mt-1.5">{rec.recordedDate} · {rec.recordedTime}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-right">
            <button
              onClick={() => onNavigateTab('healthRecords')}
              className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
            >
              View Historical Trends & Charts →
            </button>
          </div>
        </div>

        {/* Upcoming Appointments (Section 16) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-lg text-slate-900">{t('upcomingAppointments', language)}</h3>
              <p className="text-xs text-slate-500">Clinical visits & reminders</p>
            </div>
            <button
              onClick={onOpenBookAppointment}
              className="px-3.5 py-1.5 rounded-xl bg-teal-50 text-teal-700 hover:bg-teal-100 font-bold text-xs border border-teal-200 flex items-center space-x-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('bookAppointment', language)}</span>
            </button>
          </div>

          <div className="mt-4 space-y-3">
            {upcomingAppts.length === 0 ? (
              <p className="text-sm text-slate-500 py-4 text-center">No upcoming appointments scheduled.</p>
            ) : (
              upcomingAppts.map((appt) => (
                <div
                  key={appt.id}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-start justify-between"
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0 mt-0.5">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{appt.doctorName}</h4>
                      <p className="text-xs text-slate-600">{appt.clinic}</p>
                      <p className="text-xs font-semibold text-teal-700 mt-1">
                        📅 {appt.appointmentDate} at {appt.appointmentTime}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-teal-100 text-teal-800 text-[11px] font-bold">
                    Confirmed
                  </span>
                </div>
              ))
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-right">
            <button
              onClick={() => onNavigateTab('appointments')}
              className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
            >
              Manage Appointments →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
