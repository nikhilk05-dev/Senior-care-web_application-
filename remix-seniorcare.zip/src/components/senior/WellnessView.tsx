import React, { useState } from 'react';
import {
  Heart,
  Moon,
  Footprints,
  Smile,
  Utensils,
  CheckCircle2,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { WellnessRecord, Language } from '../../types';
import { t } from '../../i18n';

interface WellnessViewProps {
  wellness: WellnessRecord | null;
  language: Language;
  onSaveWellness: (record: Partial<WellnessRecord>) => void;
}

export const WellnessView: React.FC<WellnessViewProps> = ({
  wellness,
  language,
  onSaveWellness,
}) => {
  const [sleepHours, setSleepHours] = useState(wellness?.sleepHours || 7.5);
  const [steps, setSteps] = useState(wellness?.steps || 3800);
  const [exerciseMinutes, setExerciseMinutes] = useState(wellness?.exerciseMinutes || 25);
  const [mood, setMood] = useState<'great' | 'good' | 'okay' | 'low' | 'tired'>(
    wellness?.mood || 'good'
  );
  const [mealsCount, setMealsCount] = useState(wellness?.mealsCount || 3);
  const [notes, setNotes] = useState(wellness?.notes || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Compute composite score (0 - 100)
  const computeScore = () => {
    let score = 50; // base
    if (sleepHours >= 7 && sleepHours <= 9) score += 15;
    else if (sleepHours >= 6) score += 10;

    if (steps >= 4000) score += 15;
    else if (steps >= 2000) score += 10;

    if (exerciseMinutes >= 20) score += 10;

    if (mood === 'great') score += 10;
    else if (mood === 'good') score += 8;
    else if (mood === 'okay') score += 5;

    return Math.min(100, Math.max(0, score));
  };

  const currentScore = computeScore();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveWellness({
      date: new Date().toISOString().split('T')[0],
      sleepHours: Number(sleepHours),
      steps: Number(steps),
      exerciseMinutes: Number(exerciseMinutes),
      mood,
      mealsCount: Number(mealsCount),
      notes,
      wellnessScore: currentScore,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const getEncouragement = (score: number) => {
    if (score >= 85) return 'Superb balance today! Your body and mind are well nurtured.';
    if (score >= 70) return 'Wonderful job! A gentle walk and regular meals keep you vibrant.';
    return 'Take it gentle today. Rest well, hydrate frequently, and take your medicines on time.';
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
          {t('dailyWellness', language)}
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Holistic tracking of your sleep, gentle activity, nutrition, and daily emotional state.
        </p>
      </div>

      {/* Wellness Score Highlight Card (Section 15) */}
      <div className="bg-gradient-to-r from-teal-800 to-emerald-800 text-white rounded-3xl p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <span className="text-xs font-bold text-teal-200 uppercase tracking-wider block">
            Today’s Composite Wellness Score
          </span>
          <div className="flex items-baseline space-x-3 mt-1">
            <span className="font-display font-black text-6xl text-white">{currentScore}</span>
            <span className="text-xl font-bold text-teal-200">/ 100</span>
          </div>
          <p className="text-emerald-100 text-sm mt-2 max-w-lg">{getEncouragement(currentScore)}</p>
        </div>

        <div className="w-20 h-20 rounded-full bg-white/10 border-2 border-white/20 flex items-center justify-center shrink-0">
          <Heart className="w-10 h-10 text-emerald-300" />
        </div>
      </div>

      {/* Wellness Logger Form */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
        <h3 className="font-bold text-xl text-slate-900 mb-6">Log Today's Wellness Details</h3>

        {savedSuccess && (
          <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-sm flex items-center space-x-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>Wellness log saved successfully!</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-6">
          {/* Mood Selector (Section 15) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              How are you feeling today? (Mood)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {[
                { id: 'great', label: 'Great 😄', bg: 'hover:border-emerald-400' },
                { id: 'good', label: 'Good 🙂', bg: 'hover:border-teal-400' },
                { id: 'okay', label: 'Okay 😐', bg: 'hover:border-amber-400' },
                { id: 'low', label: 'Low 😔', bg: 'hover:border-indigo-400' },
                { id: 'tired', label: 'Tired 🥱', bg: 'hover:border-slate-400' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMood(m.id as any)}
                  className={`py-3.5 px-4 rounded-2xl font-bold text-sm border-2 transition cursor-pointer text-center ${
                    mood === m.id
                      ? 'border-teal-600 bg-teal-50 text-teal-800 shadow-xs'
                      : `border-slate-200 bg-white text-slate-700 ${m.bg}`
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Sleep Hours */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-700 mb-2">
                <Moon className="w-5 h-5 text-indigo-600" />
                <label className="font-bold text-xs uppercase tracking-wider">Sleep Hours</label>
              </div>
              <input
                type="number"
                step="0.5"
                min="0"
                max="24"
                value={sleepHours}
                onChange={(e) => setSleepHours(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-lg font-bold"
              />
              <span className="text-xs text-slate-400 mt-1 block">Ideal: 7–8 hours</span>
            </div>

            {/* Daily Steps */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-700 mb-2">
                <Footprints className="w-5 h-5 text-teal-600" />
                <label className="font-bold text-xs uppercase tracking-wider">Walking Steps</label>
              </div>
              <input
                type="number"
                step="100"
                min="0"
                max="50000"
                value={steps}
                onChange={(e) => setSteps(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-lg font-bold"
              />
              <span className="text-xs text-slate-400 mt-1 block">Target: 3,000–5,000 steps</span>
            </div>

            {/* Exercise Minutes */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-700 mb-2">
                <Sparkles className="w-5 h-5 text-amber-600" />
                <label className="font-bold text-xs uppercase tracking-wider">Gentle Exercise</label>
              </div>
              <input
                type="number"
                step="5"
                min="0"
                max="180"
                value={exerciseMinutes}
                onChange={(e) => setExerciseMinutes(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-lg font-bold"
              />
              <span className="text-xs text-slate-400 mt-1 block">Yoga / Stretching (mins)</span>
            </div>

            {/* Meals Count */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-700 mb-2">
                <Utensils className="w-5 h-5 text-rose-600" />
                <label className="font-bold text-xs uppercase tracking-wider">Regular Meals</label>
              </div>
              <input
                type="number"
                min="1"
                max="6"
                value={mealsCount}
                onChange={(e) => setMealsCount(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-lg font-bold"
              />
              <span className="text-xs text-slate-400 mt-1 block">Timely nutritious meals</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Personal Notes & Reflections
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Enjoyed morning walk in the park with friends, practiced deep breathing..."
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm"
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-8 py-3.5 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold rounded-2xl shadow-md cursor-pointer text-base"
            >
              Save Wellness Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
