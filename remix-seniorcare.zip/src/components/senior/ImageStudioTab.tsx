import React, { useState } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Wand2,
  Upload,
  Download,
  RefreshCw,
  Sliders,
  Check,
  Copy,
  Layers,
  Info,
  Clock,
  ArrowRight,
  ZoomIn,
  Trash2,
} from 'lucide-react';
import { Language, GeneratedImageItem } from '../../types';

interface ImageStudioTabProps {
  language: Language;
}

const SAMPLE_PRESET_PROMPTS = [
  'Peaceful senior garden with blooming jasmine flowers, sunny morning path, and a wooden bench',
  'Tranquil lotus pond with water ripples, gentle morning mist, and stone lanterns',
  'Elderly couple walking happily along a serene lakeside promenade during golden hour',
  'Cozy sunlit reading corner with indoor plants, herbal tea cup, and soft warm lighting',
  'Gentle senior yoga session in a lush green botanical park under shady banyan trees',
];

const SAMPLE_EDIT_IMAGES = [
  {
    title: 'Sunny Garden Bench',
    url: 'https://images.unsplash.com/photo-1519331379826-f10be5486c6f?auto=format&fit=crop&w=800&q=80',
    prompt: 'Add colorful blooming roses and butterflies around the wooden bench',
  },
  {
    title: 'Peaceful Tea Cup',
    url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80',
    prompt: 'Add fresh mint leaves and chamomile flowers next to the teacup with warm golden glow',
  },
  {
    title: 'Morning Park Path',
    url: 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=800&q=80',
    prompt: 'Turn this into an autumn sunrise path with soft orange fallen leaves and sunlight rays',
  },
];

export const ImageStudioTab: React.FC<ImageStudioTabProps> = ({ language }) => {
  const [mode, setMode] = useState<'create' | 'edit'>('create');
  const [prompt, setPrompt] = useState(
    'A serene morning garden with blooming flowers, comfortable bench, and soft warm sunlight for elderly relaxation'
  );
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '4:3' | '9:16' | '3:4'>('1:1');
  const [imageSize, setImageSize] = useState<'512px' | '1K' | '2K'>('1K');
  const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');

  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  // Gallery of generated images in session
  const [gallery, setGallery] = useState<GeneratedImageItem[]>([
    {
      id: 'img-seed-1',
      title: 'Morning Jasmine Garden',
      prompt: 'Peaceful senior garden with blooming jasmine flowers, sunny morning path, and a wooden bench',
      mode: 'create',
      aspectRatio: '1:1',
      imageUrl: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1000&q=80',
      createdAt: 'Earlier today',
      modelUsed: 'gemini-3.1-flash-lite-image',
    },
    {
      id: 'img-seed-2',
      title: 'Tranquil Lakeside Sunrise',
      prompt: 'Calm reflective lake at dawn with golden sunlight through gentle pine trees',
      mode: 'create',
      aspectRatio: '16:9',
      imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1000&q=80',
      createdAt: 'Yesterday',
      modelUsed: 'gemini-3.1-flash-lite-image',
    },
  ]);

  const [activeResult, setActiveResult] = useState<GeneratedImageItem | null>(gallery[0] || null);

  const handleFileUpload = (file: File) => {
    setMimeType(file.type || 'image/jpeg');
    const reader = new FileReader();
    reader.onloadend = () => {
      const full = reader.result as string;
      setUploadedImagePreview(full);
      const base64Data = full.includes(',') ? full.split(',')[1] : full;
      setUploadedImageBase64(base64Data);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSampleEdit = async (sample: typeof SAMPLE_EDIT_IMAGES[0]) => {
    setPrompt(sample.prompt);
    setUploadedImagePreview(sample.url);
    try {
      // Fetch sample to convert to base64 for API submission
      const resp = await fetch(sample.url);
      const blob = await resp.blob();
      setMimeType(blob.type || 'image/jpeg');
      const reader = new FileReader();
      reader.onloadend = () => {
        const full = reader.result as string;
        const b64 = full.includes(',') ? full.split(',')[1] : full;
        setUploadedImageBase64(b64);
      };
      reader.readAsDataURL(blob);
    } catch {
      // Fallback: use sample URL as preview
      setUploadedImageBase64('sample');
    }
  };

  const handleSubmit = async () => {
    if (!prompt.trim()) {
      alert('Please enter a description for the image you want to generate or edit.');
      return;
    }

    if (mode === 'edit' && !uploadedImagePreview) {
      alert('Please upload an image or pick one of the sample images to edit.');
      return;
    }

    setLoading(true);
    setStatusMessage(
      mode === 'create'
        ? 'Gemini 3.1 Flash Image Preview is synthesizing your image...'
        : 'Gemini 3.1 Flash Image Preview is applying your modifications...'
    );

    try {
      const endpoint = mode === 'create' ? '/api/ai/generate-image' : '/api/ai/edit-image';
      const body =
        mode === 'create'
          ? {
              prompt: prompt.trim(),
              aspectRatio,
              imageSize,
            }
          : {
              prompt: prompt.trim(),
              imageBase64: uploadedImageBase64,
              mimeType,
              aspectRatio,
            };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.message || 'Image processing failed');
      }

      const newItem: GeneratedImageItem = {
        id: `img-${Date.now()}`,
        title: prompt.trim().slice(0, 36) + '...',
        prompt: prompt.trim(),
        mode,
        aspectRatio: data.aspectRatio || aspectRatio,
        imageUrl: data.imageUrl,
        originalImageUrl: mode === 'edit' ? uploadedImagePreview || undefined : undefined,
        createdAt: 'Just now',
        modelUsed: data.modelUsed || 'gemini-3.1-flash-lite-image',
      };

      setActiveResult(newItem);
      setGallery((prev) => [newItem, ...prev]);
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Failed to generate image. Please try again.');
    } finally {
      setLoading(false);
      setStatusMessage('');
    }
  };

  const handleCopyPrompt = () => {
    if (activeResult) {
      navigator.clipboard.writeText(activeResult.prompt);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    }
  };

  const handleUseForEdit = (imgItem: GeneratedImageItem) => {
    setMode('edit');
    setUploadedImagePreview(imgItem.imageUrl);
    if (imgItem.imageUrl.startsWith('data:')) {
      const parts = imgItem.imageUrl.split(',');
      setUploadedImageBase64(parts[1]);
      const mimeMatch = parts[0].match(/data:(.*?);/);
      if (mimeMatch) setMimeType(mimeMatch[1]);
    } else {
      // External URL
      fetch(imgItem.imageUrl)
        .then((r) => r.blob())
        .then((b) => {
          setMimeType(b.type || 'image/jpeg');
          const reader = new FileReader();
          reader.onloadend = () => {
            const full = reader.result as string;
            setUploadedImageBase64(full.split(',')[1]);
          };
          reader.readAsDataURL(b);
        })
        .catch(() => setUploadedImageBase64('sample'));
    }
    setPrompt(`Add gentle warm sunlight and extra flowers to this scene`);
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6">
      {/* Studio Header Subcard */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-teal-50 text-teal-700">
              <ImageIcon className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-900">
                Gemini Image Creation & Editing Studio
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Generate high-definition eldercare visuals from text prompts or edit existing photos using{' '}
                <span className="font-mono font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">
                  gemini-3.1-flash-lite-image
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center bg-slate-100 p-1.5 rounded-2xl border border-slate-200 self-start sm:self-auto">
          <button
            type="button"
            id="image-mode-create"
            onClick={() => setMode('create')}
            className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              mode === 'create'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Create from Text</span>
          </button>
          <button
            type="button"
            id="image-mode-edit"
            onClick={() => setMode('edit')}
            className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              mode === 'edit'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Edit with Prompts</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Prompting & Controls (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-5">
            {/* Mode Description Banner */}
            <div className="p-3.5 rounded-2xl bg-teal-50/70 border border-teal-100 flex items-start space-x-3 text-xs text-teal-900">
              <Info className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <div>
                {mode === 'create' ? (
                  <span>
                    <strong>Text-to-Image Creation:</strong> Describe any scene, landscape, soothing artwork, or elder wellness visual. The model will create a brand new image adhering to your prompt and selected aspect ratio.
                  </span>
                ) : (
                  <span>
                    <strong>Image Editing:</strong> Upload an image or pick a sample photo below, then describe the modifications you wish to make (e.g. "Add a fountain in the garden", "Make the sunset more golden", "Add a warm smile").
                  </span>
                )}
              </div>
            </div>

            {/* If Edit Mode: Source Image Upload & Sample Selector */}
            {mode === 'edit' && (
              <div className="space-y-3 pt-1 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Source Image to Edit *
                  </label>
                  {uploadedImagePreview && (
                    <button
                      type="button"
                      onClick={() => {
                        setUploadedImagePreview(null);
                        setUploadedImageBase64(null);
                      }}
                      className="text-[11px] font-bold text-rose-600 hover:underline cursor-pointer flex items-center space-x-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove Photo</span>
                    </button>
                  )}
                </div>

                {uploadedImagePreview ? (
                  <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 max-h-56 flex items-center justify-center">
                    <img
                      src={uploadedImagePreview}
                      alt="Source for editing"
                      referrerPolicy="no-referrer"
                      className="max-h-56 object-contain w-full"
                    />
                    <span className="absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-black/70 text-white text-[11px] font-bold backdrop-blur-xs">
                      Active Source Image
                    </span>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const file = e.dataTransfer.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                    className="border-2 border-dashed border-slate-300 hover:border-teal-500 rounded-2xl p-6 text-center transition bg-slate-50/50 cursor-pointer"
                    onClick={() => document.getElementById('image-upload-input')?.click()}
                  >
                    <Upload className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                    <p className="text-sm font-bold text-slate-800">
                      Upload photo or drag and drop here
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Supports JPG, PNG, WEBP files
                    </p>
                    <input
                      id="image-upload-input"
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(file);
                      }}
                      className="hidden"
                    />
                  </div>
                )}

                {/* Quick Sample Selector */}
                <div>
                  <span className="text-[11px] font-bold text-slate-500 block mb-2">
                    Or select a starter eldercare scene to edit:
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {SAMPLE_EDIT_IMAGES.map((sample, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSelectSampleEdit(sample)}
                        className="text-left p-2 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/40 transition cursor-pointer text-xs group"
                      >
                        <img
                          src={sample.url}
                          alt={sample.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-16 object-cover rounded-lg mb-1.5"
                        />
                        <span className="font-bold text-slate-800 block truncate group-hover:text-teal-700">
                          {sample.title}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Prompt Input Field */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                  <span>
                    {mode === 'create' ? 'Prompt Description *' : 'Edit Instruction Prompt *'}
                  </span>
                </label>
                <span className="text-[11px] font-mono text-slate-400">
                  {prompt.length} chars
                </span>
              </div>

              <textarea
                id="image-prompt-input"
                rows={3}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={
                  mode === 'create'
                    ? 'E.g., A peaceful Japanese rock garden with stepping stones and blooming cherry blossoms...'
                    : 'E.g., Add colorful wildflowers and a small stone bird bath next to the bench...'
                }
                className="w-full p-3.5 rounded-2xl border border-slate-200 focus:border-teal-600 focus:ring-2 focus:ring-teal-100 text-sm text-slate-900 transition resize-none outline-none leading-relaxed"
              />
            </div>

            {/* Inspiration Prompt Chips */}
            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-2">
                Quick Inspiration Ideas:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_PRESET_PROMPTS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPrompt(p)}
                    className="text-[11px] font-semibold text-slate-600 bg-slate-100 hover:bg-teal-50 hover:text-teal-700 px-3 py-1.5 rounded-xl border border-slate-200 transition text-left cursor-pointer"
                  >
                    {p.length > 55 ? `${p.slice(0, 52)}...` : p}
                  </button>
                ))}
              </div>
            </div>

            {/* Dimension & Aspect Ratio Controls */}
            <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Aspect Ratio */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-2">
                  Aspect Ratio
                </label>
                <div className="grid grid-cols-5 gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold text-center">
                  {(['1:1', '16:9', '4:3', '9:16', '3:4'] as const).map((ratio) => (
                    <button
                      key={ratio}
                      type="button"
                      onClick={() => setAspectRatio(ratio)}
                      className={`py-1.5 rounded-lg transition cursor-pointer ${
                        aspectRatio === ratio
                          ? 'bg-white text-teal-800 shadow-2xs font-extrabold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>
              </div>

              {/* Image Size (Create Mode) */}
              {mode === 'create' && (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-2">
                    Resolution Quality
                  </label>
                  <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold text-center">
                    {(['512px', '1K', '2K'] as const).map((sz) => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setImageSize(sz)}
                        className={`py-1.5 rounded-lg transition cursor-pointer ${
                          imageSize === sz
                            ? 'bg-white text-teal-800 shadow-2xs font-extrabold'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Generate Button */}
            <div className="pt-2">
              <button
                type="button"
                id="generate-image-btn"
                disabled={loading}
                onClick={handleSubmit}
                className="w-full py-3.5 px-6 rounded-2xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-black text-sm flex items-center justify-center space-x-2 shadow-sm transition disabled:opacity-50 cursor-pointer"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{statusMessage || 'Processing with Gemini 3.1...'}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>
                      {mode === 'create'
                        ? 'Generate Image with gemini-3.1-flash-lite-image'
                        : 'Apply Edits with gemini-3.1-flash-lite-image'}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Active Preview & High-Res Viewer (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Active Image Canvas
              </span>
              {activeResult && (
                <span className="text-[11px] font-mono font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full border border-teal-200">
                  {activeResult.modelUsed || 'gemini-3.1-flash-lite-image'}
                </span>
              )}
            </div>

            {activeResult ? (
              <div className="space-y-4">
                {/* Result Image with Container */}
                <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-950 group">
                  <img
                    src={activeResult.imageUrl}
                    alt={activeResult.title}
                    referrerPolicy="no-referrer"
                    className="w-full max-h-[360px] object-contain mx-auto"
                  />

                  {/* Overlaid Badges */}
                  <div className="absolute top-2 left-2 flex items-center gap-1.5">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-black/70 text-white backdrop-blur-xs font-bold">
                      {activeResult.aspectRatio}
                    </span>
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-teal-600/90 text-white backdrop-blur-xs">
                      {activeResult.mode === 'create' ? 'Generated' : 'Edited'}
                    </span>
                  </div>

                  {/* Zoom Button */}
                  <button
                    type="button"
                    onClick={() => setZoomedImage(activeResult.imageUrl)}
                    className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition cursor-pointer hover:bg-black/80"
                    title="View Fullscreen"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                </div>

                {/* If was edited: show side-by-side original reference */}
                {activeResult.originalImageUrl && (
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center space-x-3">
                    <img
                      src={activeResult.originalImageUrl}
                      alt="Original Reference"
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 object-cover rounded-xl border border-slate-200 shrink-0"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-slate-700 block">Original Source Photo</span>
                      <p className="text-slate-500 text-[11px] mt-0.5">
                        Edits applied based on text prompt instruction.
                      </p>
                    </div>
                  </div>
                )}

                {/* Prompt Details */}
                <div className="space-y-1.5 text-xs">
                  <span className="font-bold text-slate-800 block">Prompt Used:</span>
                  <p className="text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 italic leading-relaxed">
                    "{activeResult.prompt}"
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2 text-xs font-bold">
                  <a
                    href={activeResult.imageUrl}
                    download={`eldercare_${activeResult.id}.png`}
                    className="px-3.5 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download High-Res</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleCopyPrompt}
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    {copiedPrompt ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPrompt ? 'Copied!' : 'Copy Prompt'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleUseForEdit(activeResult)}
                    className="px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white flex items-center space-x-1.5 transition cursor-pointer"
                    title="Send this image to the editor"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>Edit This Image</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-16 text-center text-slate-400">
                <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p className="text-sm font-semibold text-slate-600">No Image Generated Yet</p>
                <p className="text-xs text-slate-400 mt-1">
                  Type a prompt on the left and tap generate to see results here.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Creations Session Gallery */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Session Creations Gallery</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Click any image to inspect, download, or use as an edit input.
            </p>
          </div>
          <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
            {gallery.length} items
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {gallery.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveResult(item)}
              className={`rounded-2xl border p-2.5 transition cursor-pointer group flex flex-col justify-between ${
                activeResult?.id === item.id
                  ? 'border-teal-600 bg-teal-50/30 shadow-xs'
                  : 'border-slate-200 bg-white hover:border-teal-300'
              }`}
            >
              <div className="relative rounded-xl overflow-hidden bg-slate-100 mb-2 aspect-square">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <span className="absolute top-1.5 left-1.5 text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/60 text-white font-bold">
                  {item.aspectRatio}
                </span>
                <span className="absolute top-1.5 right-1.5 text-[9px] uppercase px-1.5 py-0.5 rounded bg-teal-600 text-white font-bold">
                  {item.mode}
                </span>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 line-clamp-1 group-hover:text-teal-700">
                  {item.title}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5 font-mono">{item.createdAt}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fullscreen Zoom Modal */}
      {zoomedImage && (
        <div
          onClick={() => setZoomedImage(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs cursor-pointer"
        >
          <div className="relative max-w-4xl max-h-[90vh] bg-slate-900 rounded-3xl overflow-hidden p-2 shadow-2xl">
            <img
              src={zoomedImage}
              alt="Fullscreen Zoom"
              referrerPolicy="no-referrer"
              className="max-h-[85vh] max-w-full object-contain rounded-2xl mx-auto"
            />
          </div>
        </div>
      )}
    </div>
  );
};
