import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  ShieldAlert,
  User,
  RotateCcw,
  Loader2,
  MapPin,
  Stethoscope,
  Radio,
  ExternalLink,
  Compass,
  CheckCircle,
} from 'lucide-react';
import { Language, ChatRoleType, MapsGroundingPlace } from '../../types';
import { t } from '../../i18n';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  modelUsed?: string;
  roleType?: ChatRoleType;
}

interface HealthAssistantViewProps {
  language: Language;
}

export const HealthAssistantView: React.FC<HealthAssistantViewProps> = ({ language }) => {
  const [roleType] = useState<ChatRoleType>('general');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      text:
        language === 'hi'
          ? 'नमस्ते! मैं आपका SeniorCare जनरल स्वास्थ्य सहायक हूँ। मैं आपकी दवाओं, रक्तचाप, शुगर, और दैनिक स्वास्थ्य संबंधी प्रश्नों में सहायता के लिए यहाँ हूँ। आज आप क्या जानना चाहते हैं?'
          : language === 'mr'
          ? 'नमस्कार! मी आपला SeniorCare जनरल आरोग्य सहाय्यक आहे. मी आपली औषधे, रक्तदाब, साखर आणि दैनंदिन आरोग्याविषयी मदत करण्यासाठी उपस्थित आहे. आज मी आपल्याला कशी मदत करू?'
          : 'Hello! I am your SeniorCare General Health Assistant. I am here to help you with medication schedules, blood pressure, blood sugar readings, hydration, and daily wellness. How can I assist you today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      modelUsed: 'gemini-3.8-flash',
      roleType: 'general',
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);

  // Maps Grounding modal state (gemini-3.8-flash with googleMaps tool)
  const [showMapsModal, setShowMapsModal] = useState(false);
  const [mapsQuery, setMapsQuery] = useState('senior friendly hospitals and 24/7 pharmacies nearby');
  const [mapsLoading, setMapsLoading] = useState(false);
  const [mapsSummary, setMapsSummary] = useState('');
  const [mapsPlaces, setMapsPlaces] = useState<MapsGroundingPlace[]>([]);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locatingUser, setLocatingUser] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser');
      return;
    }
    setLocatingUser(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocatingUser(false);
      },
      (err) => {
        console.warn('Geolocation error:', err.message);
        setLocatingUser(false);
      },
      { timeout: 10000 }
    );
  };

  const handleFetchMapsGrounding = async (q?: string) => {
    const queryToSearch = (q || mapsQuery).trim();
    if (!queryToSearch || mapsLoading) return;

    setMapsLoading(true);
    setMapsSummary('');
    setMapsPlaces([]);

    try {
      const res = await fetch('/api/ai/maps-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: queryToSearch,
          latitude: userLocation?.lat,
          longitude: userLocation?.lng,
          language,
        }),
      });
      const data = await res.json();
      setMapsSummary(data.text || '');
      setMapsPlaces(data.places || []);
    } catch (err) {
      console.error(err);
      setMapsSummary('Unable to load nearby places right now. Please try again.');
    } finally {
      setMapsLoading(false);
    }
  };

  const suggestedQuestions = [
    'Why is regular hydration crucial for seniors even without feeling thirsty?',
    'What simple morning stretches help relieve stiff knee joints?',
    'How should I schedule my blood pressure medicines around meals?',
    'What fiber-rich foods are easiest on senior digestion?',
  ];

  const handleSend = async (textToSend?: string) => {
    const q = (textToSend || inputValue).trim();
    if (!q || loading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      roleType,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messages.map((m) => ({
            id: m.id,
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text,
            timestamp: m.timestamp,
          })),
          message: q,
          roleType,
          language,
        }),
      });
      const data = await res.json();

      const assistantMsg: Message = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'I am here to help you stay healthy and comfortable.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed || (roleType === 'complex' ? 'gemini-3.1-pro-preview' : roleType === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash'),
        roleType,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: 'I could not connect right now. Please verify your connection or try asking again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: roleType === 'complex' ? 'gemini-3.1-pro-preview' : roleType === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash',
        roleType,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  // Text-to-speech for voice read-aloud
  const toggleSpeech = (id: string, text: string) => {
    if (currentlySpeakingId === id) {
      window.speechSynthesis.cancel();
      setCurrentlySpeakingId(null);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.onend = () => setCurrentlySpeakingId(null);
      utterance.onerror = () => setCurrentlySpeakingId(null);
      window.speechSynthesis.speak(utterance);
      setCurrentlySpeakingId(id);
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header with Title and Maps Grounding Quick-Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center">
              <Bot className="w-6 h-6" />
            </div>
            <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
              {t('healthAssistant', language)}
            </h1>
          </div>
          <p className="text-slate-600 text-sm mt-1">
            Multi-turn contextual Gemini chat powered by Google AI models with role-tailored system instructions.
          </p>
        </div>

        {/* 1-Tap Google Maps Grounding Launch Button */}
        <button
          onClick={() => {
            setShowMapsModal(true);
            if (!mapsSummary && !mapsLoading) {
              handleFetchMapsGrounding();
            }
          }}
          className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-md hover:scale-102 transition cursor-pointer self-start sm:self-auto"
        >
          <MapPin className="w-4 h-4" />
          <span>Find Nearby Hospitals & Pharmacies (Maps Grounding)</span>
        </button>
      </div>

      {/* Unified General Health Assistant Overview Card */}
      <div className="bg-gradient-to-r from-teal-50 via-emerald-50 to-teal-50 p-4 sm:p-5 rounded-3xl border border-teal-200/80 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-2xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm sm:text-base text-teal-950">
              SeniorCare General Health Assistant
            </h3>
            <p className="text-xs text-teal-800">
              Grounded in your active prescriptions, recorded vitals, and standard clinical benchmarks.
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold bg-white text-teal-800 border border-teal-200 shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse" />
            General Health Mode (Active)
          </span>
        </div>
      </div>

      {/* Safety Medical Disclaimer */}
      <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start space-x-3">
        <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Medical Disclaimer:</span> This AI assistant provides general wellness education and does not replace emergency medical response or clinical treatment by a doctor. In acute distress, tap the red Emergency SOS button.
        </div>
      </div>

      {/* Multi-turn Chat Container */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col h-[560px] overflow-hidden">
        {/* Thread Header */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold text-slate-700">
              General Health Assistant
            </span>
          </div>

          <button
            onClick={() =>
              setMessages([
                {
                  id: `init-${Date.now()}`,
                  sender: 'assistant',
                  text: 'Conversation history reset. How can I help you with your health today?',
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  modelUsed: 'gemini-3.8-flash',
                  roleType: 'general',
                },
              ])
            }
            className="text-xs text-slate-500 hover:text-slate-800 flex items-center space-x-1 font-semibold cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Clear History</span>
          </button>
        </div>

        {/* Scrollable Messages Thread */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((m) => {
            const isUser = m.sender === 'user';
            return (
              <div
                key={m.id}
                className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0">
                    <Bot className="w-5 h-5" />
                  </div>
                )}

                <div
                  className={`max-w-[82%] rounded-2xl p-4 shadow-2xs ${
                    isUser
                      ? 'bg-teal-600 text-white rounded-tr-none'
                      : 'bg-slate-100 text-slate-900 rounded-tl-none border border-slate-200/60'
                  }`}
                >
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>

                  <div
                    className={`mt-2 pt-1.5 border-t flex items-center justify-between text-[11px] ${
                      isUser ? 'border-teal-500/30 text-teal-200' : 'border-slate-200 text-slate-400'
                    }`}
                  >
                    <span>{m.timestamp}</span>

                    {!isUser && (
                      <div className="flex items-center space-x-2">
                        {m.modelUsed && (
                          <span className="text-[10px] bg-white px-2 py-0.5 rounded-full text-slate-600 border border-slate-200 font-mono">
                            {m.modelUsed}
                          </span>
                        )}
                        <button
                          onClick={() => toggleSpeech(m.id, m.text)}
                          className="p-1 rounded-md hover:bg-slate-200 text-slate-600 flex items-center space-x-1 cursor-pointer"
                          title="Listen to this message"
                        >
                          {currentlySpeakingId === m.id ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                              <span className="text-[10px] text-rose-600 font-bold">Stop</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5 text-teal-700" />
                              <span className="text-[10px] text-teal-700 font-bold">Listen</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {isUser && (
                  <div className="w-9 h-9 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0">
                    <User className="w-5 h-5" />
                  </div>
                )}
              </div>
            );
          })}

          {loading && (
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5" />
              </div>
              <div className="bg-slate-100 rounded-2xl p-4 border border-slate-200 flex items-center space-x-2 text-slate-500 text-xs font-semibold">
                <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
                <span>
                  Consulting {roleType === 'complex' ? 'gemini-3.1-pro-preview' : roleType === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-3.5-flash'}...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Question Chips */}
        <div className="px-6 py-2 bg-slate-50 border-t border-slate-100 overflow-x-auto flex gap-2">
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:border-teal-400 hover:text-teal-800 px-3 py-1.5 rounded-full whitespace-nowrap cursor-pointer transition shadow-2xs"
            >
              💡 {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-white border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask a question about health, medication, or wellness..."
              className="flex-1 p-3.5 rounded-2xl border border-slate-200 text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none"
            />
            <button
              type="submit"
              disabled={loading || !inputValue.trim()}
              className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold rounded-2xl shadow-md transition disabled:opacity-50 cursor-pointer flex items-center space-x-1.5"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </form>
        </div>
      </div>

      {/* Google Maps Grounding Modal (gemini-3.5-flash with googleMaps tool) */}
      {showMapsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2 text-emerald-700">
                <MapPin className="w-5 h-5" />
                <h3 className="font-bold text-lg text-slate-900">
                  Google Maps Grounding (gemini-3.8-flash)
                </h3>
              </div>
              <button
                onClick={() => setShowMapsModal(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold px-2 py-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕ Close
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Real-time Google Maps data for senior-accessible medical centers, 24/7 pharmacies, and emergency hospitals.
            </p>

            {/* Geolocation selector & Search Input */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleGetLocation}
                  disabled={locatingUser}
                  className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
                >
                  {locatingUser ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Compass className="w-3.5 h-3.5" />}
                  <span>
                    {userLocation
                      ? `Location Active (${userLocation.lat.toFixed(2)}, ${userLocation.lng.toFixed(2)})`
                      : 'Use My GPS Location'}
                  </span>
                </button>
                <span className="text-[11px] text-slate-400">
                  Powered by gemini-3.8-flash with googleMaps tool
                </span>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={mapsQuery}
                  onChange={(e) => setMapsQuery(e.target.value)}
                  placeholder="e.g. 24/7 pharmacy, senior physiotherapy, eye care hospital..."
                  className="flex-1 p-3 rounded-xl border border-slate-200 text-xs sm:text-sm focus:border-teal-600 outline-none"
                />
                <button
                  onClick={() => handleFetchMapsGrounding()}
                  disabled={mapsLoading || !mapsQuery.trim()}
                  className="px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition disabled:opacity-50 cursor-pointer flex items-center space-x-1.5"
                >
                  {mapsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
                  <span>Search</span>
                </button>
              </div>
            </div>

            {/* Maps Results */}
            {mapsLoading && (
              <div className="py-12 flex flex-col items-center justify-center space-y-3 text-slate-500">
                <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
                <p className="text-xs font-semibold">Querying live Google Maps via gemini-3.8-flash...</p>
              </div>
            )}

            {!mapsLoading && mapsSummary && (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-wrap">
                {mapsSummary}
              </div>
            )}

            {!mapsLoading && mapsPlaces.length > 0 && (
              <div className="space-y-2.5 pt-2">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Verified Healthcare Locations ({mapsPlaces.length}):
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {mapsPlaces.map((place, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-emerald-300 transition flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <h5 className="font-bold text-xs text-slate-900 leading-tight">
                            {place.title}
                          </h5>
                          {place.uri && (
                            <a
                              href={place.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-emerald-700 hover:text-emerald-800 shrink-0"
                              title="Open in Google Maps"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                        {place.address && (
                          <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                            {place.address}
                          </p>
                        )}
                        {place.reviewSnippets && place.reviewSnippets.length > 0 && (
                          <p className="text-[11px] text-emerald-700/90 italic mt-1.5 bg-emerald-50/60 p-1.5 rounded-lg border border-emerald-100">
                            "{place.reviewSnippets[0]}"
                          </p>
                        )}
                      </div>

                      {place.uri && (
                        <a
                          href={place.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-2.5 inline-flex items-center space-x-1 text-[11px] font-bold text-emerald-700 hover:underline"
                        >
                          <span>Get Directions & Details</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

