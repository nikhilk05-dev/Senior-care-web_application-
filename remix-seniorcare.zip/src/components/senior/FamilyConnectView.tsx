import React, { useState } from 'react';
import {
  Users,
  Shield,
  Plus,
  Lock,
  Unlock,
  CheckCircle2,
  Trash2,
  Settings2,
  AlertCircle,
  Eye,
} from 'lucide-react';
import { FamilyMember, FamilyPermissions, Language } from '../../types';
import { t } from '../../i18n';

interface FamilyConnectViewProps {
  familyMembers: FamilyMember[];
  language: Language;
  onAddFamilyMember: (member: Partial<FamilyMember>) => void;
  onUpdatePermissions: (memberId: string, perms: Partial<FamilyPermissions>) => void;
  onRemoveFamilyMember: (id: string) => void;
}

export const FamilyConnectView: React.FC<FamilyConnectViewProps> = ({
  familyMembers,
  language,
  onAddFamilyMember,
  onUpdatePermissions,
  onRemoveFamilyMember,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState('Daughter');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    onAddFamilyMember({
      name,
      relationship,
      email,
      phone,
      status: 'active',
      permissions: {
        canViewMedicineAdherence: false, // Default is DENIED (Section 10)
        canViewAppointments: false,
        canViewHealthSummary: false,
        canViewEmergencyInfo: false,
        canViewWaterIntake: false,
      },
    });

    setName('');
    setEmail('');
    setPhone('');
    setShowAddModal(false);
  };

  const togglePermission = (
    member: FamilyMember,
    permKey: keyof FamilyPermissions
  ) => {
    const updated = {
      ...member.permissions,
      [permKey]: !member.permissions[permKey],
    };
    onUpdatePermissions(member.id, updated);
    if (selectedMember && selectedMember.id === member.id) {
      setSelectedMember({
        ...selectedMember,
        permissions: updated,
      });
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('familyConnect', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Stay connected with children and caregivers while maintaining complete control over your private healthcare data.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-md shadow-teal-700/20 flex items-center space-x-2 cursor-pointer transition"
        >
          <Plus className="w-5 h-5" />
          <span>Add Family Member</span>
        </button>
      </div>

      {/* Sovereign Privacy Principle Notice (Section 10) */}
      <div className="p-6 rounded-3xl bg-indigo-50/70 border border-indigo-200/80 flex items-start space-x-4">
        <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
          <Shield className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-bold text-base text-indigo-950">
            Sovereign Senior Privacy Architecture
          </h3>
          <p className="text-xs sm:text-sm text-indigo-900 mt-1 leading-relaxed">
            By default, <strong>all access is strictly DENIED</strong> to family members until you explicitly toggle permissions below. You can grant or revoke visibility into medicine schedules, appointments, vitals, or water intake at any second.
          </p>
        </div>
      </div>

      {/* Connected Members List */}
      <div className="space-y-4">
        <h3 className="font-bold text-xl text-slate-900">Connected Caregivers & Loved Ones</h3>

        {familyMembers.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
            <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-700 font-bold text-lg">No family members connected yet.</p>
            <p className="text-slate-500 text-sm mt-1 mb-4">
              Add your daughter, son, or trusted caregiver to help support your routine.
            </p>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-6 py-2.5 bg-teal-600 text-white font-bold rounded-xl cursor-pointer"
            >
              + Add Family Member
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {familyMembers.map((member) => {
              const activeCount = Object.values(member.permissions).filter(Boolean).length;
              return (
                <div
                  key={member.id}
                  className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 font-bold text-lg flex items-center justify-center">
                          {member.name.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-900 text-base">{member.name}</h4>
                          <p className="text-xs text-slate-500">
                            {member.relationship} • {member.phone}
                          </p>
                        </div>
                      </div>

                      <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                        {member.status}
                      </span>
                    </div>

                    {/* Permissions summary */}
                    <div className="mt-4">
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="font-bold text-slate-600">Granted Permissions:</span>
                        <span className="font-bold text-indigo-700">{activeCount} of 5 Enabled</span>
                      </div>

                      <div className="space-y-2">
                        {[
                          { key: 'canViewMedicineAdherence', label: 'Medicine Schedules & Doses' },
                          { key: 'canViewAppointments', label: 'Upcoming Appointments' },
                          { key: 'canViewHealthSummary', label: 'Health Readings & Vitals' },
                          { key: 'canViewEmergencyInfo', label: 'Emergency Medical Card' },
                          { key: 'canViewWaterIntake', label: 'Daily Water Intake' },
                        ].map((perm) => {
                          const isAllowed = member.permissions[perm.key as keyof FamilyPermissions];
                          return (
                            <div
                              key={perm.key}
                              className={`p-2.5 rounded-xl border text-xs flex items-center justify-between transition ${
                                isAllowed
                                  ? 'bg-teal-50/60 border-teal-200 text-teal-900'
                                  : 'bg-slate-50 border-slate-200 text-slate-400'
                              }`}
                            >
                              <div className="flex items-center space-x-2">
                                {isAllowed ? (
                                  <Unlock className="w-3.5 h-3.5 text-teal-600" />
                                ) : (
                                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                                )}
                                <span className={isAllowed ? 'font-bold' : 'font-normal'}>
                                  {perm.label}
                                </span>
                              </div>
                              <button
                                onClick={() =>
                                  togglePermission(member, perm.key as keyof FamilyPermissions)
                                }
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition ${
                                  isAllowed
                                    ? 'bg-teal-600 text-white hover:bg-teal-700'
                                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                                }`}
                              >
                                {isAllowed ? 'Allowed' : 'Denied'}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">{member.email}</span>
                    <button
                      onClick={() => {
                        if (confirm(`Remove ${member.name} from family access?`)) {
                          onRemoveFamilyMember(member.id);
                        }
                      }}
                      className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-xl cursor-pointer"
                      title="Revoke and Remove Access"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Family Member Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-display font-bold text-xl text-slate-900">Add Family Member</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddMember} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Priya Patel"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Relationship
                  </label>
                  <select
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-white"
                  >
                    <option value="Daughter">Daughter</option>
                    <option value="Son">Son</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Caregiver">Professional Caregiver</option>
                    <option value="Grandchild">Grandchild</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="priya@example.com"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                Notice: All permissions start as <strong>DENIED</strong> for privacy protection. You will be able to customize specific visibility permissions after saving.
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md cursor-pointer"
                >
                  Connect Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
