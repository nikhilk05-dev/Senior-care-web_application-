import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  ReferenceLine,
  Cell,
} from 'recharts';
import { Droplets, CheckCircle2, AlertCircle, Plus, Info, Award } from 'lucide-react';
import { WaterDay, Language } from '../../types';

interface HydrationChartProps {
  waterToday: WaterDay;
  waterHistory?: WaterDay[];
  language?: Language;
  onAddGlass?: () => void;
}

interface ChartDataItem {
  date: string;
  dayLabel: string;
  shortDate: string;
  consumedMl: number;
  targetMl: number;
  consumedGlasses: number;
  targetGlasses: number;
  percentage: number;
  isMet: boolean;
  isToday: boolean;
}

export const HydrationChart: React.FC<HydrationChartProps> = ({
  waterToday,
  waterHistory = [],
  language = 'en',
  onAddGlass,
}) => {
  const [unit, setUnit] = useState<'ml' | 'glasses'>('ml');

  // Prepare 7-day chronological dataset (from 6 days ago to Today)
  const chartData = useMemo<ChartDataItem[]>(() => {
    const todayDateStr = waterToday?.date || new Date().toISOString().split('T')[0];
    const parts = todayDateStr.split('-').map(Number);
    const year = parts[0] || new Date().getFullYear();
    const month = parts[1] || (new Date().getMonth() + 1);
    const day = parts[2] || new Date().getDate();

    const todayTarget = waterToday?.targetMl || 2000;
    const todayConsumed = waterToday?.consumedMl || 0;
    const todayGlasses = waterToday?.glasses || Math.round(todayConsumed / 250);

    // Build map from incoming waterHistory
    const historyMap = new Map<string, WaterDay>();
    if (Array.isArray(waterHistory)) {
      waterHistory.forEach((item) => {
        if (item && item.date) {
          historyMap.set(item.date, item);
        }
      });
    }

    // Always ensure current waterToday is freshest for today's date
    if (waterToday) {
      historyMap.set(todayDateStr, waterToday);
    }

    // Default mock reference if some past days are missing
    const defaultPastLevels = [1750, 2000, 1500, 2250, 1750, 2000];

    const result: ChartDataItem[] = [];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(year, month - 1, day - i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const dateStr = `${yyyy}-${mm}-${dd}`;
      const isToday = i === 0;

      const weekdayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const dayName = isToday ? 'Today' : weekdayNames[d.getDay()];
      const shortDate = `${d.getMonth() + 1}/${d.getDate()}`;

      let record = historyMap.get(dateStr);

      if (!record) {
        // Fallback realistic baseline if day is missing in DB
        const fallbackConsumed = isToday
          ? todayConsumed
          : defaultPastLevels[(6 - i) % defaultPastLevels.length];
        const target = todayTarget;
        record = {
          date: dateStr,
          consumedMl: fallbackConsumed,
          targetMl: target,
          glasses: Math.round(fallbackConsumed / 250),
        };
      }

      // If it is today, always prioritize current active waterToday values
      const consumedMl = isToday ? todayConsumed : (record.consumedMl || 0);
      const targetMl = isToday ? todayTarget : (record.targetMl || 2000);
      const consumedGlasses = isToday ? todayGlasses : (record.glasses || Math.round(consumedMl / 250));
      const targetGlasses = Math.round(targetMl / 250) || 8;
      const percentage = targetMl > 0 ? Math.round((consumedMl / targetMl) * 100) : 0;
      const isMet = consumedMl >= targetMl;

      result.push({
        date: dateStr,
        dayLabel: dayName,
        shortDate,
        consumedMl,
        targetMl,
        consumedGlasses,
        targetGlasses,
        percentage,
        isMet,
        isToday,
      });
    }

    return result;
  }, [waterToday, waterHistory]);

  // Derived 7-day stats
  const stats = useMemo(() => {
    const totalMl = chartData.reduce((acc, item) => acc + item.consumedMl, 0);
    const avgMl = Math.round(totalMl / chartData.length);
    const avgGlasses = (avgMl / 250).toFixed(1);
    const daysMet = chartData.filter((item) => item.isMet).length;
    const completionRate = Math.round((daysMet / chartData.length) * 100);

    return {
      totalMl,
      avgMl,
      avgGlasses,
      daysMet,
      completionRate,
    };
  }, [chartData]);

  // Custom Recharts Tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data: ChartDataItem = payload[0].payload;
      const remainingMl = Math.max(0, data.targetMl - data.consumedMl);
      const remainingGlasses = Math.max(0, data.targetGlasses - data.consumedGlasses);

      return (
        <div
          id="hydration-chart-tooltip"
          className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl border border-slate-700 min-w-[200px] text-xs"
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-700/80 mb-2">
            <div>
              <span className="font-bold text-sm text-white">
                {data.dayLabel} {data.isToday && '(Current)'}
              </span>
              <span className="text-[11px] text-slate-400 block">{data.date}</span>
            </div>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                data.isMet
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
              }`}
            >
              {data.percentage}% Met
            </span>
          </div>

          <div className="space-y-1.5 font-medium">
            <div className="flex items-center justify-between">
              <span className="text-slate-300 flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-sky-400 inline-block" />
                <span>Consumed:</span>
              </span>
              <span className="font-bold text-white">
                {unit === 'ml'
                  ? `${data.consumedMl.toLocaleString()} ml`
                  : `${data.consumedGlasses} glasses`}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-300 flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-400 inline-block" />
                <span>Daily Goal:</span>
              </span>
              <span className="font-bold text-amber-300">
                {unit === 'ml'
                  ? `${data.targetMl.toLocaleString()} ml`
                  : `${data.targetGlasses} glasses`}
              </span>
            </div>

            <div className="pt-2 border-t border-slate-800 text-[11px]">
              {data.isMet ? (
                <div className="flex items-center space-x-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span>Goal achieved for this day!</span>
                </div>
              ) : (
                <div className="flex items-center space-x-1 text-amber-300">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {unit === 'ml'
                      ? `${remainingMl.toLocaleString()} ml remaining`
                      : `${remainingGlasses} glasses remaining`}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const primaryTarget = waterToday.targetMl || 2000;
  const primaryTargetValue = unit === 'ml' ? primaryTarget : Math.round(primaryTarget / 250);

  return (
    <div
      id="senior-hydration-progress-chart"
      className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm"
    >
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-xl text-slate-900 tracking-tight">
                7-Day Hydration Progress vs Goal
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Daily fluid intake tracked against your personalized {primaryTarget} ml target
              </p>
            </div>
          </div>
        </div>

        {/* Action & Unit Controls */}
        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          {/* Unit Toggle */}
          <div
            id="hydration-unit-toggle"
            className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold text-slate-600"
          >
            <button
              type="button"
              onClick={() => setUnit('ml')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                unit === 'ml'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Milliliters (ml)
            </button>
            <button
              type="button"
              onClick={() => setUnit('glasses')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                unit === 'glasses'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Glasses (250ml)
            </button>
          </div>

          {onAddGlass && (
            <button
              type="button"
              onClick={onAddGlass}
              className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-bold text-xs flex items-center space-x-1.5 shadow-sm transition cursor-pointer shrink-0"
              title="Quickly log +1 glass of water"
            >
              <Plus className="w-4 h-4" />
              <span>Log +1 Glass</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary KPI Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 my-5">
        <div className="p-4 rounded-2xl bg-sky-50/70 border border-sky-100">
          <span className="text-[11px] font-bold text-sky-800 uppercase tracking-wider block">
            7-Day Daily Average
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-900">
              {unit === 'ml' ? `${stats.avgMl.toLocaleString()} ml` : `${stats.avgGlasses} glasses`}
            </span>
            <span className="text-xs font-semibold text-slate-500">/ day</span>
          </div>
          <span className="text-[11px] text-sky-700 font-medium mt-1 block">
            {stats.avgMl >= primaryTarget
              ? 'On track with recommended daily baseline'
              : `${Math.round(primaryTarget - stats.avgMl)} ml below daily target`}
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100">
          <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
            Goal Achievement
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-900">
              {stats.daysMet} of 7 days
            </span>
            <span className="text-xs font-bold text-emerald-700">({stats.completionRate}%)</span>
          </div>
          <span className="text-[11px] text-emerald-700 font-medium mt-1 block flex items-center space-x-1">
            <Award className="w-3.5 h-3.5 shrink-0" />
            <span>Target was fully achieved on {stats.daysMet} days</span>
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Today’s Intake
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-900">
              {unit === 'ml'
                ? `${waterToday.consumedMl.toLocaleString()} ml`
                : `${waterToday.glasses} glasses`}
            </span>
            <span className="text-xs font-semibold text-slate-500">
              / {unit === 'ml' ? `${primaryTarget} ml` : `${Math.round(primaryTarget / 250)} gl`}
            </span>
          </div>
          <span className="text-[11px] text-slate-600 font-medium mt-1 block">
            {waterToday.consumedMl >= primaryTarget
              ? 'Daily target reached for today!'
              : `${Math.max(0, Math.round((primaryTarget - waterToday.consumedMl) / 250))} glasses left to reach goal`}
          </span>
        </div>
      </div>

      {/* Main Recharts Chart Visualization */}
      <div className="mt-4 w-full h-[280px] sm:h-[320px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={chartData}
            margin={{ top: 20, right: 16, left: -10, bottom: 4 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis
              dataKey="dayLabel"
              tickLine={false}
              axisLine={{ stroke: '#cbd5e1' }}
              tick={({ x, y, payload }) => {
                const item = chartData.find((d) => d.dayLabel === payload.value);
                const isToday = item?.isToday;
                return (
                  <g transform={`translate(${x},${y})`}>
                    <text
                      x={0}
                      y={0}
                      dy={14}
                      textAnchor="middle"
                      fill={isToday ? '#0284c7' : '#475569'}
                      fontWeight={isToday ? 800 : 600}
                      fontSize={13}
                    >
                      {payload.value}
                    </text>
                    {item && (
                      <text
                        x={0}
                        y={0}
                        dy={28}
                        textAnchor="middle"
                        fill="#94a3b8"
                        fontSize={10}
                        fontWeight={500}
                      >
                        {item.shortDate}
                      </text>
                    )}
                  </g>
                );
              }}
              height={44}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tick={{ fill: '#64748b', fontSize: 11, fontWeight: 600 }}
              domain={[
                0,
                unit === 'ml'
                  ? (dataMax: number) =>
                      Number.isFinite(dataMax) && dataMax > 0
                        ? Math.max(2500, Math.ceil((dataMax + 250) / 250) * 250)
                        : 2500
                  : (dataMax: number) =>
                      Number.isFinite(dataMax) && dataMax > 0
                        ? Math.max(10, Math.ceil(dataMax) + 2)
                        : 10,
              ]}
              tickFormatter={(value) =>
                unit === 'ml' ? `${value}` : `${value} gl`
              }
            />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(241, 245, 249, 0.6)' }} />
            <Legend
              verticalAlign="top"
              align="right"
              wrapperStyle={{ paddingBottom: 12, fontSize: 12, fontWeight: 600 }}
              formatter={(value) => (
                <span className="text-slate-700 mr-2">{value}</span>
              )}
            />

            {/* Daily Goal Target Reference Line */}
            <ReferenceLine
              y={primaryTargetValue}
              stroke="#f59e0b"
              strokeDasharray="4 4"
              strokeWidth={2}
              label={{
                value: `Goal (${unit === 'ml' ? `${primaryTarget}ml` : `${primaryTargetValue} gl`})`,
                fill: '#b45309',
                fontSize: 11,
                fontWeight: 700,
                position: 'insideTopRight',
              }}
            />

            {/* Consumed Water Bar */}
            <Bar
              dataKey={unit === 'ml' ? 'consumedMl' : 'consumedGlasses'}
              name={unit === 'ml' ? 'Water Consumed (ml)' : 'Water Consumed (glasses)'}
              radius={[8, 8, 0, 0]}
              maxBarSize={48}
            >
              {chartData.map((entry, index) => {
                // Color variation: Met target is vibrant solid teal/sky, Below target is softer sky blue
                // Today has distinct saturation
                let barColor = entry.isMet ? '#0284c7' : '#38bdf8';
                if (entry.isToday) {
                  barColor = entry.isMet ? '#0369a1' : '#0284c7';
                }
                return (
                  <Cell
                    key={`cell-${index}`}
                    fill={barColor}
                    stroke={entry.isToday ? '#0369a1' : 'none'}
                    strokeWidth={entry.isToday ? 2 : 0}
                  />
                );
              })}
            </Bar>

            {/* Daily Goal Line across days */}
            <Line
              type="monotone"
              dataKey={unit === 'ml' ? 'targetMl' : 'targetGlasses'}
              name={unit === 'ml' ? 'Target Goal (ml)' : 'Target Goal (glasses)'}
              stroke="#f59e0b"
              strokeWidth={2.5}
              strokeDasharray="4 4"
              dot={{ r: 4, fill: '#f59e0b', strokeWidth: 2, stroke: '#ffffff' }}
              activeDot={{ r: 6, fill: '#d97706', stroke: '#ffffff', strokeWidth: 2 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Footer Notes & Health Guidance */}
      <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-slate-500">
        <div className="flex items-center space-x-2">
          <Info className="w-4 h-4 text-sky-500 shrink-0" />
          <span>
            Goal is based on geriatric wellness guidelines (approx. 250ml per glass).
          </span>
        </div>
        <div className="flex items-center space-x-3 text-[11px] font-semibold">
          <span className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-sky-600 inline-block" />
            <span className="text-slate-600">Goal Met</span>
          </span>
          <span className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-sky-300 inline-block" />
            <span className="text-slate-600">In Progress</span>
          </span>
          <span className="flex items-center space-x-1.5">
            <span className="w-3 h-0.5 border-t-2 border-dashed border-amber-500 inline-block" />
            <span className="text-slate-600">Target Line</span>
          </span>
        </div>
      </div>
    </div>
  );
};
