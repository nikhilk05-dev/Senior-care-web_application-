import React, { useState } from 'react';
import {
  Lightbulb,
  Volume2,
  VolumeX,
  Filter,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { HealthTip, Language } from '../../types';
import { t } from '../../i18n';

interface HealthTipsViewProps {
  tips: HealthTip[];
  language: Language;
}

export const HealthTipsView: React.FC<HealthTipsViewProps> = ({ tips, language }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);

  const categories = [
    'All',
    'Hydration',
    'Nutrition',
    'Medicine Safety',
    'Exercise & Mobility',
    'Sleep & Rest',
    'Mental Wellness',
    'Preventive Care',
  ];

  const filteredTips =
    selectedCategory === 'All'
      ? tips
      : tips.filter(
          (tip) => tip.category.toLowerCase() === selectedCategory.toLowerCase()
        );

  const toggleSpeech = (tip: HealthTip) => {
    if (currentlySpeakingId === tip.id) {
      window.speechSynthesis.cancel();
      setCurrentlySpeakingId(null);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(`${tip.title}. ${tip.content}`);
      utterance.rate = 0.9;
      utterance.onend = () => setCurrentlySpeakingId(null);
      utterance.onerror = () => setCurrentlySpeakingId(null);
      window.speechSynthesis.speak(utterance);
      setCurrentlySpeakingId(tip.id);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
          {t('healthTips', language)}
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Daily wellness practices and safety advice written specifically for senior vitality.
        </p>
      </div>

      {/* Category Pills (Section 13) */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              selectedCategory === cat
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Tips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredTips.map((tip) => (
          <div
            key={tip.id}
            className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-teal-300 transition flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900">
                  {tip.category}
                </span>

                <button
                  onClick={() => toggleSpeech(tip)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-teal-50 text-slate-700 hover:text-teal-800 text-xs font-bold flex items-center space-x-1 cursor-pointer transition shadow-2xs"
                  title="Read tip aloud"
                >
                  {currentlySpeakingId === tip.id ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                      <span className="text-rose-600">Stop Reading</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-teal-700" />
                      <span>{t('listenTip', language)}</span>
                    </>
                  )}
                </button>
              </div>

              <div className="mt-4">
                <h3 className="font-extrabold text-lg text-slate-900 leading-snug">{tip.title}</h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">{tip.content}</p>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-slate-100 text-xs text-slate-400">
              Verified for Senior Vitality & Safety
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
