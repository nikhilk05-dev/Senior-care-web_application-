import React, { useState } from 'react';
import {
  Activity,
  Plus,
  Filter,
  Download,
  Printer,
  Trash2,
  TrendingUp,
  Heart,
  Droplet,
  Thermometer,
  Wind,
  FileText,
  Info,
  CheckCircle2,
  AlertCircle,
  Scale,
} from 'lucide-react';
import { HealthRecord, HealthRecordType, Language } from '../../types';
import { t } from '../../i18n';

interface HealthRecordsViewProps {
  records: HealthRecord[];
  language: Language;
  onAddRecord: (record: Partial<HealthRecord>) => void;
  onDeleteRecord: (id: string) => void;
}

// Standard medical reference counts required for any person (adult / senior)
export interface MetricNormalInfo {
  label: string;
  shortBracket: string;
  fullBracket: string;
  requiredDescription: string;
  unit: string;
  example: string;
  icon: any;
  color: string;
  badgeBg: string;
  badgeText: string;
}

export const NORMAL_METRIC_COUNTS: Record<HealthRecordType, MetricNormalInfo> = {
  blood_pressure: {
    label: 'Blood Pressure',
    shortBracket: '(Normal: 120/80 mmHg | Required: 90/60 – 120/80 mmHg)',
    fullBracket: '(Normal count required: 90/60 to 120/80 mmHg)',
    requiredDescription: 'Systolic required 90–120 mmHg, Diastolic required 60–80 mmHg for any healthy adult.',
    unit: 'mmHg',
    example: '120/80',
    icon: Heart,
    color: 'rose',
    badgeBg: 'bg-rose-50 border-rose-200 text-rose-800',
    badgeText: 'text-rose-700',
  },
  blood_sugar: {
    label: 'Blood Sugar',
    shortBracket: '(Normal: 70–140 mg/dL | Fasting: 70–99 mg/dL, Post-Meal: <140 mg/dL)',
    fullBracket: '(Normal count required: Fasting 70–99 mg/dL, Post-Meal <140 mg/dL)',
    requiredDescription: 'Fasting glucose required: 70–99 mg/dL; 2 hours after meal required: under 140 mg/dL.',
    unit: 'mg/dL',
    example: '110',
    icon: Droplet,
    color: 'amber',
    badgeBg: 'bg-amber-50 border-amber-200 text-amber-800',
    badgeText: 'text-amber-700',
  },
  oxygen: {
    label: 'SpO2 Oxygen',
    shortBracket: '(Normal: 95%–100% | Required: ≥95%)',
    fullBracket: '(Normal count required: 95% to 100% blood oxygen)',
    requiredDescription: 'Resting pulse oximeter oxygen required at least 95% for safe organ and brain oxygenation.',
    unit: '%',
    example: '98',
    icon: Wind,
    color: 'sky',
    badgeBg: 'bg-sky-50 border-sky-200 text-sky-800',
    badgeText: 'text-sky-700',
  },
  heart_rate: {
    label: 'Heart Rate (Health Rate)',
    shortBracket: '(Normal: 60–100 bpm | Required: 60–100 bpm)',
    fullBracket: '(Normal count required: 60 to 100 beats per minute for any person)',
    requiredDescription: 'Resting pulse / health rate required between 60 and 100 bpm for any person at rest.',
    unit: 'bpm',
    example: '72',
    icon: Activity,
    color: 'emerald',
    badgeBg: 'bg-emerald-50 border-emerald-200 text-emerald-800',
    badgeText: 'text-emerald-700',
  },
  weight: {
    label: 'Weight',
    shortBracket: '(Normal: 50–80 kg | BMI: 18.5–24.9)',
    fullBracket: '(Normal count required: 50–80 kg typical based on height / BMI 18.5–24.9 for any person)',
    requiredDescription: 'Healthy weight range required based on height to maintain BMI between 18.5 and 24.9.',
    unit: 'kg',
    example: '68',
    icon: Scale,
    color: 'indigo',
    badgeBg: 'bg-indigo-50 border-indigo-200 text-indigo-800',
    badgeText: 'text-indigo-700',
  },
  temperature: {
    label: 'Temperature',
    shortBracket: '(Normal: 97.8°F–99.1°F / 36.5°C–37.3°C | Required: ~98.6°F / 37.0°C)',
    fullBracket: '(Normal count required: 97.8°F to 99.1°F / 36.5°C to 37.3°C)',
    requiredDescription: 'Standard resting body temperature required is ~98.6°F (37.0°C). Above 100.4°F indicates fever.',
    unit: '°F',
    example: '98.6',
    icon: Thermometer,
    color: 'orange',
    badgeBg: 'bg-orange-50 border-orange-200 text-orange-800',
    badgeText: 'text-orange-700',
  },
  symptoms: {
    label: 'Symptoms / Well-being',
    shortBracket: '(Normal: Pain-free, steady balance, clear breathing)',
    fullBracket: '(Normal status: Alert, restful, comfortable)',
    requiredDescription: 'Log daily pain levels, dizziness, or wellness notes.',
    unit: 'status',
    example: 'Feeling well',
    icon: Activity,
    color: 'teal',
    badgeBg: 'bg-teal-50 border-teal-200 text-teal-800',
    badgeText: 'text-teal-700',
  },
  doctor_notes: {
    label: 'Doctor Notes',
    shortBracket: '(Normal: Routine clinical follow-up advice)',
    fullBracket: '(Normal: Doctor consultation notes and lab advice)',
    requiredDescription: 'Prescriptions and physician clinical notes.',
    unit: 'notes',
    example: 'Checkup complete',
    icon: FileText,
    color: 'slate',
    badgeBg: 'bg-slate-50 border-slate-200 text-slate-800',
    badgeText: 'text-slate-700',
  },
};

export const HealthRecordsView: React.FC<HealthRecordsViewProps> = ({
  records,
  language,
  onAddRecord,
  onDeleteRecord,
}) => {
  const [selectedType, setSelectedType] = useState<HealthRecordType | 'all'>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [type, setType] = useState<HealthRecordType>('blood_pressure');
  const [value, setValue] = useState('');
  const [unit, setUnit] = useState('mmHg');
  const [notes, setNotes] = useState('');

  const filteredRecords = selectedType === 'all'
    ? records
    : records.filter((r) => r.type === selectedType);

  const handleTypeChange = (newType: HealthRecordType) => {
    setType(newType);
    const info = NORMAL_METRIC_COUNTS[newType];
    if (info) {
      setUnit(info.unit);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!value.trim()) return;

    onAddRecord({
      type,
      value: value.trim(),
      unit,
      notes: notes.trim(),
      recordedDate: new Date().toISOString().split('T')[0],
      recordedTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });

    setValue('');
    setNotes('');
    setShowAddModal(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['Date,Time,Metric,Value,Unit,Normal Count Required,Notes']
        .concat(
          records.map((r) => {
            const normalInfo = NORMAL_METRIC_COUNTS[r.type]?.shortBracket || '';
            return `"${r.recordedDate}","${r.recordedTime}","${r.type}","${r.value}","${r.unit}","${normalInfo}","${r.notes || ''}"`;
          })
        )
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'seniorcare_health_records.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activeMetricInfo = NORMAL_METRIC_COUNTS[type] || NORMAL_METRIC_COUNTS.blood_pressure;

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('healthRecords', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Track daily vitals with standard normal reference counts required for any person.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer shadow-2xs"
            title="Print Health Summary"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Report</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer shadow-2xs"
            title="Download CSV"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            id="add-health-reading-btn"
            onClick={() => {
              setType('blood_pressure');
              setUnit('mmHg');
              setValue('');
              setShowAddModal(true);
            }}
            className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-xs shadow-md shadow-teal-700/20 flex items-center space-x-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addHealthReading', language)}</span>
          </button>
        </div>
      </div>

      {/* Standard Normal Counts Reference Board (Requested by User) */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-7 shadow-xl border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-teal-500/20 text-teal-300">
              <Info className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-white">
                Standard Normal Counts Required For Any Person
              </h3>
              <p className="text-xs text-teal-200">
                Official medical benchmark ranges displayed in brackets for immediate reference
              </p>
            </div>
          </div>
          <span className="text-[11px] font-mono bg-white/10 px-2.5 py-1 rounded-full text-slate-300 hidden sm:inline-block">
            Clinical Reference
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {/* Blood Pressure */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 hover:bg-white/10 transition">
            <div className="flex items-center space-x-2 text-rose-300 font-bold text-xs">
              <Heart className="w-4 h-4 text-rose-400" />
              <span>Blood Pressure</span>
            </div>
            <p className="text-sm font-black text-white mt-1">
              (Normal: 120/80 mmHg)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Required: <strong className="text-rose-200">90/60 – 120/80 mmHg</strong>
            </p>
          </div>

          {/* Blood Sugar */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 hover:bg-white/10 transition">
            <div className="flex items-center space-x-2 text-amber-300 font-bold text-xs">
              <Droplet className="w-4 h-4 text-amber-400" />
              <span>Blood Sugar</span>
            </div>
            <p className="text-sm font-black text-white mt-1">
              (Normal: 70–140 mg/dL)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Required: <strong className="text-amber-200">Fasting: 70–99 | Post-Meal: &lt;140</strong>
            </p>
          </div>

          {/* SpO2 Oxygen */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 hover:bg-white/10 transition">
            <div className="flex items-center space-x-2 text-sky-300 font-bold text-xs">
              <Wind className="w-4 h-4 text-sky-400" />
              <span>SpO2 Oxygen Saturation</span>
            </div>
            <p className="text-sm font-black text-white mt-1">
              (Normal: 95%–100%)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Required: <strong className="text-sky-200">≥ 95% blood saturation</strong>
            </p>
          </div>

          {/* Heart Rate */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 hover:bg-white/10 transition">
            <div className="flex items-center space-x-2 text-emerald-300 font-bold text-xs">
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>Heart Rate (Pulse)</span>
            </div>
            <p className="text-sm font-black text-white mt-1">
              (Normal: 60–100 bpm)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Resting required: <strong className="text-emerald-200">60–100 beats/min</strong>
            </p>
          </div>

          {/* Weight */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 hover:bg-white/10 transition">
            <div className="flex items-center space-x-2 text-indigo-300 font-bold text-xs">
              <Scale className="w-4 h-4 text-indigo-400" />
              <span>Body Weight</span>
            </div>
            <p className="text-sm font-black text-white mt-1">
              (Normal BMI: 18.5–24.9)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Required: <strong className="text-indigo-200">50–80 kg (based on height)</strong>
            </p>
          </div>

          {/* Temperature */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 hover:bg-white/10 transition">
            <div className="flex items-center space-x-2 text-orange-300 font-bold text-xs">
              <Thermometer className="w-4 h-4 text-orange-400" />
              <span>Body Temperature</span>
            </div>
            <p className="text-sm font-black text-white mt-1">
              (Normal: 97.8°F–99.1°F / 36.5°C–37.3°C)
            </p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Required average: <strong className="text-orange-200">~98.6°F / 37.0°C</strong>
            </p>
          </div>
        </div>
      </div>

      {/* Visual Trends Preview */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-teal-600" />
            <h3 className="font-bold text-lg text-slate-900">Health Vitals Trends Overview</h3>
          </div>
          <span className="text-xs font-semibold text-slate-500">Last 7 Days</span>
        </div>

        {/* Visual trend curve chart using SVG */}
        <div className="mt-6">
          <div className="h-44 w-full flex items-end justify-between gap-2 px-2 pb-2 border-b border-slate-200">
            {records.slice(0, 7).map((r, i) => {
              const numVal = parseFloat(r.value) || 120;
              const heightPct = Math.min(100, Math.max(25, (numVal / 180) * 100));
              return (
                <div key={r.id || i} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-[11px] font-bold text-slate-700">{r.value}</span>
                  <div
                    className="w-full max-w-[42px] bg-gradient-to-t from-teal-600 to-teal-400 rounded-t-xl transition-all duration-500 shadow-xs"
                    style={{ height: `${heightPct}%` }}
                  />
                  <span className="text-[10px] text-slate-400 truncate max-w-[50px]">
                    {r.recordedDate.slice(5)}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between items-center text-xs text-slate-400 mt-2 px-2">
            <span>Older readings</span>
            <span className="font-bold text-teal-700">Latest recordings</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs with Normal Counts in Brackets */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5 text-teal-600" />
            <span>Select Vitals Category (Normal count shown in brackets):</span>
          </span>
          <span className="text-xs text-slate-400 font-semibold">
            Showing {filteredRecords.length} records
          </span>
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto py-1.5 scrollbar-thin">
          {[
            { id: 'all', label: 'All Records', bracket: '' },
            { id: 'blood_pressure', label: 'Blood Pressure', bracket: '(Normal: 120/80 mmHg | Required: 90/60 – 120/80 mmHg)' },
            { id: 'blood_sugar', label: 'Blood Sugar', bracket: '(Normal: 70–140 mg/dL | Fasting: 70–99 mg/dL, Post-Meal: <140 mg/dL)' },
            { id: 'oxygen', label: 'SpO2 Oxygen', bracket: '(Normal: 95%–100% | Required: ≥95%)' },
            { id: 'heart_rate', label: 'Heart Rate (Health Rate)', bracket: '(Normal: 60–100 bpm | Required: 60–100 bpm)' },
            { id: 'weight', label: 'Weight', bracket: '(Normal: 50–80 kg | BMI: 18.5–24.9)' },
            { id: 'temperature', label: 'Temperature', bracket: '(Normal: 97.8°F–99.1°F / 36.5°C–37.3°C | Required: ~98.6°F)' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedType(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs whitespace-nowrap cursor-pointer transition flex items-center space-x-1.5 ${
                selectedType === tab.id
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>{tab.label}</span>
              {tab.bracket && (
                <span className={`text-[10px] font-normal ${selectedType === tab.id ? 'text-teal-100' : 'text-slate-500'}`}>
                  {tab.bracket}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Records Grid */}
      {filteredRecords.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 shadow-2xs">
          <Activity className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-700 font-bold text-lg">No health readings recorded in this category.</p>
          <p className="text-slate-500 text-sm mt-1 mb-4">
            Track blood pressure, blood glucose, oxygen saturation, and body vitals here.
          </p>
          <button
            onClick={() => {
              if (selectedType !== 'all') {
                setType(selectedType as HealthRecordType);
              }
              setShowAddModal(true);
            }}
            className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl cursor-pointer shadow-xs"
          >
            + Log New Reading
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRecords.map((rec) => {
            const normalInfo = NORMAL_METRIC_COUNTS[rec.type] || {
              label: rec.type.replace('_', ' '),
              shortBracket: '',
              requiredDescription: '',
              icon: Activity,
              badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
            };
            const Icon = normalInfo.icon;

            return (
              <div
                key={rec.id}
                className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs hover:border-teal-300 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-1.5">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold uppercase bg-slate-100 text-slate-800">
                        {normalInfo.label}
                      </span>
                      {normalInfo.shortBracket && (
                        <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-teal-50 text-teal-800 border border-teal-200">
                          {normalInfo.shortBracket}
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-slate-400 font-medium">
                      {rec.recordedDate} at {rec.recordedTime}
                    </span>
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <div>
                      <span className="font-display font-black text-3xl sm:text-4xl text-slate-900">
                        {rec.value}
                      </span>
                      <span className="text-sm font-bold text-slate-500 ml-1.5">{rec.unit}</span>
                    </div>

                    <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>

                  {/* Normal Count in Bracket Displayed on the Card */}
                  {normalInfo.shortBracket && (
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="flex items-start space-x-1.5 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-extrabold text-slate-900 block">
                            {normalInfo.shortBracket}
                          </span>
                          <span className="text-[11px] text-slate-500 leading-tight block mt-0.5">
                            {normalInfo.requiredDescription}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {rec.notes && (
                    <p className="text-xs text-slate-600 mt-3 p-2.5 rounded-xl bg-amber-50/50 border border-amber-100 italic">
                      “{rec.notes}”
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Recorded reading</span>
                  <button
                    onClick={() => onDeleteRecord(rec.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition"
                    title="Delete Record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Reading Modal with Normal Count in Brackets for Each Metric */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-display font-bold text-xl text-slate-900">
                  {t('addHealthReading', language)}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Standard required normal counts are shown in brackets for each metric
                </p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 cursor-pointer rounded-lg hover:bg-slate-200"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              {/* Metric Type Selection with Full Normal Counts in Brackets */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Metric Type & Normal Count in Brackets
                </label>
                <select
                  value={type}
                  onChange={(e) => handleTypeChange(e.target.value as HealthRecordType)}
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs sm:text-sm bg-white font-medium focus:ring-2 focus:ring-teal-100 focus:border-teal-600 outline-none"
                >
                  <option value="blood_pressure">
                    Blood Pressure (Normal: 120/80 mmHg | Required: 90/60 – 120/80 mmHg)
                  </option>
                  <option value="blood_sugar">
                    Blood Sugar (Normal: 70–140 mg/dL | Fasting: 70–99 mg/dL, Post-Meal: &lt;140 mg/dL)
                  </option>
                  <option value="oxygen">
                    SpO2 Oxygen (Normal: 95%–100% | Required: ≥95%)
                  </option>
                  <option value="heart_rate">
                    Heart Rate / Health Rate (Normal: 60–100 bpm | Required: 60–100 bpm)
                  </option>
                  <option value="weight">
                    Weight (Normal: 50–80 kg | BMI: 18.5–24.9 | Required healthy weight for any person)
                  </option>
                  <option value="temperature">
                    Temperature (Normal: 97.8°F–99.1°F / 36.5°C–37.3°C | Required: ~98.6°F / 37.0°C)
                  </option>
                  <option value="symptoms">
                    Symptoms / Well-being (Normal: Pain-free, steady balance)
                  </option>
                  <option value="doctor_notes">
                    Doctor Consultation Notes (Routine checkup instructions)
                  </option>
                </select>
              </div>

              {/* Dynamic Highlight Card Explaining the Required Count for Selected Metric */}
              <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-200 text-xs text-teal-900">
                <div className="flex items-start space-x-2">
                  <Info className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-extrabold text-teal-950 block">
                      Required Count for Any Person: {activeMetricInfo.shortBracket}
                    </span>
                    <span className="text-[11px] text-teal-800 leading-relaxed block mt-0.5">
                      {activeMetricInfo.requiredDescription}
                    </span>
                  </div>
                </div>
              </div>

              {/* Value and Unit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Value * (e.g. {activeMetricInfo.example})
                  </label>
                  <input
                    type="text"
                    required
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder={activeMetricInfo.example}
                    className="w-full p-3 rounded-xl border border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-teal-100 focus:border-teal-600 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Unit
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-teal-100 focus:border-teal-600 outline-none"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Notes / Time of Reading (Optional)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Taken before breakfast, feeling energetic..."
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs sm:text-sm focus:ring-2 focus:ring-teal-100 focus:border-teal-600 outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md cursor-pointer"
                >
                  Save Reading
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
