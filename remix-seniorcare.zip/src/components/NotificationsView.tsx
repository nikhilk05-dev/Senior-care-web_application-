import React, { useState, useMemo } from 'react';
import {
  Bell,
  CheckCircle2,
  Trash2,
  Volume2,
  VolumeX,
  Sparkles,
  Pill,
  Calendar,
  AlertTriangle,
  HeartPulse,
  Droplets,
  ShieldAlert,
  Search,
  CheckCheck,
  ArrowRight,
  ExternalLink,
  Flame,
  Radio,
  Clock,
  Filter,
  Info,
} from 'lucide-react';
import { NotificationItem, Language, NotificationType } from '../types';
import { t } from '../i18n';

interface NotificationsViewProps {
  notifications: NotificationItem[];
  language: Language;
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
  onDeleteNotification: (id: string) => void;
  onClearAllNotifications: () => void;
  onNavigateTab: (tab: string) => void;
  onOpenEmergency: () => void;
  onSendTestNotification?: (type: 'medicine' | 'health' | 'appointment' | 'emergency' | 'water') => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  notifications,
  language,
  onMarkRead,
  onMarkAllRead,
  onDeleteNotification,
  onClearAllNotifications,
  onNavigateTab,
  onOpenEmergency,
  onSendTestNotification,
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNotifForDetail, setSelectedNotifForDetail] = useState<NotificationItem | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [chimeEnabled, setChimeEnabled] = useState(true);

  // Play auditory notification chime using Web Audio API
  const playChime = () => {
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2); // G5
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      }
    } catch {
      // Audio fallback
    }
  };

  // Text-to-Speech read aloud for elderly users
  const toggleSpeak = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;
    if (currentlySpeakingId === id) {
      window.speechSynthesis.cancel();
      setCurrentlySpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    if (language === 'hi') utterance.lang = 'hi-IN';
    else if (language === 'mr') utterance.lang = 'mr-IN';
    else utterance.lang = 'en-US';
    utterance.rate = 0.88;
    utterance.onend = () => setCurrentlySpeakingId(null);
    utterance.onerror = () => setCurrentlySpeakingId(null);
    setCurrentlySpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Filtered list
  const filteredNotifications = useMemo(() => {
    return notifications.filter((item) => {
      // Category filter
      if (filterType === 'unread' && item.isRead) return false;
      if (filterType === 'meds' && !item.type.includes('medicine') && !item.type.includes('refill')) return false;
      if (filterType === 'health' && !item.type.includes('health') && !item.type.includes('vital')) return false;
      if (filterType === 'appointment' && !item.type.includes('appointment')) return false;
      if (filterType === 'emergency' && !item.type.includes('emergency')) return false;
      if (filterType === 'water' && !item.type.includes('water')) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return item.title.toLowerCase().includes(q) || item.message.toLowerCase().includes(q);
      }
      return true;
    });
  }, [notifications, filterType, searchQuery]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const getCategoryMeta = (type: NotificationType | string) => {
    if (type.includes('emergency')) {
      return {
        label: 'Emergency SOS',
        icon: ShieldAlert,
        bg: 'bg-rose-50 text-rose-700 border-rose-200',
        badge: 'bg-rose-600 text-white',
        actionLabel: 'Open SOS Card',
        targetTab: 'emergency',
      };
    }
    if (type.includes('medicine') || type.includes('refill')) {
      return {
        label: 'Medication Schedule',
        icon: Pill,
        bg: 'bg-teal-50 text-teal-800 border-teal-200',
        badge: 'bg-teal-700 text-white',
        actionLabel: 'View Medicines',
        targetTab: 'medicines',
      };
    }
    if (type.includes('appointment')) {
      return {
        label: 'Doctor Appointment',
        icon: Calendar,
        bg: 'bg-blue-50 text-blue-700 border-blue-200',
        badge: 'bg-blue-600 text-white',
        actionLabel: 'View Appointments',
        targetTab: 'appointments',
      };
    }
    if (type.includes('water')) {
      return {
        label: 'Hydration Tracker',
        icon: Droplets,
        bg: 'bg-sky-50 text-sky-700 border-sky-200',
        badge: 'bg-sky-600 text-white',
        actionLabel: 'Log Water',
        targetTab: 'waterTracker',
      };
    }
    if (type.includes('health') || type.includes('vital')) {
      return {
        label: 'Health & Vitals',
        icon: HeartPulse,
        bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        badge: 'bg-emerald-600 text-white',
        actionLabel: 'View Health Records',
        targetTab: 'healthRecords',
      };
    }
    return {
      label: 'System Notification',
      icon: Bell,
      bg: 'bg-slate-50 text-slate-700 border-slate-200',
      badge: 'bg-slate-700 text-white',
      actionLabel: 'View Dashboard',
      targetTab: 'dashboard',
    };
  };

  const handleActionClick = (targetTab: string) => {
    if (targetTab === 'emergency') {
      onOpenEmergency();
    } else {
      onNavigateTab(targetTab);
    }
  };

  const formatRelativeTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const diffMs = Date.now() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      if (diffMins < 2) return 'Just now';
      if (diffMins < 60) return `${diffMins} mins ago`;
      if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
      if (diffDays === 1) return 'Yesterday';
      if (diffDays < 7) return `${diffDays} days ago`;
      return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch {
      return 'Recently';
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Banner / Header */}
      <div className="bg-gradient-to-r from-teal-800 via-teal-700 to-teal-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-teal-950/20 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0 shadow-inner">
              <Bell className="w-9 h-9 text-white animate-bounce" />
            </div>
            <div>
              <div className="flex items-center space-x-2.5">
                <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
                  {t('notifications', language)} & Alert Center
                </h1>
                {unreadCount > 0 && (
                  <span className="px-3 py-1 rounded-full bg-rose-500 text-white text-xs font-black uppercase tracking-wider animate-pulse shadow-xs">
                    {unreadCount} Unread
                  </span>
                )}
              </div>
              <p className="text-teal-100 text-sm mt-1 max-w-xl font-medium">
                Live alerts for medication doses, refill alerts, doctor appointments, water tracking, and emergency SOS signals.
              </p>
            </div>
          </div>

          {/* Quick Top Actions */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <button
              onClick={() => {
                setChimeEnabled(!chimeEnabled);
                playChime();
              }}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold border transition flex items-center space-x-1.5 cursor-pointer ${
                chimeEnabled
                  ? 'bg-white/20 hover:bg-white/30 text-white border-white/40'
                  : 'bg-black/20 text-teal-200 border-white/20'
              }`}
              title="Test Sound Chime"
            >
              {chimeEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span>{chimeEnabled ? 'Chime Active (Test)' : 'Chime Off'}</span>
            </button>

            {unreadCount > 0 && (
              <button
                onClick={onMarkAllRead}
                className="px-4 py-2.5 rounded-xl bg-white hover:bg-teal-50 text-teal-900 font-extrabold text-xs shadow-md transition flex items-center space-x-1.5 cursor-pointer"
              >
                <CheckCheck className="w-4 h-4 text-teal-700" />
                <span>Mark All as Read</span>
              </button>
            )}

            {notifications.length > 0 && (
              <button
                onClick={() => setShowClearConfirm(true)}
                className="px-3.5 py-2.5 rounded-xl bg-rose-600/90 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition flex items-center space-x-1.5 cursor-pointer border border-rose-400/40"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear All</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Simulator / Demo Generator Drawer (Helpful for test & evaluation) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center space-x-2 text-slate-700 text-xs font-bold">
          <Sparkles className="w-4 h-4 text-teal-600" />
          <span>Simulate Test Notification:</span>
        </div>
        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <button
            onClick={() => onSendTestNotification?.('medicine')}
            className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold border border-teal-200 cursor-pointer flex items-center space-x-1"
          >
            <Pill className="w-3.5 h-3.5 text-teal-600" />
            <span>+ Dose Reminder</span>
          </button>
          <button
            onClick={() => onSendTestNotification?.('health')}
            className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 cursor-pointer flex items-center space-x-1"
          >
            <HeartPulse className="w-3.5 h-3.5 text-emerald-600" />
            <span>+ Vitals Alert</span>
          </button>
          <button
            onClick={() => onSendTestNotification?.('appointment')}
            className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200 cursor-pointer flex items-center space-x-1"
          >
            <Calendar className="w-3.5 h-3.5 text-blue-600" />
            <span>+ Clinic Visit</span>
          </button>
          <button
            onClick={() => onSendTestNotification?.('water')}
            className="px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-bold border border-sky-200 cursor-pointer flex items-center space-x-1"
          >
            <Droplets className="w-3.5 h-3.5 text-sky-600" />
            <span>+ Water Reminder</span>
          </button>
          <button
            onClick={() => onSendTestNotification?.('emergency')}
            className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-bold border border-rose-200 cursor-pointer flex items-center space-x-1"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>+ SOS Test</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Filter Pills */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-thin">
            {[
              { id: 'all', label: 'All', count: notifications.length },
              { id: 'unread', label: 'Unread', count: unreadCount },
              { id: 'meds', label: 'Medicines', count: notifications.filter((n) => n.type.includes('medicine') || n.type.includes('refill')).length },
              { id: 'health', label: 'Health Vitals', count: notifications.filter((n) => n.type.includes('health') || n.type.includes('vital')).length },
              { id: 'appointment', label: 'Appointments', count: notifications.filter((n) => n.type.includes('appointment')).length },
              { id: 'emergency', label: 'Emergency SOS', count: notifications.filter((n) => n.type.includes('emergency')).length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterType(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center space-x-1.5 ${
                  filterType === tab.id
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                    filterType === tab.id ? 'bg-white/30 text-white' : 'bg-white text-slate-700 border border-slate-200'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notifications..."
              className="w-full pl-9 pr-3 py-2 text-xs font-medium rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-teal-600 focus:ring-1 focus:ring-teal-600 outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-500 hover:text-slate-800 absolute right-2.5 top-1/2 -translate-y-1/2 font-bold"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Notifications List */}
        {filteredNotifications.length === 0 ? (
          <div className="p-12 text-center bg-slate-50/70 rounded-2xl border border-dashed border-slate-200 space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-800 text-base">No notifications match this filter</h3>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              {filterType === 'unread'
                ? 'Great job! You have read all your alerts and reminders.'
                : 'No alerts found in this category. You are all up to date.'}
            </p>
            {filterType !== 'all' && (
              <button
                onClick={() => setFilterType('all')}
                className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
              >
                Show all notifications
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredNotifications.map((n) => {
              const meta = getCategoryMeta(n.type);
              const Icon = meta.icon;
              const isUrgent = n.type.includes('emergency') || n.type.includes('refill');

              return (
                <div
                  key={n.id}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                    !n.isRead
                      ? 'bg-teal-50/40 border-teal-200 shadow-xs ring-1 ring-teal-100'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start space-x-3.5 flex-1">
                    {/* Category Icon */}
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${meta.bg}`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="space-y-1 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${meta.badge}`}>
                          {meta.label}
                        </span>
                        {!n.isRead && (
                          <span className="w-2 h-2 rounded-full bg-teal-600 shrink-0 animate-ping" />
                        )}
                        {isUrgent && (
                          <span className="text-[10px] font-black uppercase text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full border border-rose-200">
                            Action Recommended
                          </span>
                        )}
                        <span className="text-xs text-slate-500 font-semibold flex items-center space-x-1">
                          <Clock className="w-3 h-3 text-slate-400 inline" />
                          <span>{formatRelativeTime(n.createdAt)}</span>
                        </span>
                      </div>

                      <h3 className="font-extrabold text-slate-900 text-base leading-snug">{n.title}</h3>
                      <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">{n.message}</p>
                    </div>
                  </div>

                  {/* Right Side Actions */}
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    {/* Read Aloud */}
                    <button
                      onClick={() => toggleSpeak(n.id, `${n.title}. ${n.message}`)}
                      className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200 cursor-pointer"
                      title="Read Aloud to me"
                    >
                      {currentlySpeakingId === n.id ? (
                        <VolumeX className="w-4 h-4 text-rose-600 animate-pulse" />
                      ) : (
                        <Volume2 className="w-4 h-4 text-slate-600" />
                      )}
                    </button>

                    {/* Mark Read/Unread Toggle */}
                    <button
                      onClick={() => onMarkRead(n.id)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center space-x-1 ${
                        n.isRead
                          ? 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          : 'bg-teal-50 text-teal-800 border-teal-300 hover:bg-teal-100 font-extrabold'
                      }`}
                      title={n.isRead ? 'Mark as Unread' : 'Mark as Read'}
                    >
                      <CheckCircle2 className={`w-3.5 h-3.5 ${n.isRead ? 'text-slate-400' : 'text-teal-700'}`} />
                      <span>{n.isRead ? 'Read' : 'Mark Read'}</span>
                    </button>

                    {/* Primary Jump Action */}
                    <button
                      onClick={() => handleActionClick(meta.targetTab)}
                      className="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white font-bold text-xs flex items-center space-x-1 shadow-xs cursor-pointer"
                    >
                      <span>{meta.actionLabel}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete Individual */}
                    <button
                      onClick={() => onDeleteNotification(n.id)}
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 cursor-pointer transition"
                      title="Delete this notification"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Safety Confirmation Modal: Clear All Notifications */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 border border-slate-200 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="font-display font-black text-xl text-slate-900">
                Clear All Notifications?
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
                Are you sure you want to remove all {notifications.length} notifications? This action cannot be undone.
              </p>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearAllNotifications();
                  setShowClearConfirm(false);
                }}
                className="flex-1 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-md cursor-pointer"
              >
                Yes, Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
