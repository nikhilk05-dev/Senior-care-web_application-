import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  Pill,
  Stethoscope,
  Heart,
  Droplets,
  AlertCircle,
  CheckCircle2,
  CalendarCheck,
  Sparkles,
  MapPin,
  X,
  FileText,
  Filter,
} from 'lucide-react';
import { Medicine, Appointment, Language, User } from '../types';
import { IndianTimeClock } from './IndianTimeClock';

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time?: string;
  type: 'medicine' | 'appointment' | 'holiday' | 'health_check' | 'personal';
  description?: string;
  status?: 'pending' | 'completed' | 'cancelled';
  location?: string;
  badge?: string;
}

interface CalendarViewProps {
  user: User;
  medicines: Medicine[];
  appointments: Appointment[];
  language: Language;
  onOpenBookAppointment?: () => void;
  onTakeDose?: (medId: string) => void;
}

// Comprehensive Indian festivals, national observances, and health awareness days
const INDIAN_EVENTS_DATABASE: Array<{
  date: string; // MM-DD
  titleEn: string;
  titleHi: string;
  titleMr: string;
  type: 'holiday';
  badge: string;
  desc: string;
}> = [
  { date: '01-15', titleEn: 'Makar Sankranti / Pongal', titleHi: 'मकर संक्रांति / पोंगल', titleMr: 'मकर संक्रांत / पोंगल', type: 'holiday', badge: '🪁', desc: 'Harvest festival celebrated across India.' },
  { date: '01-26', titleEn: 'Republic Day (National Holiday)', titleHi: 'गणतंत्र दिवस (राष्ट्रीय अवकाश)', titleMr: 'प्रजासत्ताक दिन (राष्ट्रीय सुट्टी)', type: 'holiday', badge: '🇮🇳', desc: 'Constitution of India came into effect.' },
  { date: '02-15', titleEn: 'Maha Shivratri', titleHi: 'महाशिवरात्रि', titleMr: 'महाशिवरात्री', type: 'holiday', badge: '🕉️', desc: 'Auspicious day dedicated to wellness and spiritual meditation.' },
  { date: '03-04', titleEn: 'Holi (Festival of Colors)', titleHi: 'होली (रंगोत्सव)', titleMr: 'धुलिवंदन / होळी', type: 'holiday', badge: '🎨', desc: 'Celebration of spring, joy, and family harmony.' },
  { date: '03-19', titleEn: 'Gudi Padwa / Chaitra Navratri', titleHi: 'गुड़ी पड़वा / चैत्र नवरात्रि', titleMr: 'गुढीपाडवा (मराठी नववर्ष)', type: 'holiday', badge: '🚩', desc: 'Traditional New Year celebration and auspicious beginning.' },
  { date: '04-07', titleEn: 'World Health Day', titleHi: 'विश्व स्वास्थ्य दिवस', titleMr: 'जागतिक आरोग्य दिन', type: 'holiday', badge: '🩺', desc: 'Global annual health awareness and checkup milestone.' },
  { date: '04-14', titleEn: 'Dr. B.R. Ambedkar Jayanti', titleHi: 'डॉ. बी.आर. आंबेडकर जयंती', titleMr: 'डॉ. बाबासाहेब आंबेडकर जयंती', type: 'holiday', badge: '📜', desc: 'Commemoration of the Father of the Indian Constitution.' },
  { date: '05-01', titleEn: 'Maharashtra Day / Labour Day', titleHi: 'महाराष्ट्र दिवस / मजदूर दिवस', titleMr: 'महाराष्ट्र दिन / कामगार दिन', type: 'holiday', badge: '🌟', desc: 'Formation of the State of Maharashtra.' },
  { date: '06-21', titleEn: 'International Day of Yoga', titleHi: 'अंतर्राष्ट्रीय योग दिवस', titleMr: 'आंतरराष्ट्रीय योग दिन', type: 'holiday', badge: '🧘', desc: 'Gentle pranayama, meditation, and healthy stretching.' },
  { date: '07-01', titleEn: "National Doctors' Day", titleHi: 'राष्ट्रीय चिकित्सक दिवस', titleMr: 'राष्ट्रीय डॉक्टर दिन', type: 'holiday', badge: '👨‍⚕️', desc: 'Honoring doctors and healthcare workers across India.' },
  { date: '08-15', titleEn: 'Independence Day (National Holiday)', titleHi: 'स्वतंत्रता दिवस (राष्ट्रीय अवकाश)', titleMr: 'स्वातंत्र्य दिन (राष्ट्रीय सुट्टी)', type: 'holiday', badge: '🇮🇳', desc: 'Indian Independence celebrations.' },
  { date: '09-04', titleEn: 'Krishna Janmashtami', titleHi: 'श्री कृष्ण जन्माष्टमी', titleMr: 'गोकुळाष्टमी / दहीहंडी', type: 'holiday', badge: '🦚', desc: 'Celebration of the birth of Lord Krishna.' },
  { date: '09-15', titleEn: 'Ganesh Chaturthi', titleHi: 'गणेश चतुर्थी', titleMr: 'गणेशोत्सव / गणेश चतुर्थी', type: 'holiday', badge: '🐘', desc: 'Arrival of Lord Ganesha, bringer of wisdom and health.' },
  { date: '09-29', titleEn: 'World Heart Day', titleHi: 'विश्व हृदय दिवस', titleMr: 'जागतिक हृदय दिन', type: 'holiday', badge: '❤️', desc: 'Focus on cardiovascular wellness, BP monitoring, and daily walks.' },
  { date: '10-01', titleEn: 'International Day of Older Persons', titleHi: 'अंतर्राष्ट्रीय वृद्धजन दिवस', titleMr: 'आंतरराष्ट्रीय ज्येष्ठ नागरिक दिन', type: 'holiday', badge: '👴', desc: 'Celebrating senior citizens with warmth, dignity, and care.' },
  { date: '10-02', titleEn: 'Mahatma Gandhi Jayanti', titleHi: 'महात्मा गांधी जयंती', titleMr: 'महात्मा गांधी जयंती', type: 'holiday', badge: '🕊️', desc: 'National tribute to the Father of the Nation.' },
  { date: '10-20', titleEn: 'Dussehra / Vijayadashami', titleHi: 'दशहरा / विजयादशमी', titleMr: 'दसरा / विजयादशमी', type: 'holiday', badge: '🏹', desc: 'Triumph of righteousness and auspicious beginnings.' },
  { date: '11-08', titleEn: 'Diwali (Deepavali)', titleHi: 'दीपावली (रोशनी का पर्व)', titleMr: 'दिवाळी (दीपावली)', type: 'holiday', badge: '🪔', desc: 'Festival of lights, prosperity, and family togetherness.' },
  { date: '11-10', titleEn: 'Bhai Dooj / Bhau Beej', titleHi: 'भाई दूज', titleMr: 'भाऊबीज', type: 'holiday', badge: '🌸', desc: 'Celebrating loving family bonds.' },
  { date: '11-14', titleEn: 'World Diabetes Day', titleHi: 'विश्व मधुमेह दिवस', titleMr: 'जागतिक मधुमेह दिन', type: 'holiday', badge: '🩸', desc: 'Focus on blood sugar management, nutrition, and walking.' },
  { date: '11-24', titleEn: 'Guru Nanak Jayanti', titleHi: 'गुरु नानक जयंती', titleMr: 'गुरु नानक जयंती', type: 'holiday', badge: '🪯', desc: 'Celebration of truth, selfless service, and peace.' },
  { date: '12-25', titleEn: 'Christmas Day', titleHi: 'क्रिसमस (बड़ा दिन)', titleMr: 'नाताळ (ख्रिसमस)', type: 'holiday', badge: '🎄', desc: 'Joyous holiday celebration of love and peace.' },
];

export const CalendarView: React.FC<CalendarViewProps> = ({
  user,
  medicines,
  appointments,
  language,
  onOpenBookAppointment,
  onTakeDose,
}) => {
  // Current Indian Standard Time Reference
  const istNow = useMemo(() => {
    return new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  }, []);

  const [currentDate, setCurrentDate] = useState<Date>(istNow);
  const [selectedDate, setSelectedDate] = useState<Date>(istNow);
  const [filterType, setFilterType] = useState<'all' | 'medicine' | 'appointment' | 'holiday' | 'health_check'>('all');
  const [showAddEventModal, setShowAddEventModal] = useState(false);

  // Custom User Reminders Added via Calendar
  const [customEvents, setCustomEvents] = useState<CalendarEvent[]>([
    {
      id: 'custom-1',
      title: 'Morning Yoga & Pranayama',
      date: `${istNow.getFullYear()}-${String(istNow.getMonth() + 1).padStart(2, '0')}-${String(istNow.getDate()).padStart(2, '0')}`,
      time: '07:00 AM',
      type: 'health_check',
      description: 'Gentle 20-minute stretching and deep breathing for lung capacity.',
      status: 'pending',
    },
    {
      id: 'custom-2',
      title: 'Fasting Blood Sugar Test',
      date: `${istNow.getFullYear()}-${String(istNow.getMonth() + 1).padStart(2, '0')}-${String(istNow.getDate()).padStart(2, '0')}`,
      time: '08:00 AM',
      type: 'health_check',
      description: 'Record morning fasting glucose before taking breakfast.',
      status: 'pending',
    },
  ]);

  // Form state for adding new calendar reminder
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventTime, setNewEventTime] = useState('09:00');
  const [newEventType, setNewEventType] = useState<'medicine' | 'appointment' | 'health_check' | 'personal'>('health_check');
  const [newEventDesc, setNewEventDesc] = useState('');

  // Calendar calculations
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 is Sunday
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  // Month navigation
  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const jumpToToday = () => {
    const today = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
    setCurrentDate(today);
    setSelectedDate(today);
  };

  // Localized Month & Day Names
  const monthNames = {
    en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    hi: ['जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'],
    mr: ['जानेवारी', 'फेब्रुवारी', 'मार्च', 'एप्रिल', 'मे', 'जून', 'जुलै', 'ऑगस्ट', 'सप्टेंबर', 'ऑक्टोबर', 'नोव्हेंबर', 'डिसेंबर'],
  };

  const weekDayNames = {
    en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    hi: ['रवि', 'सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि'],
    mr: ['रवि', 'सोम', 'मंगळ', 'बुध', 'गुरु', 'शुक्र', 'शनि'],
  };

  const fullDayNames = {
    en: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    hi: ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'],
    mr: ['रविवार', 'सोमवार', 'मंगळवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'],
  };

  // Convert date to YYYY-MM-DD string
  const formatDateKey = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  // Gather events for any date
  const getEventsForDate = (dateObj: Date): CalendarEvent[] => {
    const dateKey = formatDateKey(dateObj);
    const mmdd = `${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}`;
    const events: CalendarEvent[] = [];

    // 1. Indian Holidays / Observances
    INDIAN_EVENTS_DATABASE.forEach((h) => {
      if (h.date === mmdd) {
        events.push({
          id: `hol-${h.date}`,
          title: language === 'hi' ? h.titleHi : language === 'mr' ? h.titleMr : h.titleEn,
          date: dateKey,
          type: 'holiday',
          description: h.desc,
          badge: h.badge,
        });
      }
    });

    // 2. Doctor Appointments
    appointments.forEach((appt) => {
      if (appt.appointmentDate === dateKey) {
        events.push({
          id: `appt-${appt.id}`,
          title: `Dr. ${appt.doctorName}`,
          date: dateKey,
          time: appt.appointmentTime,
          type: 'appointment',
          description: `${appt.purpose || 'Medical Consultation'} at ${appt.clinic || 'Clinic'}`,
          status: appt.status === 'completed' ? 'completed' : 'pending',
          location: appt.clinic,
        });
      }
    });

    // 3. Medicines scheduled for today / every day
    medicines.forEach((med) => {
      (med.schedules || []).forEach((sched) => {
        events.push({
          id: `med-${med.id}-${sched.id}`,
          title: `${med.name} (${med.dosage})`,
          date: dateKey,
          time: sched.time,
          type: 'medicine',
          description: `${sched.label} • ${med.timing}`,
          status: sched.status === 'taken' ? 'completed' : 'pending',
          badge: '💊',
        });
      });
    });

    // 4. Custom user events
    customEvents.forEach((ev) => {
      if (ev.date === dateKey) {
        events.push(ev);
      }
    });

    return events;
  };

  // Events for the currently selected day
  const selectedDateEvents = useMemo(() => {
    const raw = getEventsForDate(selectedDate);
    if (filterType === 'all') return raw;
    return raw.filter((e) => e.type === filterType);
  }, [selectedDate, medicines, appointments, customEvents, filterType, language]);

  const handleAddCustomEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) return;

    const newEv: CalendarEvent = {
      id: `custom-${Date.now()}`,
      title: newEventTitle.trim(),
      date: formatDateKey(selectedDate),
      time: newEventTime,
      type: newEventType,
      description: newEventDesc.trim(),
      status: 'pending',
    };

    setCustomEvents((prev) => [...prev, newEv]);
    setNewEventTitle('');
    setNewEventDesc('');
    setShowAddEventModal(false);
  };

  const isToday = (d: Date) => {
    return (
      d.getDate() === istNow.getDate() &&
      d.getMonth() === istNow.getMonth() &&
      d.getFullYear() === istNow.getFullYear()
    );
  };

  const isSelected = (d: Date) => {
    return (
      d.getDate() === selectedDate.getDate() &&
      d.getMonth() === selectedDate.getMonth() &&
      d.getFullYear() === selectedDate.getFullYear()
    );
  };

  // Generate the 35 or 42 grid cells
  const calendarCells = useMemo(() => {
    const cells: Array<{ date: Date; isCurrentMonth: boolean }> = [];

    // Previous month filler days
    for (let i = firstDayOfMonth - 1; i >= 0; i--) {
      cells.push({
        date: new Date(year, month - 1, daysInPrevMonth - i),
        isCurrentMonth: false,
      });
    }

    // Current month days
    for (let i = 1; i <= daysInMonth; i++) {
      cells.push({
        date: new Date(year, month, i),
        isCurrentMonth: true,
      });
    }

    // Next month filler days to complete grid to multiple of 7
    const remaining = 42 - cells.length;
    if (remaining < 7) {
      for (let i = 1; i <= remaining; i++) {
        cells.push({
          date: new Date(year, month + 1, i),
          isCurrentMonth: false,
        });
      }
    } else if (cells.length < 35) {
      const fill35 = 35 - cells.length;
      for (let i = 1; i <= fill35; i++) {
        cells.push({
          date: new Date(year, month + 1, i),
          isCurrentMonth: false,
        });
      }
    }

    return cells;
  }, [year, month, firstDayOfMonth, daysInMonth, daysInPrevMonth]);

  const selectedDateFormatted = selectedDate.toLocaleDateString(
    language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-IN',
    {
      timeZone: 'Asia/Kolkata',
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }
  );

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* Top Banner: Indian Standard Time & Calendar Title */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-11 h-11 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center shadow-xs">
              <CalendarIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-slate-900 tracking-tight">
                  {language === 'hi'
                    ? 'वरिष्ठ स्वास्थ्य व औषध कैलेंडर'
                    : language === 'mr'
                    ? 'ज्येष्ठ नागरिक आरोग्य व औषध दिनदर्शिका'
                    : 'Senior Health & Care Calendar'}
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 border border-orange-200 text-xs font-bold font-mono">
                  IST 🇮🇳
                </span>
              </div>
              <p className="text-slate-600 text-xs sm:text-sm mt-0.5">
                Track daily medicines, doctor appointments, blood pressure tests, and Indian festivals in Indian Standard Time.
              </p>
            </div>
          </div>
        </div>

        {/* Live Indian Time Banner in Header */}
        <div className="lg:w-96">
          <IndianTimeClock language={language} compact={false} />
        </div>
      </div>

      {/* Main Calendar + Day Details Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Calendar Grid (7 cols) */}
        <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200 shadow-sm p-4 sm:p-6 space-y-4">
          {/* Calendar Navigation & Month Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center space-x-2">
              <button
                onClick={prevMonth}
                className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 transition cursor-pointer"
                title="Previous Month"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <h2 className="font-display font-extrabold text-xl sm:text-2xl text-slate-900 px-2 min-w-[180px]">
                {monthNames[language][month]} {year}
              </h2>

              <button
                onClick={nextMonth}
                className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 transition cursor-pointer"
                title="Next Month"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={jumpToToday}
                className="px-3.5 py-2 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-800 border border-orange-200 text-xs font-bold flex items-center space-x-1.5 transition cursor-pointer shadow-2xs"
              >
                <span>🇮🇳</span>
                <span>
                  {language === 'hi' ? 'आज (Today)' : language === 'mr' ? 'आज (Today)' : 'Today (IST)'}
                </span>
              </button>

              {onOpenBookAppointment && (
                <button
                  onClick={onOpenBookAppointment}
                  className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center space-x-1.5 transition cursor-pointer shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>
                    {language === 'hi' ? '+ अपॉइंटमेंट' : language === 'mr' ? '+ डॉक्टर भेट' : '+ Visit'}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Weekday Headers (Sunday to Saturday) */}
          <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs uppercase tracking-wider text-slate-500 py-1">
            {weekDayNames[language].map((dayName, idx) => (
              <div
                key={dayName}
                className={`py-2 rounded-lg ${idx === 0 ? 'text-rose-600 bg-rose-50/50' : ''}`}
              >
                {dayName}
              </div>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
            {calendarCells.map((cell, idx) => {
              const dayNum = cell.date.getDate();
              const dateKey = formatDateKey(cell.date);
              const cellEvents = getEventsForDate(cell.date);
              const hasHoliday = cellEvents.find((e) => e.type === 'holiday');
              const hasAppt = cellEvents.find((e) => e.type === 'appointment');
              const hasMeds = cellEvents.filter((e) => e.type === 'medicine');
              const cellIsToday = isToday(cell.date);
              const cellIsSelected = isSelected(cell.date);

              return (
                <button
                  key={idx}
                  onClick={() => setSelectedDate(cell.date)}
                  className={`min-h-[72px] sm:min-h-[88px] p-1.5 sm:p-2 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer relative group ${
                    cellIsSelected
                      ? 'border-teal-600 bg-teal-50/70 ring-2 ring-teal-500/30 shadow-md'
                      : cellIsToday
                      ? 'border-orange-400 bg-orange-50/40 shadow-xs ring-1 ring-orange-400/40'
                      : cell.isCurrentMonth
                      ? 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                      : 'border-slate-100 bg-slate-50/50 text-slate-300'
                  }`}
                >
                  {/* Date number and today tag */}
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`text-sm sm:text-base font-extrabold ${
                        cellIsSelected
                          ? 'text-teal-900 font-black'
                          : cellIsToday
                          ? 'text-orange-900 bg-orange-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs'
                          : cell.isCurrentMonth
                          ? 'text-slate-800'
                          : 'text-slate-400'
                      }`}
                    >
                      {dayNum}
                    </span>

                    {hasHoliday && (
                      <span className="text-xs" title={hasHoliday.title}>
                        {hasHoliday.badge || '🪔'}
                      </span>
                    )}
                  </div>

                  {/* Badges / Dots preview */}
                  <div className="w-full space-y-1 mt-1">
                    {hasHoliday && (
                      <div className="text-[10px] font-bold text-orange-800 truncate leading-tight bg-orange-100/80 px-1 py-0.5 rounded-sm">
                        {hasHoliday.title}
                      </div>
                    )}

                    {hasAppt && (
                      <div className="text-[10px] font-bold text-emerald-800 truncate leading-tight bg-emerald-100/90 px-1 py-0.5 rounded-sm flex items-center space-x-0.5">
                        <Stethoscope className="w-2.5 h-2.5 shrink-0" />
                        <span className="truncate">{hasAppt.title}</span>
                      </div>
                    )}

                    {hasMeds.length > 0 && !hasAppt && !hasHoliday && (
                      <div className="flex items-center space-x-1 text-[10px] text-teal-700 font-semibold truncate">
                        <Pill className="w-2.5 h-2.5 shrink-0 text-teal-600" />
                        <span>{hasMeds.length} doses</span>
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Calendar Legend */}
          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
            <div className="flex items-center space-x-3 flex-wrap gap-y-1">
              <span className="flex items-center space-x-1 font-semibold">
                <span className="w-3 h-3 rounded-full bg-orange-500 inline-block" />
                <span>Today (IST)</span>
              </span>
              <span className="flex items-center space-x-1 font-semibold">
                <span>🪔</span>
                <span>Indian Festivals</span>
              </span>
              <span className="flex items-center space-x-1 font-semibold">
                <span className="w-3 h-3 rounded-md bg-emerald-100 border border-emerald-300 inline-block" />
                <span>Doctor Visits</span>
              </span>
              <span className="flex items-center space-x-1 font-semibold">
                <span className="w-3 h-3 rounded-md bg-teal-100 border border-teal-300 inline-block" />
                <span>Medications</span>
              </span>
            </div>

            <span className="text-[11px] text-slate-400 font-mono">
              Calibrated to Asia/Kolkata (UTC +05:30)
            </span>
          </div>
        </div>

        {/* Right Column: Day Detail Itinerary & Custom Events (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4">
          {/* Header for Selected Day */}
          <div className="pb-3 border-b border-slate-100 flex items-start justify-between">
            <div>
              <div className="flex items-center space-x-2">
                <CalendarCheck className="w-5 h-5 text-teal-600" />
                <h3 className="font-display font-extrabold text-lg text-slate-900 leading-tight">
                  {isToday(selectedDate) ? 'Today’s Schedule' : 'Day Schedule'}
                </h3>
              </div>
              <p className="text-xs font-semibold text-teal-800 mt-1">
                {selectedDateFormatted}
              </p>
            </div>

            <button
              onClick={() => setShowAddEventModal(true)}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center space-x-1 shadow-2xs transition cursor-pointer"
              title="Add New Reminder for This Day"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Event</span>
            </button>
          </div>

          {/* Quick Filter */}
          <div className="flex space-x-1 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setFilterType('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer whitespace-nowrap ${
                filterType === 'all'
                  ? 'bg-slate-800 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All ({getEventsForDate(selectedDate).length})
            </button>
            <button
              onClick={() => setFilterType('medicine')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer whitespace-nowrap ${
                filterType === 'medicine'
                  ? 'bg-teal-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              💊 Pills
            </button>
            <button
              onClick={() => setFilterType('appointment')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer whitespace-nowrap ${
                filterType === 'appointment'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🩺 Clinic
            </button>
            <button
              onClick={() => setFilterType('holiday')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer whitespace-nowrap ${
                filterType === 'holiday'
                  ? 'bg-orange-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🪔 Festivals
            </button>
          </div>

          {/* Events List for Day */}
          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
            {selectedDateEvents.length === 0 ? (
              <div className="py-10 text-center text-slate-400 space-y-2">
                <CalendarIcon className="w-10 h-10 mx-auto text-slate-300 stroke-1" />
                <p className="text-sm font-semibold text-slate-600">No events for this date</p>
                <p className="text-xs text-slate-400">
                  Tap "+ Add Event" above to add a reminder, medication, or wellness routine.
                </p>
              </div>
            ) : (
              selectedDateEvents.map((event) => {
                const isMed = event.type === 'medicine';
                const isAppt = event.type === 'appointment';
                const isHol = event.type === 'holiday';

                return (
                  <div
                    key={event.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isHol
                        ? 'bg-orange-50/70 border-orange-200 text-orange-950'
                        : isAppt
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                        : isMed
                        ? 'bg-teal-50/70 border-teal-200 text-teal-950'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start space-x-2">
                        <span className="text-lg mt-0.5">
                          {isHol ? event.badge || '🪔' : isAppt ? '🩺' : isMed ? '💊' : '📋'}
                        </span>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900 leading-snug">
                            {event.title}
                          </h4>
                          {event.time && (
                            <div className="flex items-center space-x-1 text-xs text-slate-600 mt-0.5 font-semibold">
                              <Clock className="w-3 h-3 text-slate-500" />
                              <span>{event.time} IST</span>
                            </div>
                          )}
                          {event.description && (
                            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                              {event.description}
                            </p>
                          )}
                          {event.location && (
                            <div className="flex items-center space-x-1 text-[11px] text-slate-500 mt-1">
                              <MapPin className="w-3 h-3 text-emerald-600" />
                              <span>{event.location}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {event.status === 'completed' && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold shrink-0">
                          Done
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Add Custom Calendar Event Modal */}
      {showAddEventModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2 text-teal-700">
                <CalendarIcon className="w-5 h-5" />
                <h3 className="font-bold text-lg text-slate-900">Add Calendar Reminder</h3>
              </div>
              <button
                onClick={() => setShowAddEventModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold px-2 py-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Date: <strong className="text-slate-800">{selectedDateFormatted}</strong> (Indian Standard Time)
            </p>

            <form onSubmit={handleAddCustomEvent} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Event / Task Title *
                </label>
                <input
                  type="text"
                  required
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  placeholder="e.g. Blood pressure reading, Morning walk, Temple visit"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm focus:border-teal-600 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Time (IST)
                  </label>
                  <input
                    type="time"
                    value={newEventTime}
                    onChange={(e) => setNewEventTime(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm focus:border-teal-600 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Category
                  </label>
                  <select
                    value={newEventType}
                    onChange={(e) => setNewEventType(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm focus:border-teal-600 outline-none bg-white"
                  >
                    <option value="health_check">Health Check / Test</option>
                    <option value="medicine">Medication Dose</option>
                    <option value="appointment">Doctor / Clinic Visit</option>
                    <option value="personal">Personal / Family Routine</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Notes / Instructions
                </label>
                <textarea
                  rows={2}
                  value={newEventDesc}
                  onChange={(e) => setNewEventDesc(e.target.value)}
                  placeholder="e.g. Remember to drink 1 glass water beforehand"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm focus:border-teal-600 outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddEventModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Save to Calendar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
