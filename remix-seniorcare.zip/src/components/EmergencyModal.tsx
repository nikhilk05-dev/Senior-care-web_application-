import React, { useState, useEffect } from 'react';
import {
  PhoneCall,
  AlertTriangle,
  X,
  ShieldAlert,
  Heart,
  Plus,
  Edit2,
  Check,
  MapPin,
  CheckCircle2,
  ArrowLeft,
  Vibrate,
  Trash2,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  Phone,
  HelpCircle,
  FileText,
} from 'lucide-react';
import { EmergencyContact, EmergencyInformation, Language } from '../types';
import { t } from '../i18n';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: EmergencyContact[];
  emergencyInfo: EmergencyInformation | null;
  language: Language;
  onUpdateInfo: (info: Partial<EmergencyInformation>) => void;
  onAddContact: (contact: Partial<EmergencyContact>) => void;
  onEditContact?: (id: string, contact: Partial<EmergencyContact>) => void;
  onDeleteContact?: (id: string) => void;
  onClearAllContacts?: () => void;
  onClearEmergencyInfo?: () => void;
  onResetDefaultContacts?: () => void;
  onTriggerDistressAlert?: (details?: { location?: string; timestamp?: string }) => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  contacts,
  emergencyInfo,
  language,
  onUpdateInfo,
  onAddContact,
  onEditContact,
  onDeleteContact,
  onClearAllContacts,
  onClearEmergencyInfo,
  onResetDefaultContacts,
  onTriggerDistressAlert,
}) => {
  const [selectedCallContact, setSelectedCallContact] = useState<EmergencyContact | null>(null);
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);
  const [contactToDelete, setContactToDelete] = useState<EmergencyContact | null>(null);
  const [showClearAllContactsConfirm, setShowClearAllContactsConfirm] = useState(false);
  const [showClearInfoConfirm, setShowClearInfoConfirm] = useState(false);
  const [sirenPlaying, setSirenPlaying] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Two-step SOS confirmation flow state: 'idle' -> 'verifying' -> 'triggered'
  const [sosFlowState, setSosFlowState] = useState<'idle' | 'verifying' | 'triggered'>('idle');
  const [alertTriggeredTime, setAlertTriggeredTime] = useState<string>('');
  const [hapticActive, setHapticActive] = useState(false);

  // Form states for editing emergency medical card
  const [bloodGroup, setBloodGroup] = useState(emergencyInfo?.bloodGroup || 'B+');
  const [allergiesStr, setAllergiesStr] = useState(emergencyInfo?.allergies?.join(', ') || '');
  const [conditionsStr, setConditionsStr] = useState(emergencyInfo?.medicalConditions?.join(', ') || '');
  const [primaryDoctor, setPrimaryDoctor] = useState(emergencyInfo?.primaryDoctor || '');
  const [preferredHospital, setPreferredHospital] = useState(emergencyInfo?.preferredHospital || '');
  const [insuranceNumber, setInsuranceNumber] = useState(emergencyInfo?.insuranceNumber || '');
  const [emergencyNotes, setEmergencyNotes] = useState(emergencyInfo?.emergencyNotes || '');

  // Form state for adding contact
  const [newContactName, setNewContactName] = useState('');
  const [newContactRel, setNewContactRel] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactNotes, setNewContactNotes] = useState('');

  // Form state for editing contact
  const [editName, setEditName] = useState('');
  const [editRel, setEditRel] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editNotes, setEditNotes] = useState('');

  // Haptic feedback & physical device vibration handler
  const triggerHaptic = (pattern: number | number[] = [150, 75, 150]) => {
    try {
      if (typeof window !== 'undefined' && 'navigator' in window && typeof navigator.vibrate === 'function') {
        navigator.vibrate(pattern);
      }
    } catch {
      // Gracefully handle devices without vibration API
    }

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      }
    } catch {
      // AudioContext fallback
    }
  };

  // Audible Siren Chime test for device speaker check
  const playSirenTest = () => {
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(650, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(950, ctx.currentTime + 0.3);
        osc.frequency.linearRampToValueAtTime(650, ctx.currentTime + 0.6);
        osc.frequency.linearRampToValueAtTime(950, ctx.currentTime + 0.9);
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 1.2);
        setSirenPlaying(true);
        setTimeout(() => setSirenPlaying(false), 1200);
      }
    } catch {
      // Audio fallback
    }
  };

  // Triggered when senior taps the primary SOS button
  const handleSosInitialPress = () => {
    triggerHaptic([150, 75, 150]);
    setHapticActive(true);
    setTimeout(() => {
      setHapticActive(false);
      setSosFlowState('verifying');
    }, 160);
  };

  useEffect(() => {
    if (!isOpen) {
      setSosFlowState('idle');
      setSelectedCallContact(null);
      setIsEditingInfo(false);
      setShowAddContact(false);
      setEditingContact(null);
      setContactToDelete(null);
      setShowClearAllContactsConfirm(false);
      setShowClearInfoConfirm(false);
      setStatusMessage(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (emergencyInfo) {
      setBloodGroup(emergencyInfo.bloodGroup || 'B+');
      setAllergiesStr(emergencyInfo.allergies?.join(', ') || '');
      setConditionsStr(emergencyInfo.medicalConditions?.join(', ') || '');
      setPrimaryDoctor(emergencyInfo.primaryDoctor || '');
      setPreferredHospital(emergencyInfo.preferredHospital || '');
      setInsuranceNumber(emergencyInfo.insuranceNumber || '');
      setEmergencyNotes(emergencyInfo.emergencyNotes || '');
    }
  }, [emergencyInfo]);

  if (!isOpen) return null;

  const showTempStatus = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleTriggerDistress = () => {
    triggerHaptic([200, 100, 200, 100, 300]);
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setAlertTriggeredTime(time);
    setSosFlowState('triggered');
    if (onTriggerDistressAlert) {
      onTriggerDistressAlert({
        location: '18.5204° N, 73.8567° E (Shivajinagar, Pune)',
        timestamp: new Date().toISOString(),
      });
    }
  };

  const handleSaveInfo = () => {
    onUpdateInfo({
      bloodGroup,
      allergies: allergiesStr.split(',').map((s) => s.trim()).filter(Boolean),
      medicalConditions: conditionsStr.split(',').map((s) => s.trim()).filter(Boolean),
      primaryDoctor,
      preferredHospital,
      insuranceNumber,
      emergencyNotes,
    });
    setIsEditingInfo(false);
    showTempStatus('Medical card updated successfully');
  };

  const handleAddNewContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim() || !newContactPhone.trim()) return;
    onAddContact({
      name: newContactName.trim(),
      relationship: newContactRel.trim() || 'Family',
      phone: newContactPhone.trim(),
      priority: contacts.length + 1,
      notes: newContactNotes.trim() || undefined,
    });
    setNewContactName('');
    setNewContactRel('');
    setNewContactPhone('');
    setNewContactNotes('');
    setShowAddContact(false);
    showTempStatus('New contact added');
  };

  const startEditContact = (contact: EmergencyContact) => {
    setEditingContact(contact);
    setEditName(contact.name);
    setEditRel(contact.relationship);
    setEditPhone(contact.phone);
    setEditNotes(contact.notes || '');
  };

  const handleSaveEditedContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingContact || !editName.trim() || !editPhone.trim()) return;
    if (onEditContact) {
      onEditContact(editingContact.id, {
        name: editName.trim(),
        relationship: editRel.trim() || 'Family',
        phone: editPhone.trim(),
        notes: editNotes.trim() || undefined,
      });
    }
    setEditingContact(null);
    showTempStatus('Contact details updated');
  };

  const confirmDeleteIndividualContact = () => {
    if (!contactToDelete) return;
    if (onDeleteContact) {
      onDeleteContact(contactToDelete.id);
      showTempStatus(`Removed contact: ${contactToDelete.name}`);
    }
    setContactToDelete(null);
  };

  const confirmClearAllContacts = () => {
    if (onClearAllContacts) {
      onClearAllContacts();
      showTempStatus('All emergency contacts removed');
    }
    setShowClearAllContactsConfirm(false);
  };

  const confirmClearMedicalInfo = () => {
    if (onClearEmergencyInfo) {
      onClearEmergencyInfo();
    }
    setBloodGroup('');
    setAllergiesStr('');
    setConditionsStr('');
    setPrimaryDoctor('');
    setPreferredHospital('');
    setInsuranceNumber('');
    setEmergencyNotes('');
    setShowClearInfoConfirm(false);
    showTempStatus('Emergency medical information cleared');
  };

  const executeCall = (phone: string) => {
    window.location.href = `tel:${phone.replace(/\s+/g, '')}`;
    setSelectedCallContact(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      {/* SECTION 1: EMERGENCY CALL POPUP */}
      {selectedCallContact && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border-4 border-rose-500 text-center animate-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4 animate-bounce">
              <PhoneCall className="w-8 h-8" />
            </div>

            <h3 className="font-display font-extrabold text-2xl text-slate-900 mb-2">
              {t('emergencyConfirmation', language)}
            </h3>

            <div className="my-4 p-4 rounded-2xl bg-rose-50 border border-rose-200">
              <p className="font-extrabold text-xl text-slate-900">{selectedCallContact.name}</p>
              <p className="text-sm font-semibold text-rose-700">{selectedCallContact.relationship}</p>
              <p className="text-lg font-mono font-bold text-slate-800 mt-1">{selectedCallContact.phone}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-6">
              <button
                onClick={() => setSelectedCallContact(null)}
                className="py-3 px-4 rounded-xl border-2 border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                {t('cancel', language)}
              </button>
              <button
                onClick={() => executeCall(selectedCallContact.phone)}
                className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold shadow-lg shadow-rose-600/30 flex items-center justify-center space-x-2 cursor-pointer text-lg"
              >
                <PhoneCall className="w-5 h-5" />
                <span>{t('callNow', language)}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: DELETE CONTACT CONFIRMATION POPUP */}
      {contactToDelete && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border-2 border-rose-300 text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-7 h-7" />
            </div>

            <div>
              <h3 className="font-display font-black text-2xl text-slate-900">
                {t('deleteContact', language)}?
              </h3>
              <p className="text-sm text-slate-600 mt-2 font-medium">
                {t('deleteContactConfirm', language)}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-left">
              <p className="font-extrabold text-base text-slate-900">{contactToDelete.name}</p>
              <p className="text-xs font-semibold text-rose-700">{contactToDelete.relationship}</p>
              <p className="text-sm font-mono font-bold text-slate-800 mt-1">{contactToDelete.phone}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setContactToDelete(null)}
                className="py-3 px-4 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                {t('cancel', language)}
              </button>
              <button
                onClick={confirmDeleteIndividualContact}
                className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold shadow-md shadow-rose-600/25 flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: CLEAR ALL CONTACTS CONFIRMATION POPUP */}
      {showClearAllContactsConfirm && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-lg w-full shadow-2xl border-4 border-rose-500 text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-9 h-9" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-black uppercase tracking-wider inline-block mb-2">
                ⚠️ Warning: Life-Safety Setting
              </span>
              <h3 className="font-display font-black text-2xl sm:text-3xl text-slate-900">
                {t('clearAllContacts', language)}?
              </h3>
              <p className="text-sm text-slate-600 mt-2 font-medium leading-relaxed">
                {t('clearAllContactsConfirm', language)}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-900 font-semibold text-left space-y-1">
              <p>• Currently registered: <strong>{contacts.length} contacts</strong></p>
              <p>• If removed, emergency responders and caregivers cannot be auto-notified.</p>
              <p>• You can restore default recommended contacts at any time.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setShowClearAllContactsConfirm(false)}
                className="py-3 px-4 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                Keep Contacts
              </button>
              <button
                onClick={confirmClearAllContacts}
                className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold shadow-md flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Yes, Remove All</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: CLEAR MEDICAL INFO CONFIRMATION POPUP */}
      {showClearInfoConfirm && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border-2 border-slate-300 text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-display font-black text-xl text-slate-900">
                {t('clearMedicalInfo', language)}?
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-2 font-medium">
                {t('clearMedicalInfoConfirm', language)}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setShowClearInfoConfirm(false)}
                className="py-2.5 px-4 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer text-xs sm:text-sm"
              >
                Cancel
              </button>
              <button
                onClick={confirmClearMedicalInfo}
                className="py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold shadow-md cursor-pointer text-xs sm:text-sm"
              >
                Yes, Clear Card
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT CONTACT MODAL */}
      {editingContact && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveEditedContact}
            className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-150"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <Edit2 className="w-5 h-5 text-teal-600" />
                <h3 className="font-display font-black text-xl text-slate-900">
                  {t('editContact', language)}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingContact(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Contact Name *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-slate-50 focus:bg-white focus:border-teal-600 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Relationship</label>
                  <input
                    type="text"
                    value={editRel}
                    onChange={(e) => setEditRel(e.target.value)}
                    placeholder="Son, Daughter, Doctor"
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-slate-50 focus:bg-white focus:border-teal-600 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-slate-50 focus:bg-white focus:border-teal-600 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Notes (Optional)</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="e.g. Lives nearby, has spare key"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-slate-50 focus:bg-white focus:border-teal-600 outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingContact(null)}
                className="px-4 py-2.5 text-xs font-bold text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                {t('cancel', language)}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-extrabold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs cursor-pointer flex items-center space-x-1"
              >
                <Check className="w-4 h-4" />
                <span>{t('saveContactChanges', language)}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Main Emergency Dialog */}
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-rose-600 text-white p-5 sm:p-6 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-white shrink-0 shadow-inner">
              <ShieldAlert className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="font-display font-black text-2xl sm:text-3xl tracking-tight">
                  {sosFlowState === 'verifying'
                    ? t('confirmSosDistress', language)
                    : sosFlowState === 'triggered'
                    ? 'Emergency Alert Transmitted'
                    : t('emergencySos', language)}
                </h2>
                <button
                  onClick={playSirenTest}
                  className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white text-xs font-bold flex items-center space-x-1 cursor-pointer"
                  title="Test Alert Chime"
                >
                  {sirenPlaying ? <VolumeX className="w-3.5 h-3.5 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">{sirenPlaying ? 'Testing...' : 'Test Siren'}</span>
                </button>
              </div>
              <p className="text-xs sm:text-sm text-rose-100 font-medium mt-0.5">
                {sosFlowState === 'verifying'
                  ? 'Step 2 of 2: Security Verification & Confirmation'
                  : sosFlowState === 'triggered'
                  ? 'Incident Active • Distress Signal Broadcast'
                  : 'Immediate Contacts & Life-Saving Medical Information Card'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 cursor-pointer"
            title="Close"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Status Toast Banner */}
        {statusMessage && (
          <div className="bg-teal-500 text-white text-xs font-bold px-4 py-2 text-center animate-in fade-in duration-150">
            ✓ {statusMessage}
          </div>
        )}

        {/* Content Area */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {/* STEP 2: 'ARE YOU SURE?' VERIFICATION SCREEN */}
          {sosFlowState === 'verifying' ? (
            <div id="sos-verification-screen" className="py-6 sm:py-8 px-2 sm:px-6 flex flex-col items-center text-center space-y-6 max-w-xl mx-auto">
              <div className="relative">
                <div className="w-24 h-24 rounded-3xl bg-rose-100 border-4 border-rose-400 text-rose-600 flex items-center justify-center mx-auto shadow-xl shadow-rose-600/20 animate-pulse">
                  <AlertTriangle className="w-12 h-12 text-rose-600" />
                </div>
                <span className="absolute -top-1.5 -right-1.5 flex h-6 w-6">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-6 w-6 bg-rose-600 border-2 border-white"></span>
                </span>
              </div>

              <div>
                <span className="inline-block px-3.5 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-black uppercase tracking-wider mb-2.5 border border-rose-200">
                  ⚠️ Emergency Protocol • Confirmation Required
                </span>
                <h3 className="font-display font-black text-3xl sm:text-4xl text-slate-900 tracking-tight">
                  {t('areYouSureSos', language)}
                </h3>
                <p className="text-sm sm:text-base text-slate-600 mt-2 font-medium leading-relaxed max-w-md mx-auto">
                  A second tap is required to verify your emergency distress alert and prevent accidental triggers.
                </p>
                <div className="inline-flex items-center space-x-2 mt-3 px-3.5 py-1.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200">
                  <Vibrate className="w-4 h-4 text-rose-600 animate-pulse shrink-0" />
                  <span>Physical Vibration Confirmed • Tap Below to Dispatch</span>
                </div>
              </div>

              {/* Location & Response Details Card */}
              <div className="w-full bg-rose-50/80 rounded-2xl p-5 border-2 border-rose-200 text-left space-y-3 shadow-xs">
                <div className="flex items-center space-x-2 text-rose-950 font-bold text-sm">
                  <MapPin className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>GPS Location: 18.5204° N, 73.8567° E (Shivajinagar, Pune)</span>
                </div>
                <div className="text-xs sm:text-sm text-rose-950 space-y-2 pt-2.5 border-t border-rose-200/80 font-medium">
                  <p className="font-bold text-rose-900">Upon your confirmation:</p>
                  <p className="flex items-start space-x-2">
                    <span className="text-rose-600 font-bold text-sm shrink-0">✓</span>
                    <span>High-priority push alert will be dispatched to {contacts.length} registered emergency contacts.</span>
                  </p>
                  <p className="flex items-start space-x-2">
                    <span className="text-rose-600 font-bold text-sm shrink-0">✓</span>
                    <span>Caregiver and family portals will display active emergency indicators.</span>
                  </p>
                  <p className="flex items-start space-x-2">
                    <span className="text-rose-600 font-bold text-sm shrink-0">✓</span>
                    <span>Your medical profile ({emergencyInfo?.bloodGroup || 'B+'} blood group, allergies) will be accessible to responders.</span>
                  </p>
                </div>
              </div>

              {/* Action Buttons: Second Tap to Trigger OR Cancel */}
              <div className="w-full space-y-3 pt-2">
                <button
                  id="confirm-distress-alert-btn"
                  onClick={handleTriggerDistress}
                  className="w-full py-4 sm:py-5 px-6 rounded-2xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-display font-black text-lg sm:text-xl shadow-xl shadow-rose-600/35 flex items-center justify-center space-x-3 cursor-pointer transition transform hover:scale-[1.01] active:scale-[0.98] border-2 border-rose-500 animate-pulse"
                >
                  <ShieldAlert className="w-6 h-6 sm:w-7 sm:h-7" />
                  <span>{t('sendDistressAlertNow', language)}</span>
                </button>

                <button
                  id="cancel-distress-verification-btn"
                  onClick={() => setSosFlowState('idle')}
                  className="w-full py-3.5 px-6 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm sm:text-base flex items-center justify-center space-x-2 cursor-pointer transition border border-slate-300"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{t('cancelSos', language)}</span>
                </button>
              </div>
            </div>
          ) : sosFlowState === 'triggered' ? (
            /* ACTIVE TRIGGERED STATE */
            <div id="sos-triggered-screen" className="py-6 sm:py-8 px-2 sm:px-6 flex flex-col items-center text-center space-y-6 max-w-xl mx-auto">
              <div className="relative">
                <div className="w-20 h-20 rounded-3xl bg-emerald-100 border-4 border-emerald-400 text-emerald-600 flex items-center justify-center mx-auto shadow-xl">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                </div>
                <span className="absolute -top-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500"></span>
                </span>
              </div>

              <div>
                <span className="inline-block px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-black uppercase tracking-wider mb-2 border border-emerald-200">
                  Emergency Alert Active • Dispatched
                </span>
                <h3 className="font-display font-black text-2xl sm:text-3xl text-slate-900 tracking-tight">
                  Distress Alert Sent!
                </h3>
                <p className="text-sm text-slate-600 mt-1.5 font-medium">
                  Your emergency broadcast was transmitted at <strong>{alertTriggeredTime}</strong>. Responders have been alerted with your location and medical card.
                </p>
              </div>

              {/* Dispatch summary */}
              <div className="w-full bg-emerald-50/70 rounded-2xl p-5 border-2 border-emerald-200 text-left space-y-3">
                <div className="flex items-center justify-between text-xs text-emerald-900 font-bold pb-2 border-b border-emerald-200">
                  <span>Broadcast Status</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white font-extrabold uppercase text-[10px]">
                    Live • Active
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-slate-700 space-y-1.5 font-medium">
                  <p>
                    <strong>Recipients:</strong>{' '}
                    {contacts.length > 0
                      ? contacts.map((c) => c.name).join(', ')
                      : 'Emergency Dispatch Center & Connected Family'}
                  </p>
                  <p>
                    <strong>GPS Location:</strong> 18.5204° N, 73.8567° E (Shivajinagar, Pune)
                  </p>
                  <p>
                    <strong>Shared Medical Card:</strong> Blood Group {emergencyInfo?.bloodGroup || 'B+'}, Hospital{' '}
                    {emergencyInfo?.preferredHospital || 'City General'}
                  </p>
                </div>
              </div>

              {/* Direct Emergency Call Shortcuts */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <a
                  href="tel:108"
                  className="py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-sm flex items-center justify-center space-x-2 shadow-lg shadow-rose-600/25 transition cursor-pointer"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Call Ambulance (108)</span>
                </a>
                <a
                  href="tel:112"
                  className="py-3.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-sm flex items-center justify-center space-x-2 shadow-lg shadow-slate-900/25 transition cursor-pointer"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>National Emergency (112)</span>
                </a>
              </div>

              <button
                id="resolve-sos-return-btn"
                onClick={() => setSosFlowState('idle')}
                className="text-sm font-bold text-slate-600 hover:text-slate-900 underline cursor-pointer mt-2"
              >
                Return to Emergency Contacts & Medical Info
              </button>
            </div>
          ) : (
            /* STEP 1: MAIN SOS INTERFACE */
            <>
              {/* LARGE SOS BUTTON */}
              <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-rose-600 via-rose-700 to-red-700 text-white shadow-xl shadow-rose-950/20 border-2 border-rose-400/40 relative overflow-hidden">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
                  <div className="flex items-center space-x-4">
                    <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center shrink-0 shadow-inner">
                      <ShieldAlert className="w-8 h-8 text-white animate-pulse" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2 justify-center sm:justify-start">
                        <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-rose-100 text-[10px] font-black uppercase tracking-wider">
                          1-Click Distress Alert
                        </span>
                        <span className="flex h-2 w-2 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                        </span>
                      </div>
                      <h3 className="font-display font-black text-xl sm:text-2xl text-white tracking-tight mt-1">
                        {t('emergencySos', language)}
                      </h3>
                      <p className="text-xs text-rose-100 font-medium mt-0.5">
                        Broadcast instant distress signal with live GPS coordinates to family & caregivers
                      </p>
                    </div>
                  </div>

                  <button
                    id="emergency-trigger-button"
                    onClick={handleSosInitialPress}
                    className={`w-full sm:w-auto px-6 py-3.5 rounded-2xl font-display font-black text-base sm:text-lg shadow-lg shadow-black/20 flex items-center justify-center space-x-2 transition cursor-pointer transform active:scale-95 shrink-0 border-2 ${
                      hapticActive
                        ? 'bg-rose-100 text-rose-800 border-rose-500 ring-4 ring-white ring-offset-2 ring-offset-rose-700 scale-95'
                        : 'bg-white hover:bg-rose-50 active:bg-rose-100 text-rose-700 border-white/80'
                    }`}
                    aria-label="Trigger Emergency SOS"
                  >
                    {hapticActive ? (
                      <>
                        <Vibrate className="w-5 h-5 text-rose-700 animate-bounce" />
                        <span>Vibrating... Registered!</span>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-5 h-5 text-rose-600" />
                        <span>{t('triggerEmergencySos', language)}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* SECTION: EMERGENCY CONTACTS MANAGEMENT */}
              <div>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3">
                  <div>
                    <h3 className="font-bold text-lg text-slate-900 flex items-center space-x-2">
                      <PhoneCall className="w-5 h-5 text-rose-600" />
                      <span>Priority Emergency Contacts ({contacts.length})</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      Contacts called in sequence during an emergency SOS
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {contacts.length > 0 && (
                      <button
                        id="clear-all-contacts-btn"
                        onClick={() => setShowClearAllContactsConfirm(true)}
                        className="text-xs font-bold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-xl border border-rose-200 cursor-pointer flex items-center space-x-1 transition"
                        title="Remove all registered emergency contacts"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        <span>{t('clearAllContacts', language)}</span>
                      </button>
                    )}

                    <button
                      id="add-contact-btn"
                      onClick={() => setShowAddContact(!showAddContact)}
                      className="text-xs font-bold text-teal-700 hover:text-teal-800 bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-xl border border-teal-200 cursor-pointer flex items-center space-x-1 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Contact</span>
                    </button>
                  </div>
                </div>

                {/* Add Contact inline form */}
                {showAddContact && (
                  <form
                    onSubmit={handleAddNewContact}
                    className="p-4 mb-4 rounded-2xl bg-teal-50/50 border border-teal-200 space-y-3 animate-in fade-in duration-150"
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-bold text-teal-900 uppercase tracking-wide">
                        + Add New Emergency Contact
                      </p>
                      <span className="text-[11px] text-teal-700 font-semibold">Priority #{contacts.length + 1}</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <input
                        type="text"
                        required
                        placeholder="Contact Name (e.g. Rajesh Patel)"
                        value={newContactName}
                        onChange={(e) => setNewContactName(e.target.value)}
                        className="p-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:border-teal-600 outline-none"
                      />
                      <input
                        type="text"
                        placeholder="Relationship (e.g. Son, Doctor)"
                        value={newContactRel}
                        onChange={(e) => setNewContactRel(e.target.value)}
                        className="p-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:border-teal-600 outline-none"
                      />
                      <input
                        type="tel"
                        required
                        placeholder="Phone (e.g. +91 98765 43210)"
                        value={newContactPhone}
                        onChange={(e) => setNewContactPhone(e.target.value)}
                        className="p-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:border-teal-600 outline-none"
                      />
                    </div>

                    <input
                      type="text"
                      placeholder="Optional Notes (e.g. Has apartment key, available after 5 PM)"
                      value={newContactNotes}
                      onChange={(e) => setNewContactNotes(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:border-teal-600 outline-none"
                    />

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowAddContact(false)}
                        className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 rounded-lg hover:bg-slate-200 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 text-xs font-extrabold text-white bg-teal-600 rounded-lg hover:bg-teal-700 cursor-pointer shadow-xs"
                      >
                        Save Contact
                      </button>
                    </div>
                  </form>
                )}

                {/* Contacts List */}
                {contacts.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-200 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
                      <PhoneCall className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-base">No Emergency Contacts Registered</h4>
                      <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                        Please register at least one family member, doctor, or caregiver so responders can be called immediately.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                      <button
                        onClick={() => setShowAddContact(true)}
                        className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-xs cursor-pointer flex items-center space-x-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add First Contact</span>
                      </button>
                      {onResetDefaultContacts && (
                        <button
                          onClick={onResetDefaultContacts}
                          className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs cursor-pointer flex items-center space-x-1"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>{t('resetDefaultContacts', language)}</span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {contacts.map((contact, index) => (
                      <div
                        key={contact.id}
                        className="p-4 rounded-2xl bg-slate-50/90 border border-slate-200 hover:border-rose-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                      >
                        <div className="flex items-center space-x-3.5 flex-1 min-w-0">
                          <span
                            className="w-9 h-9 rounded-xl bg-rose-100 text-rose-700 font-black text-sm flex items-center justify-center shrink-0 border border-rose-200 shadow-2xs"
                            title={`Priority #${contact.priority || index + 1}`}
                          >
                            #{contact.priority || index + 1}
                          </span>

                          <div className="truncate flex-1">
                            <div className="flex items-center space-x-2">
                              <p className="font-extrabold text-slate-900 text-base truncate">{contact.name}</p>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 shrink-0">
                                {contact.relationship}
                              </span>
                            </div>
                            <p className="text-xs font-mono font-bold text-slate-600 mt-0.5">
                              {contact.phone}
                            </p>
                            {contact.notes && (
                              <p className="text-[11px] text-slate-500 italic mt-0.5 truncate">
                                ℹ️ {contact.notes}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Actions for this contact */}
                        <div className="flex items-center space-x-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200 justify-end">
                          {/* Call button */}
                          <button
                            onClick={() => setSelectedCallContact(contact)}
                            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center space-x-1.5 shadow-md shadow-rose-600/20 cursor-pointer transition transform active:scale-95"
                            title={`Call ${contact.name}`}
                          >
                            <PhoneCall className="w-4 h-4" />
                            <span>{t('callContact', language)}</span>
                          </button>

                          {/* Edit button */}
                          <button
                            onClick={() => startEditContact(contact)}
                            className="p-2.5 rounded-xl text-slate-600 hover:text-teal-700 hover:bg-teal-50 border border-slate-200 cursor-pointer transition"
                            title="Edit contact details"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {/* Delete individual button */}
                          <button
                            onClick={() => setContactToDelete(contact)}
                            className="p-2.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 cursor-pointer transition"
                            title={`Delete contact ${contact.name}`}
                            aria-label={`Delete contact ${contact.name}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* SECTION: INDIAN NATIONAL EMERGENCY HELPLINES */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-rose-400" />
                    <h4 className="font-extrabold text-sm text-white">
                      {t('emergencyHelplines', language)}
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    24x7 Toll-Free
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  <a
                    href="tel:108"
                    className="p-2.5 rounded-xl bg-white/10 hover:bg-rose-600 text-center transition cursor-pointer flex flex-col items-center"
                  >
                    <span className="font-black text-rose-400 group-hover:text-white text-base">108</span>
                    <span className="text-[10px] text-slate-300 font-medium">Ambulance</span>
                  </a>
                  <a
                    href="tel:112"
                    className="p-2.5 rounded-xl bg-white/10 hover:bg-rose-600 text-center transition cursor-pointer flex flex-col items-center"
                  >
                    <span className="font-black text-rose-400 text-base">112</span>
                    <span className="text-[10px] text-slate-300 font-medium">National Emergency</span>
                  </a>
                  <a
                    href="tel:101"
                    className="p-2.5 rounded-xl bg-white/10 hover:bg-rose-600 text-center transition cursor-pointer flex flex-col items-center"
                  >
                    <span className="font-black text-rose-400 text-base">101</span>
                    <span className="text-[10px] text-slate-300 font-medium">Fire Dept</span>
                  </a>
                  <a
                    href="tel:1090"
                    className="p-2.5 rounded-xl bg-white/10 hover:bg-rose-600 text-center transition cursor-pointer flex flex-col items-center"
                  >
                    <span className="font-black text-amber-400 text-base">1090</span>
                    <span className="text-[10px] text-slate-300 font-medium">Senior Helpline</span>
                  </a>
                  <a
                    href="tel:14567"
                    className="p-2.5 rounded-xl bg-white/10 hover:bg-rose-600 text-center transition cursor-pointer flex flex-col items-center col-span-2 sm:col-span-1"
                  >
                    <span className="font-black text-teal-300 text-base">14567</span>
                    <span className="text-[10px] text-slate-300 font-medium">Elder Line India</span>
                  </a>
                </div>
              </div>

              {/* EMERGENCY MEDICAL CARD (SECTION 11) */}
              <div className="border-t border-slate-200 pt-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                  <div>
                    <h3 className="font-bold text-lg text-slate-900 flex items-center space-x-2">
                      <Heart className="w-5 h-5 text-teal-600" />
                      <span>Emergency Medical Information Card</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      Vital information provided to medical responders and ambulance doctors
                    </p>
                  </div>

                  <div className="flex items-center space-x-2">
                    {/* Clear medical info button */}
                    {!isEditingInfo && (
                      <button
                        onClick={() => setShowClearInfoConfirm(true)}
                        className="text-xs font-bold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-xl border border-rose-200 cursor-pointer flex items-center space-x-1"
                        title="Clear medical profile info"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t('clearMedicalInfo', language)}</span>
                      </button>
                    )}

                    {!isEditingInfo ? (
                      <button
                        onClick={() => setIsEditingInfo(true)}
                        className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center space-x-1 cursor-pointer bg-teal-50 px-3 py-1.5 rounded-xl border border-teal-200"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit Medical Info</span>
                      </button>
                    ) : (
                      <button
                        onClick={handleSaveInfo}
                        className="text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 flex items-center space-x-1 cursor-pointer px-3.5 py-1.5 rounded-xl shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Save Changes</span>
                      </button>
                    )}
                  </div>
                </div>

                {!isEditingInfo ? (
                  <div className="bg-gradient-to-br from-teal-50/50 to-white rounded-2xl p-5 border border-teal-200/80 shadow-xs space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div>
                        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                          Blood Group
                        </span>
                        <span className="font-black text-rose-600 text-lg sm:text-xl">
                          {emergencyInfo?.bloodGroup || bloodGroup || 'B+'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                          Primary Physician
                        </span>
                        <span className="font-bold text-slate-900 text-sm">
                          {emergencyInfo?.primaryDoctor || primaryDoctor || 'Dr. Joshi'}
                        </span>
                      </div>
                      <div className="sm:col-span-2">
                        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                          Preferred Hospital
                        </span>
                        <span className="font-bold text-slate-900 text-sm">
                          {emergencyInfo?.preferredHospital || preferredHospital || 'City General Hospital (Emergency Wing)'}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-teal-100">
                      <div>
                        <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                          Known Drug Allergies
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {emergencyInfo?.allergies && emergencyInfo.allergies.length > 0 ? (
                            emergencyInfo.allergies.map((alg, i) => (
                              <span
                                key={i}
                                className="px-2.5 py-1 rounded-md bg-rose-100 text-rose-800 font-bold text-xs border border-rose-200"
                              >
                                ⚠️ {alg}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-slate-500 italic">None reported</span>
                          )}
                        </div>
                      </div>

                      <div>
                        <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                          Existing Medical Conditions
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {emergencyInfo?.medicalConditions && emergencyInfo.medicalConditions.length > 0 ? (
                            emergencyInfo.medicalConditions.map((cond, i) => (
                              <span
                                key={i}
                                className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-800 font-bold text-xs border border-slate-200"
                              >
                                {cond}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-slate-500 italic">None reported</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {emergencyInfo?.insuranceNumber && (
                      <div className="pt-2 border-t border-teal-100 flex items-center justify-between text-xs text-slate-600">
                        <span>
                          <strong>Health Insurance ID:</strong> {emergencyInfo.insuranceNumber}
                        </span>
                      </div>
                    )}

                    {emergencyInfo?.emergencyNotes && (
                      <p className="text-xs text-slate-600 italic bg-white/70 p-2.5 rounded-xl border border-slate-100">
                        “{emergencyInfo.emergencyNotes}”
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Blood Group</label>
                        <input
                          type="text"
                          value={bloodGroup}
                          onChange={(e) => setBloodGroup(e.target.value)}
                          placeholder="e.g. B+, O+, AB-"
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Primary Doctor</label>
                        <input
                          type="text"
                          value={primaryDoctor}
                          onChange={(e) => setPrimaryDoctor(e.target.value)}
                          placeholder="e.g. Dr. R. K. Joshi"
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">
                        Known Allergies (comma separated)
                      </label>
                      <input
                        type="text"
                        value={allergiesStr}
                        onChange={(e) => setAllergiesStr(e.target.value)}
                        placeholder="e.g. Penicillin, Sulfa drugs"
                        className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">
                        Chronic Conditions (comma separated)
                      </label>
                      <input
                        type="text"
                        value={conditionsStr}
                        onChange={(e) => setConditionsStr(e.target.value)}
                        placeholder="e.g. Hypertension, Type 2 Diabetes"
                        className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Preferred Hospital</label>
                        <input
                          type="text"
                          value={preferredHospital}
                          onChange={(e) => setPreferredHospital(e.target.value)}
                          placeholder="e.g. City General Hospital"
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Insurance Policy Number</label>
                        <input
                          type="text"
                          value={insuranceNumber}
                          onChange={(e) => setInsuranceNumber(e.target.value)}
                          placeholder="e.g. POL-12345"
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">Emergency Notes</label>
                      <textarea
                        rows={2}
                        value={emergencyNotes}
                        onChange={(e) => setEmergencyNotes(e.target.value)}
                        placeholder="Notes for emergency responders (e.g. carries inhaler in purse)..."
                        className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-sm"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsEditingInfo(false)}
                        className="px-3.5 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveInfo}
                        className="px-4 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg cursor-pointer"
                      >
                        Save Information
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-3 shrink-0">
          <p className="text-xs text-slate-600 text-center sm:text-left">
            {sosFlowState === 'verifying'
              ? 'Security Step: 2-step verification prevents false alarms.'
              : sosFlowState === 'triggered'
              ? 'Distress signal dispatched. Keep your phone line clear.'
              : 'For critical life-threatening situations, dial 108 / 112 immediately.'}
          </p>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 font-bold text-sm text-slate-800 cursor-pointer"
          >
            {sosFlowState === 'triggered' ? 'Close Window' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
