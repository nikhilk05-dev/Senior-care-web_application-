import React from 'react';
import {
  Users,
  Pill,
  Calendar,
  Activity,
  ShieldCheck,
  TrendingUp,
  FileText,
  History,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { Language } from '../../types';
import { t } from '../../i18n';

interface AdminDashboardViewProps {
  language: Language;
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  language,
  onNavigateTab,
}) => {
  const stats = [
    { label: 'Total Registered Users', value: '1,428', icon: Users, color: 'text-teal-700 bg-teal-50' },
    { label: 'Prescription Fulfillment Rate', value: '94.2%', icon: Pill, color: 'text-emerald-700 bg-emerald-50' },
    { label: 'Scheduled Appointments', value: '382', icon: Calendar, color: 'text-indigo-700 bg-indigo-50' },
    { label: 'Daily Vitals Logged', value: '2,940', icon: Activity, color: 'text-rose-700 bg-rose-50' },
  ];

  const recentLogs = [
    { action: 'Emergency Contact Triggered', user: 'Ramesh Patel', time: '10 mins ago', type: 'warning' },
    { action: 'Medicine Dose Marked Taken', user: 'Ramesh Patel', time: '25 mins ago', type: 'success' },
    { action: 'Family Permission Updated', user: 'Ramesh Patel -> Priya Patel', time: '1 hour ago', type: 'info' },
    { action: 'New Caregiver Connected', user: 'Priya Patel', time: '3 hours ago', type: 'info' },
    { action: 'System Backup Completed', user: 'System Worker', time: '6 hours ago', type: 'success' },
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-slate-200 px-3 py-1 rounded-full">
          Super Admin Console
        </span>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight mt-2">
          SeniorCare Platform Administration
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          System health, platform-wide dose fulfillment, user governance, and security audits.
        </p>
      </div>

      {/* KPI Cards (Section 23) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <div
              key={i}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex items-center justify-between"
            >
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">{s.label}</p>
                <p className="font-display font-black text-3xl text-slate-900 mt-1">{s.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${s.color}`}>
                <Icon className="w-6 h-6" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Navigation Panels */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div
          onClick={() => onNavigateTab('adminUsers')}
          className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-md transition cursor-pointer"
        >
          <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center mb-4">
            <Users className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-lg text-slate-900">User Management</h4>
          <p className="text-xs text-slate-500 mt-1">
            Manage senior accounts, family caregivers, and account activation statuses.
          </p>
          <span className="text-xs font-bold text-teal-700 mt-4 block">Manage Users →</span>
        </div>

        <div
          onClick={() => onNavigateTab('adminTips')}
          className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-md transition cursor-pointer"
        >
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mb-4">
            <Lightbulb className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-lg text-slate-900">Health Tips Management</h4>
          <p className="text-xs text-slate-500 mt-1">
            Curate and publish educational articles, hydration advice, and seasonal wellness tips.
          </p>
          <span className="text-xs font-bold text-teal-700 mt-4 block">Manage Tips →</span>
        </div>

        <div
          onClick={() => onNavigateTab('adminReports')}
          className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-md transition cursor-pointer"
        >
          <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4">
            <FileText className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-lg text-slate-900">System Reports & Exports</h4>
          <p className="text-xs text-slate-500 mt-1">
            Download HIPAA-compliant medicine reports, appointment logs, and clinical summaries.
          </p>
          <span className="text-xs font-bold text-teal-700 mt-4 block">Export Reports →</span>
        </div>
      </div>

      {/* Recent Activity Log (Section 27) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <History className="w-5 h-5 text-slate-700" />
            <h3 className="font-bold text-lg text-slate-900">Recent Platform Activity & Audit</h3>
          </div>
          <button
            onClick={() => onNavigateTab('adminLogs')}
            className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
          >
            View Full Audit Log →
          </button>
        </div>

        <div className="mt-4 divide-y divide-slate-100">
          {recentLogs.map((log, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    log.type === 'warning'
                      ? 'bg-rose-500'
                      : log.type === 'success'
                      ? 'bg-emerald-500'
                      : 'bg-teal-500'
                  }`}
                />
                <div>
                  <p className="font-bold text-sm text-slate-900">{log.action}</p>
                  <p className="text-xs text-slate-500">Initiated by {log.user}</p>
                </div>
              </div>
              <span className="text-xs text-slate-400 font-mono">{log.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
