import React, { useState } from 'react';
import { History, Search, Filter, ShieldCheck, AlertCircle } from 'lucide-react';
import { Language } from '../../types';
import { t } from '../../i18n';

interface AdminLogsViewProps {
  language: Language;
}

export const AdminLogsView: React.FC<AdminLogsViewProps> = ({ language }) => {
  const [filter, setFilter] = useState('all');

  const logs = [
    {
      id: 'log-1',
      action: 'Emergency Call Triggered',
      user: 'Ramesh Patel (Senior)',
      details: 'Connected to Priya Patel (+91 98765 43211)',
      category: 'emergency',
      timestamp: '2026-03-15 11:20:14',
      status: 'Warning',
    },
    {
      id: 'log-2',
      action: 'Medicine Dose Marked Taken',
      user: 'Ramesh Patel (Senior)',
      details: 'Telmisartan 40mg taken on time (08:35 AM)',
      category: 'medicine',
      timestamp: '2026-03-15 08:35:02',
      status: 'Success',
    },
    {
      id: 'log-3',
      action: 'Family Permission Updated',
      user: 'Ramesh Patel (Senior)',
      details: 'Medicine Schedule permission set to TRUE for Priya Patel',
      category: 'privacy',
      timestamp: '2026-03-15 07:15:20',
      status: 'Success',
    },
    {
      id: 'log-4',
      action: 'User Authentication Login',
      user: 'Priya Patel (Caregiver)',
      details: 'Successful login from mobile web client',
      category: 'auth',
      timestamp: '2026-03-15 06:40:11',
      status: 'Success',
    },
    {
      id: 'log-5',
      action: 'Admin Published Health Tip',
      user: 'Dr. Anand Sharma (Admin)',
      details: 'Published "Sip Warm Water in the Morning" to all seniors',
      category: 'content',
      timestamp: '2026-03-14 18:00:00',
      status: 'Success',
    },
    {
      id: 'log-6',
      action: 'Water Intake Goal Reached',
      user: 'Suresh Deshmukh (Senior)',
      details: 'Reached 8 glasses (2,000 ml) daily hydration',
      category: 'wellness',
      timestamp: '2026-03-14 16:45:30',
      status: 'Success',
    },
  ];

  const filteredLogs = filter === 'all' ? logs : logs.filter((l) => l.category === filter);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
          {t('adminLogs', language)}
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Cryptographically timestamped audit trail of all security, authentication, and emergency events.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {['all', 'emergency', 'medicine', 'privacy', 'auth', 'content'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
              filter === cat
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Logs Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="p-4 pl-6">Timestamp</th>
                <th className="p-4">Action</th>
                <th className="p-4">User</th>
                <th className="p-4">Event Details</th>
                <th className="p-4 text-right pr-6">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/50">
                  <td className="p-4 pl-6 font-mono text-xs text-slate-500 whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="p-4 font-bold text-slate-900">{log.action}</td>
                  <td className="p-4 text-xs font-medium text-slate-700">{log.user}</td>
                  <td className="p-4 text-xs text-slate-600 max-w-sm">{log.details}</td>
                  <td className="p-4 text-right pr-6">
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                        log.status === 'Warning'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
