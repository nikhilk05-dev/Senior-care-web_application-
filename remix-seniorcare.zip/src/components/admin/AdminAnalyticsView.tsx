import React from 'react';
import { TrendingUp, Users, PieChart, Activity, Globe, Award } from 'lucide-react';
import { Language } from '../../types';
import { t } from '../../i18n';

interface AdminAnalyticsViewProps {
  language: Language;
}

export const AdminAnalyticsView: React.FC<AdminAnalyticsViewProps> = ({ language }) => {
  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
          {t('adminAnalytics', language)}
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Population health insights, regional language adoption, and medication compliance metrics.
        </p>
      </div>

      {/* Grid: Dose Fulfillment Distribution + Role Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Medicine Dose Fulfillment Distribution */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 className="font-bold text-lg text-slate-900">Daily Dose Fulfillment Distribution</h3>
            <span className="text-xs font-semibold text-slate-500">1,428 Seniors</span>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-emerald-800">High Completion (90% – 100%)</span>
                <span className="text-slate-900">76% of Seniors</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '76%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-teal-800">Moderate Completion (75% – 89%)</span>
                <span className="text-slate-900">18% of Seniors</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full" style={{ width: '18%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-rose-800">Pending Doses (&lt; 75%)</span>
                <span className="text-slate-900">6% of Seniors</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500 rounded-full" style={{ width: '6%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Language Adoption Breakdown (Section 19 & 28) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 className="font-bold text-lg text-slate-900">Regional Language Adoption</h3>
            <span className="text-xs font-semibold text-slate-500">Active Preference</span>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-800">English (EN)</span>
                <span className="text-slate-900">45%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-teal-600 rounded-full" style={{ width: '45%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-800">हिन्दी (Hindi)</span>
                <span className="text-slate-900">35%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full" style={{ width: '35%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-800">मराठी (Marathi)</span>
                <span className="text-slate-900">20%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: '20%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Population Vitals Insights */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <h3 className="font-bold text-lg text-slate-900 mb-4">Most Monitored Health Parameters</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200">
            <p className="font-black text-2xl text-teal-800">54%</p>
            <p className="text-xs font-bold text-slate-600 mt-1">Blood Pressure</p>
          </div>
          <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200">
            <p className="font-black text-2xl text-indigo-800">28%</p>
            <p className="text-xs font-bold text-slate-600 mt-1">Blood Sugar (Glucose)</p>
          </div>
          <div className="p-4 rounded-2xl bg-sky-50 border border-sky-200">
            <p className="font-black text-2xl text-sky-800">12%</p>
            <p className="text-xs font-bold text-slate-600 mt-1">SpO2 Oxygen</p>
          </div>
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
            <p className="font-black text-2xl text-amber-800">6%</p>
            <p className="text-xs font-bold text-slate-600 mt-1">Heart Rate / Weight</p>
          </div>
        </div>
      </div>
    </div>
  );
};
