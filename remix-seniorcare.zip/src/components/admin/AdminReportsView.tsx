import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  Users,
  Pill,
  Calendar,
  Activity,
  CheckCircle2,
} from 'lucide-react';
import { Language } from '../../types';
import { t } from '../../i18n';

interface AdminReportsViewProps {
  language: Language;
}

export const AdminReportsView: React.FC<AdminReportsViewProps> = ({ language }) => {
  const [selectedReport, setSelectedReport] = useState<
    'users' | 'medicines' | 'appointments' | 'healthRecords'
  >('medicines');

  const downloadCSV = (title: string, headers: string[], rows: string[][]) => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(',')]
        .concat(rows.map((row) => row.map((cell) => `"${cell}"`).join(',')))
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${title}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExport = () => {
    if (selectedReport === 'users') {
      downloadCSV(
        'seniorcare_users_report',
        ['Name', 'Email', 'Role', 'Status', 'Language', 'Registered Date'],
        [
          ['Ramesh Patel', 'ramesh@example.com', 'Senior', 'Active', 'en', '2026-01-15'],
          ['Priya Patel', 'priya@example.com', 'Caregiver', 'Active', 'en', '2026-01-16'],
          ['Suresh Deshmukh', 'suresh@example.com', 'Senior', 'Active', 'mr', '2026-02-01'],
          ['Dr. Anand Sharma', 'admin@seniorcare.org', 'Admin', 'Active', 'en', '2026-01-01'],
        ]
      );
    } else if (selectedReport === 'medicines') {
      downloadCSV(
        'seniorcare_medicine_fulfillment_report',
        ['Senior Name', 'Total Medicines', 'Scheduled Doses', 'Completion Rate', 'Status'],
        [
          ['Ramesh Patel', '4', '8', '100%', 'Completed'],
          ['Suresh Deshmukh', '3', '6', '83.3%', 'Good'],
          ['Kamla Rao', '5', '10', '90%', 'Completed'],
          ['Devendra Joshi', '2', '4', '50%', 'Pending'],
        ]
      );
    } else if (selectedReport === 'appointments') {
      downloadCSV(
        'seniorcare_appointments_report',
        ['Senior Name', 'Doctor', 'Clinic', 'Date', 'Time', 'Status'],
        [
          ['Ramesh Patel', 'Dr. A. K. Joshi', 'City Care Hospital', '2026-03-25', '10:30 AM', 'Upcoming'],
          ['Suresh Deshmukh', 'Dr. Meera Patil', 'Apollo Clinic', '2026-03-28', '04:00 PM', 'Upcoming'],
        ]
      );
    } else {
      downloadCSV(
        'seniorcare_health_records_report',
        ['Senior Name', 'Date', 'Metric', 'Value', 'Unit'],
        [
          ['Ramesh Patel', '2026-03-15', 'Blood Pressure', '128/82', 'mmHg'],
          ['Ramesh Patel', '2026-03-15', 'Blood Sugar', '112', 'mg/dL'],
          ['Ramesh Patel', '2026-03-15', 'Oxygen SpO2', '98', '%'],
        ]
      );
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('adminReports', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Generate and export system-wide compliance reports, medication schedule tables, and clinical summaries.
          </p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => window.print()}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center space-x-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Current Report</span>
          </button>
          <button
            onClick={handleExport}
            className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center space-x-1.5 shadow-md shadow-teal-700/20 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Report Selector Tabs (Section 26) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { id: 'medicines', label: 'Medicine Schedules', icon: Pill },
          { id: 'users', label: 'User Registry', icon: Users },
          { id: 'appointments', label: 'Clinical Appointments', icon: Calendar },
          { id: 'healthRecords', label: 'Health Records & Vitals', icon: Activity },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = selectedReport === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedReport(tab.id as any)}
              className={`p-4 rounded-2xl border text-left transition cursor-pointer flex items-center space-x-3 ${
                isActive
                  ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span className="font-bold text-sm">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Report Table Preview */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        {selectedReport === 'medicines' && (
          <div>
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-lg text-slate-900">Platform-Wide Medicine Dose Fulfillment Report</h3>
                <p className="text-xs text-slate-500">
                  Dose completion summary across registered senior profiles
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                Platform Fulfillment: 94.2%
              </span>
            </div>

            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="p-4 pl-6">Senior Citizen</th>
                  <th className="p-4">Active Medicines</th>
                  <th className="p-4">Scheduled Doses</th>
                  <th className="p-4">Completion Rate</th>
                  <th className="p-4 pr-6 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr className="hover:bg-slate-50/50">
                  <td className="p-4 pl-6 font-bold text-slate-900">Ramesh Patel</td>
                  <td className="p-4">4</td>
                  <td className="p-4">8</td>
                  <td className="p-4 font-black text-emerald-700">100%</td>
                  <td className="p-4 pr-6 text-right">
                    <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                      Excellent
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="p-4 pl-6 font-bold text-slate-900">Suresh Deshmukh</td>
                  <td className="p-4">3</td>
                  <td className="p-4">6</td>
                  <td className="p-4 font-black text-teal-700">83.3%</td>
                  <td className="p-4 pr-6 text-right">
                    <span className="px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold">
                      Good
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="p-4 pl-6 font-bold text-slate-900">Kamla Rao</td>
                  <td className="p-4">5</td>
                  <td className="p-4">10</td>
                  <td className="p-4 font-black text-emerald-700">90%</td>
                  <td className="p-4 pr-6 text-right">
                    <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                      Excellent
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="p-4 pl-6 font-bold text-slate-900">Devendra Joshi</td>
                  <td className="p-4">2</td>
                  <td className="p-4">4</td>
                  <td className="p-4 font-black text-rose-700">50%</td>
                  <td className="p-4 pr-6 text-right">
                    <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold">
                      Needs Attention
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {selectedReport === 'users' && (
          <div className="p-6">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Total Registered Users Report</h3>
            <p className="text-xs text-slate-500 mb-4">Active registry of seniors, family caregivers, and administrators.</p>
            <div className="p-4 bg-slate-50 rounded-2xl text-xs text-slate-700">
              Click “Export CSV” above to download the full detailed 1,428-record user roster with verification timestamps.
            </div>
          </div>
        )}

        {selectedReport === 'appointments' && (
          <div className="p-6">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Clinical Appointments & Teleconsultations</h3>
            <p className="text-xs text-slate-500 mb-4">Upcoming and completed medical visits across hospitals.</p>
            <div className="p-4 bg-slate-50 rounded-2xl text-xs text-slate-700">
              Click “Export CSV” above to download the clinical appointment registry.
            </div>
          </div>
        )}

        {selectedReport === 'healthRecords' && (
          <div className="p-6">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Health Records & Biometric Logs</h3>
            <p className="text-xs text-slate-500 mb-4">Blood pressure, glucose, and oxygen saturation logs.</p>
            <div className="p-4 bg-slate-50 rounded-2xl text-xs text-slate-700">
              Click “Export CSV” above to download the vitals log dataset.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
