import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Trash2,
  AlertTriangle,
  UserCheck,
  Shield,
} from 'lucide-react';
import { User, Language } from '../../types';
import { t } from '../../i18n';

interface AdminUsersViewProps {
  language: Language;
}

export const AdminUsersView: React.FC<AdminUsersViewProps> = ({ language }) => {
  const [users, setUsers] = useState<User[]>([
    {
      id: 'user_senior_1',
      name: 'Ramesh Patel',
      email: 'ramesh@example.com',
      phone: '+91 98765 43210',
      role: 'senior',
      language: 'en',
      fontSize: 'large',
      accountStatus: 'active',
      createdAt: '2026-01-15T10:00:00Z',
    },
    {
      id: 'user_caregiver_1',
      name: 'Priya Patel',
      email: 'priya@example.com',
      phone: '+91 98765 43211',
      role: 'caregiver',
      language: 'en',
      fontSize: 'normal',
      accountStatus: 'active',
      createdAt: '2026-01-16T11:30:00Z',
    },
    {
      id: 'user_senior_2',
      name: 'Suresh Deshmukh',
      email: 'suresh@example.com',
      phone: '+91 98123 45678',
      role: 'senior',
      language: 'mr',
      fontSize: 'xlarge',
      accountStatus: 'active',
      createdAt: '2026-02-01T09:15:00Z',
    },
    {
      id: 'user_caregiver_2',
      name: 'Amit Deshmukh',
      email: 'amit@example.com',
      phone: '+91 98123 45679',
      role: 'caregiver',
      language: 'mr',
      fontSize: 'normal',
      accountStatus: 'inactive',
      createdAt: '2026-02-02T14:20:00Z',
    },
    {
      id: 'user_admin_1',
      name: 'Dr. Anand Sharma',
      email: 'admin@seniorcare.org',
      phone: '+91 99999 88888',
      role: 'admin',
      language: 'en',
      fontSize: 'normal',
      accountStatus: 'active',
      createdAt: '2026-01-01T08:00:00Z',
    },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [deletingUser, setDeletingUser] = useState<User | null>(null);

  const toggleStatus = (id: string) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          const nextStatus = u.accountStatus === 'active' ? 'inactive' : 'active';
          return { ...u, accountStatus: nextStatus };
        }
        return u;
      })
    );
  };

  const confirmDelete = () => {
    if (deletingUser) {
      setUsers((prev) => prev.filter((u) => u.id !== deletingUser.id));
      setDeletingUser(null);
    }
  };

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
          {t('adminUsers', language)}
        </h1>
        <p className="text-slate-600 text-sm mt-1">
          Review accounts, manage roles, adjust account activation states, and purge user data.
        </p>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm bg-slate-50 focus:bg-white"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="p-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-white"
          >
            <option value="all">All Roles</option>
            <option value="senior">Senior Citizens</option>
            <option value="caregiver">Family / Caregivers</option>
            <option value="admin">Administrators</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="p-4 pl-6">User</th>
                <th className="p-4">Role</th>
                <th className="p-4">Contact</th>
                <th className="p-4">Language</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right pr-6">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/50 transition">
                  <td className="p-4 pl-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-800 font-bold text-sm flex items-center justify-center">
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{u.name}</p>
                        <p className="text-xs text-slate-500">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        u.role === 'senior'
                          ? 'bg-teal-100 text-teal-800'
                          : u.role === 'caregiver'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-slate-800 text-slate-100'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="p-4 text-xs font-medium text-slate-600">{u.phone || '—'}</td>
                  <td className="p-4 text-xs font-bold text-slate-500 uppercase">{u.language}</td>
                  <td className="p-4">
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center space-x-1 ${
                        u.accountStatus === 'active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {u.accountStatus === 'active' ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Active</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Inactive</span>
                        </>
                      )}
                    </span>
                  </td>
                  <td className="p-4 text-right pr-6">
                    <div className="flex items-center justify-end space-x-2">
                      <button
                        onClick={() => toggleStatus(u.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer border ${
                          u.accountStatus === 'active'
                            ? 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200'
                            : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border-emerald-200'
                        }`}
                      >
                        {u.accountStatus === 'active' ? 'Deactivate' : 'Activate'}
                      </button>

                      <button
                        onClick={() => setDeletingUser(u)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                        title="Delete User"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete User Modal (Section 24) */}
      {deletingUser && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border-2 border-rose-300 text-center">
            <div className="w-14 h-14 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="font-display font-extrabold text-2xl text-slate-900 mb-2">
              Permanently Delete User?
            </h3>

            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              Are you sure you want to delete user <strong>{deletingUser.name}</strong> ({deletingUser.email})? All associated health logs and schedules will be permanently wiped.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setDeletingUser(null)}
                className="py-3 px-4 rounded-xl border-2 border-slate-200 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
