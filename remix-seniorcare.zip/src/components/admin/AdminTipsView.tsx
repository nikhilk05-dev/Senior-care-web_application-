import React, { useState } from 'react';
import {
  Lightbulb,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Volume2,
} from 'lucide-react';
import { HealthTip, Language } from '../../types';
import { t } from '../../i18n';

interface AdminTipsViewProps {
  tips: HealthTip[];
  language: Language;
  onAddTip: (tip: Partial<HealthTip>) => void;
  onDeleteTip: (id: string) => void;
  onToggleActiveTip: (id: string) => void;
}

export const AdminTipsView: React.FC<AdminTipsViewProps> = ({
  tips,
  language,
  onAddTip,
  onDeleteTip,
  onToggleActiveTip,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Nutrition');
  const [content, setContent] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    onAddTip({
      title,
      category,
      content,
      isActive: true,
      audioSupported: true,
    });

    setTitle('');
    setContent('');
    setShowModal(false);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-black text-3xl text-slate-900 tracking-tight">
            {t('adminTips', language)}
          </h1>
          <p className="text-slate-600 text-sm mt-1">
            Curate verified senior health advice, hydration reminders, and seasonal nutrition tips.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-bold text-sm shadow-md shadow-teal-700/20 flex items-center space-x-2 cursor-pointer transition"
        >
          <Plus className="w-5 h-5" />
          <span>Add New Health Tip</span>
        </button>
      </div>

      {/* Tips Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
            <tr>
              <th className="p-4 pl-6">Tip Title & Advice</th>
              <th className="p-4">Category</th>
              <th className="p-4">Audio Ready</th>
              <th className="p-4">Status</th>
              <th className="p-4 text-right pr-6">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {tips.map((tip) => (
              <tr key={tip.id} className="hover:bg-slate-50/50">
                <td className="p-4 pl-6 max-w-md">
                  <p className="font-bold text-slate-900 text-sm">{tip.title}</p>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-0.5">{tip.content}</p>
                </td>
                <td className="p-4">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900">
                    {tip.category}
                  </span>
                </td>
                <td className="p-4 text-xs font-semibold text-teal-700 flex items-center space-x-1 mt-3">
                  <Volume2 className="w-4 h-4" />
                  <span>Speech Ready</span>
                </td>
                <td className="p-4">
                  <button
                    onClick={() => onToggleActiveTip(tip.id)}
                    className={`px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center space-x-1 cursor-pointer ${
                      tip.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {tip.isActive ? 'Active' : 'Draft'}
                  </button>
                </td>
                <td className="p-4 text-right pr-6">
                  <button
                    onClick={() => {
                      if (confirm(`Delete tip "${tip.title}"?`)) {
                        onDeleteTip(tip.id);
                      }
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                    title="Delete Tip"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Tip Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-display font-bold text-xl text-slate-900">Add New Health Tip</h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Sip Warm Water in the Morning"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm bg-white"
                >
                  <option value="Hydration">Hydration</option>
                  <option value="Nutrition">Nutrition</option>
                  <option value="Medicine Safety">Medicine Safety</option>
                  <option value="Exercise & Mobility">Exercise & Mobility</option>
                  <option value="Sleep & Rest">Sleep & Rest</option>
                  <option value="Mental Wellness">Mental Wellness</option>
                  <option value="Preventive Care">Preventive Care</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Educational Content (Speech Read-Aloud Compatible) *
                </label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write gentle, encouraging health advice with clear pronunciation..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-sm"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md cursor-pointer"
                >
                  Publish Tip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
