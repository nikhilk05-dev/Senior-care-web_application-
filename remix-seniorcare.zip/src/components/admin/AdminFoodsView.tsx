import React, { useState, useMemo } from 'react';
import {
  Utensils,
  Plus,
  Search,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X,
  Filter,
  Check,
  Flame,
  Apple,
} from 'lucide-react';
import { FoodItem, Language } from '../../types';

interface AdminFoodsViewProps {
  foods: FoodItem[];
  language: Language;
  onAddFood: (food: Omit<FoodItem, 'id'>) => Promise<void> | void;
  onUpdateFood: (id: string, updates: Partial<FoodItem>) => Promise<void> | void;
  onDeleteFood: (id: string) => Promise<void> | void;
}

export const AdminFoodsView: React.FC<AdminFoodsViewProps> = ({
  foods,
  language,
  onAddFood,
  onUpdateFood,
  onDeleteFood,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingFood, setEditingFood] = useState<FoodItem | null>(null);

  // Toast notification
  const [notification, setNotification] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // Distinct categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    foods.forEach((f) => {
      if (f.category) set.add(f.category);
    });
    return Array.from(set);
  }, [foods]);

  // Filtered foods
  const filteredFoods = useMemo(() => {
    return foods.filter((f) => {
      const matchesSearch =
        !searchQuery.trim() ||
        f.foodName.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        (f.category && f.category.toLowerCase().includes(searchQuery.toLowerCase().trim()));

      const matchesCat = categoryFilter === 'all' || f.category === categoryFilter;

      return matchesSearch && matchesCat;
    });
  }, [foods, searchQuery, categoryFilter]);

  return (
    <div className="space-y-6 pb-12">
      {/* Toast */}
      {notification && (
        <div className="fixed top-24 right-4 z-50 flex items-center space-x-2 px-4 py-3 bg-teal-600 text-white rounded-2xl shadow-xl text-sm font-bold animate-bounce">
          <CheckCircle2 className="w-5 h-5" />
          <span>{notification}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
            Admin Console • Master Nutrition Database
          </span>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-white mt-2">
            Food & Nutrition Database Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Maintain high-quality nutritional records, standard senior servings, and macronutrient data.
          </p>
        </div>

        <button
          onClick={() => setIsAddOpen(true)}
          className="flex items-center space-x-2 px-5 py-3 bg-teal-600 hover:bg-teal-500 active:bg-teal-700 text-white font-extrabold text-sm rounded-2xl shadow-lg transition cursor-pointer"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>Add New Food</span>
        </button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Foods in DB</span>
          <span className="text-2xl font-black text-slate-900 mt-1 block">{foods.length}</span>
          <span className="text-xs text-slate-500">Standardized nutritional profiles</span>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Meal Categories</span>
          <span className="text-2xl font-black text-teal-700 mt-1 block">{categories.length || 4}</span>
          <span className="text-xs text-slate-500">Breakfast, lunch, snacks, dinner</span>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Average Calories</span>
          <span className="text-2xl font-black text-orange-600 mt-1 block">
            {foods.length > 0 ? Math.round(foods.reduce((acc, f) => acc + f.calories, 0) / foods.length) : 0} kcal
          </span>
          <span className="text-xs text-slate-500">Per typical senior portion</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center gap-3 justify-between">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search foods by name or category..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700"
          >
            <option value="all">All Categories ({foods.length})</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Foods Table / Grid */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-4">Food Name</th>
                <th className="py-3.5 px-4">Serving Size</th>
                <th className="py-3.5 px-4">Calories</th>
                <th className="py-3.5 px-4">Protein</th>
                <th className="py-3.5 px-4">Carbs</th>
                <th className="py-3.5 px-4">Fat</th>
                <th className="py-3.5 px-4">Fiber</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredFoods.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    No foods found matching your search.
                  </td>
                </tr>
              ) : (
                filteredFoods.map((f) => (
                  <tr key={f.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">{f.foodName}</td>
                    <td className="py-3 px-4 text-slate-600 text-xs">{f.servingSize}</td>
                    <td className="py-3 px-4 font-extrabold text-orange-700">{f.calories} kcal</td>
                    <td className="py-3 px-4 text-slate-600">{f.protein}g</td>
                    <td className="py-3 px-4 text-slate-600">{f.carbohydrates}g</td>
                    <td className="py-3 px-4 text-slate-600">{f.fat}g</td>
                    <td className="py-3 px-4 text-slate-600">{f.fiber}g</td>
                    <td className="py-3 px-4">
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                        {f.category || 'General'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1">
                      <button
                        onClick={() => setEditingFood(f)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-teal-700 hover:bg-slate-100 cursor-pointer"
                        title="Edit Food"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={async () => {
                          if (window.confirm(`Delete "${f.foodName}" from food database?`)) {
                            await onDeleteFood(f.id);
                            showToast(`"${f.foodName}" removed from database.`);
                          }
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                        title="Delete Food"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Add Food */}
      {isAddOpen && (
        <FoodFormModal
          title="Add New Food Item to Database"
          onClose={() => setIsAddOpen(false)}
          onSave={async (foodData) => {
            await onAddFood(foodData);
            setIsAddOpen(false);
            showToast(`Added "${foodData.foodName}" to database.`);
          }}
        />
      )}

      {/* Modal: Edit Food */}
      {editingFood && (
        <FoodFormModal
          title={`Edit Food: ${editingFood.foodName}`}
          initialData={editingFood}
          onClose={() => setEditingFood(null)}
          onSave={async (foodData) => {
            await onUpdateFood(editingFood.id, foodData);
            setEditingFood(null);
            showToast(`Updated "${foodData.foodName}".`);
          }}
        />
      )}
    </div>
  );
};

// Form Modal Component for Admin Add / Edit
interface FoodFormModalProps {
  title: string;
  initialData?: FoodItem;
  onClose: () => void;
  onSave: (data: Omit<FoodItem, 'id'>) => Promise<void> | void;
}

const FoodFormModal: React.FC<FoodFormModalProps> = ({ title, initialData, onClose, onSave }) => {
  const [foodName, setFoodName] = useState(initialData?.foodName || '');
  const [servingSize, setServingSize] = useState(initialData?.servingSize || '1 serving');
  const [calories, setCalories] = useState<number>(initialData?.calories ?? 150);
  const [protein, setProtein] = useState<number>(initialData?.protein ?? 5);
  const [carbohydrates, setCarbs] = useState<number>(initialData?.carbohydrates ?? 20);
  const [fat, setFat] = useState<number>(initialData?.fat ?? 4);
  const [fiber, setFiber] = useState<number>(initialData?.fiber ?? 3);
  const [category, setCategory] = useState(initialData?.category || 'Lunch & Dinner');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName.trim()) {
      setErrorMessage('Food name is required.');
      return;
    }
    if (calories < 0 || isNaN(calories)) {
      setErrorMessage('Calories cannot be negative.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        foodName: foodName.trim(),
        servingSize: servingSize.trim() || '1 serving',
        calories: Math.round(calories),
        protein: Math.round(protein * 10) / 10,
        carbohydrates: Math.round(carbohydrates * 10) / 10,
        fat: Math.round(fat * 10) / 10,
        fiber: Math.round(fiber * 10) / 10,
        category: category.trim() || 'General',
      });
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error saving food.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">{title}</h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold">
              {errorMessage}
            </div>
          )}

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Food Name *</label>
            <input
              type="text"
              required
              value={foodName}
              onChange={(e) => setFoodName(e.target.value)}
              placeholder="e.g. Boiled Egg"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Standard Serving</label>
              <input
                type="text"
                value={servingSize}
                onChange={(e) => setServingSize(e.target.value)}
                placeholder="e.g. 1 bowl (200g)"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold"
              >
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch & Dinner">Lunch & Dinner</option>
                <option value="Fruits & Snacks">Fruits & Snacks</option>
                <option value="Dinner">Dinner</option>
                <option value="Snacks">Snacks</option>
                <option value="Beverages">Beverages</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Calories (kcal) *</label>
              <input
                type="number"
                min="0"
                value={calories}
                onChange={(e) => setCalories(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-orange-700"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Protein (g)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={protein}
                onChange={(e) => setProtein(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Carbs (g)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={carbohydrates}
                onChange={(e) => setCarbs(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Fat (g)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={fat}
                onChange={(e) => setFat(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Dietary Fiber (g)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={fiber}
                onChange={(e) => setFiber(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
              />
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 font-bold text-sm"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm rounded-xl cursor-pointer"
            >
              {isSubmitting ? 'Saving...' : 'Save Food'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
