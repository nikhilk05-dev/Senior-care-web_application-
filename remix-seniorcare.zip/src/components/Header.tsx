import React, { useState } from 'react';
import {
  PhoneCall,
  Bell,
  Globe,
  Type,
  User as UserIcon,
  ShieldAlert,
  LogOut,
  ChevronDown,
  Menu,
  X,
  HeartPulse,
  KeyRound,
  Calendar as CalendarIcon,
  Check,
} from 'lucide-react';
import { User, Language, NotificationItem } from '../types';
import { t } from '../i18n';
import { IndianTimeClock } from './IndianTimeClock';

interface HeaderProps {
  user: User | null;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  fontSize: 'normal' | 'large' | 'xlarge';
  onFontSizeChange: (size: 'normal' | 'large' | 'xlarge') => void;
  onOpenEmergency: () => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  onSwitchDemoRole: (role: 'senior' | 'family' | 'caregiver' | 'admin') => void;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onMarkAllNotificationsRead: () => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  currentLanguage,
  onLanguageChange,
  fontSize,
  onFontSizeChange,
  onOpenEmergency,
  onOpenAuth,
  onLogout,
  onSwitchDemoRole,
  notifications,
  onMarkNotificationRead,
  onMarkAllNotificationsRead,
  activeTab,
  onSelectTab,
}) => {
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showFontMenu, setShowFontMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onSelectTab('dashboard')}>
            <div className="w-12 h-12 rounded-2xl bg-teal-600 flex items-center justify-center text-white shadow-md shadow-teal-700/20">
              <HeartPulse className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-display font-bold text-2xl tracking-tight text-slate-900">
                  {t('appName', currentLanguage)}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-xs font-semibold rounded-full bg-teal-50 text-teal-700 border border-teal-200">
                  Care
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium hidden sm:block">
                {t('tagline', currentLanguage)}
              </p>
            </div>
          </div>

          {/* Quick Controls: Emergency SOS, Indian Time, Calendar, Accessibility, Language, Notifications, User */}
          <div className="flex items-center space-x-1.5 sm:space-x-3">
            {/* Live Indian Standard Time (IST) Clock */}
            <IndianTimeClock
              language={currentLanguage}
              compact={true}
              onOpenCalendar={() => onSelectTab('calendar')}
            />

            {/* Calendar Shortcut */}
            <button
              onClick={() => onSelectTab('calendar')}
              className={`p-2 sm:px-3 sm:py-2 rounded-xl flex items-center space-x-1.5 border text-xs sm:text-sm font-bold cursor-pointer transition ${
                activeTab === 'calendar'
                  ? 'bg-teal-600 text-white border-teal-700 shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
              title="Health & Care Calendar (IST)"
            >
              <CalendarIcon className={`w-4 h-4 ${activeTab === 'calendar' ? 'text-white' : 'text-teal-600'}`} />
              <span className="hidden md:inline">{t('calendar', currentLanguage)}</span>
            </button>

            {/* EMERGENCY SOS BUTTON (Section 31 & Section 11) */}
            <button
              id="emergency-sos-btn"
              onClick={onOpenEmergency}
              className="flex items-center space-x-1.5 sm:space-x-2 px-3 sm:px-4 py-2 sm:py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold rounded-xl shadow-md shadow-rose-600/30 transition-all hover:scale-105 cursor-pointer animate-pulse focus:ring-4 focus:ring-rose-200"
              title="Immediate Emergency Assistance"
            >
              <PhoneCall className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              <span className="tracking-wide text-xs sm:text-base font-extrabold uppercase">
                {t('emergencySos', currentLanguage)}
              </span>
            </button>

            {/* Font Size & Text Legibility Accessibility Adjuster */}
            <div className="relative">
              <button
                id="font-size-btn"
                onClick={() => {
                  setShowFontMenu(!showFontMenu);
                  setShowLangMenu(false);
                  setShowNotifMenu(false);
                  setShowUserMenu(false);
                }}
                className={`p-2 sm:px-3 sm:py-2 rounded-xl flex items-center space-x-1.5 border text-sm font-bold cursor-pointer transition ${
                  showFontMenu
                    ? 'bg-teal-50 border-teal-300 text-teal-800'
                    : 'text-slate-800 hover:bg-slate-100 border-slate-200'
                }`}
                title="Adjust Text Size & Legibility"
                aria-label="Text Legibility Settings"
                aria-expanded={showFontMenu}
              >
                <Type className="w-4 h-4 text-teal-700" />
                <span className="font-extrabold text-slate-800">
                  {fontSize === 'normal' ? 'A' : fontSize === 'large' ? 'A+' : 'A++'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-600" />
              </button>

              {showFontMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowFontMenu(false)}
                    aria-hidden="true"
                  />
                  <div
                    role="menu"
                    aria-label="Text Legibility Options"
                    className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-2.5 z-50 animate-in fade-in duration-150"
                  >
                    <div className="px-3.5 py-1.5 text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-1.5 border-b border-slate-100 mb-1.5">
                      <Type className="w-4 h-4 text-teal-700" />
                      <span>{t('textLegibility', currentLanguage)}</span>
                    </div>

                    <button
                      role="menuitem"
                      onClick={() => {
                        onFontSizeChange('normal');
                        setShowFontMenu(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between hover:bg-slate-50 transition cursor-pointer ${
                        fontSize === 'normal'
                          ? 'font-bold text-teal-800 bg-teal-50/80 border-l-4 border-teal-600'
                          : 'text-slate-800 font-medium'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-900">
                          {t('fontSizeNormal', currentLanguage)}
                        </span>
                        <span className="text-xs text-slate-600">
                          {t('fontSizeStandardBadge', currentLanguage)}
                        </span>
                      </div>
                      {fontSize === 'normal' && (
                        <Check className="w-4 h-4 text-teal-700 font-bold shrink-0" />
                      )}
                    </button>

                    <button
                      role="menuitem"
                      onClick={() => {
                        onFontSizeChange('large');
                        setShowFontMenu(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between hover:bg-slate-50 transition cursor-pointer ${
                        fontSize === 'large'
                          ? 'font-bold text-teal-800 bg-teal-50/80 border-l-4 border-teal-600'
                          : 'text-slate-800 font-medium'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-900">
                          {t('fontSizeLarge', currentLanguage)}
                        </span>
                        <span className="text-xs text-teal-700 font-semibold">
                          {t('fontSizeRecommendedBadge', currentLanguage)}
                        </span>
                      </div>
                      {fontSize === 'large' && (
                        <Check className="w-4 h-4 text-teal-700 font-bold shrink-0" />
                      )}
                    </button>

                    <button
                      role="menuitem"
                      onClick={() => {
                        onFontSizeChange('xlarge');
                        setShowFontMenu(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between hover:bg-slate-50 transition cursor-pointer ${
                        fontSize === 'xlarge'
                          ? 'font-bold text-teal-800 bg-teal-50/80 border-l-4 border-teal-600'
                          : 'text-slate-800 font-medium'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-900">
                          {t('fontSizeXLarge', currentLanguage)}
                        </span>
                        <span className="text-xs text-slate-700 font-semibold">
                          {t('fontSizeHighContrastBadge', currentLanguage)}
                        </span>
                      </div>
                      {fontSize === 'xlarge' && (
                        <Check className="w-4 h-4 text-teal-700 font-bold shrink-0" />
                      )}
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Language Switcher (Section 19: English, Hindi, Marathi) */}
            <div className="relative">
              <button
                id="language-selector-btn"
                onClick={() => {
                  setShowLangMenu(!showLangMenu);
                  setShowFontMenu(false);
                  setShowNotifMenu(false);
                  setShowUserMenu(false);
                }}
                className={`p-2 sm:px-3 sm:py-2 rounded-xl flex items-center space-x-1.5 border text-sm font-bold cursor-pointer transition ${
                  showLangMenu
                    ? 'bg-teal-50 border-teal-300 text-teal-800'
                    : 'text-slate-800 hover:bg-slate-100 border-slate-200'
                }`}
                title="Change Application Language"
                aria-label="Change Application Language"
                aria-expanded={showLangMenu}
              >
                <Globe className="w-4 h-4 text-teal-700" />
                <span className="hidden md:inline font-bold text-slate-800">
                  {currentLanguage === 'en' ? 'English' : currentLanguage === 'hi' ? 'हिन्दी' : 'मराठी'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-600" />
              </button>

              {showLangMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowLangMenu(false)}
                    aria-hidden="true"
                  />
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-slate-200 py-2.5 z-50 animate-in fade-in duration-150">
                    <div className="px-3.5 py-1 text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 mb-1">
                      {t('language', currentLanguage)}
                    </div>
                    <button
                      onClick={() => {
                        onLanguageChange('en');
                        setShowLangMenu(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between hover:bg-slate-50 cursor-pointer ${
                        currentLanguage === 'en'
                          ? 'font-bold text-teal-800 bg-teal-50/80 border-l-4 border-teal-600'
                          : 'text-slate-800 font-medium'
                      }`}
                    >
                      <span className="font-semibold text-slate-900">English</span>
                      <span className="text-xs text-slate-500 font-bold">EN</span>
                    </button>
                    <button
                      onClick={() => {
                        onLanguageChange('hi');
                        setShowLangMenu(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between hover:bg-slate-50 cursor-pointer ${
                        currentLanguage === 'hi'
                          ? 'font-bold text-teal-800 bg-teal-50/80 border-l-4 border-teal-600'
                          : 'text-slate-800 font-medium'
                      }`}
                    >
                      <span className="font-semibold text-slate-900">हिन्दी</span>
                      <span className="text-xs text-slate-500 font-bold">Hindi</span>
                    </button>
                    <button
                      onClick={() => {
                        onLanguageChange('mr');
                        setShowLangMenu(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between hover:bg-slate-50 cursor-pointer ${
                        currentLanguage === 'mr'
                          ? 'font-bold text-teal-800 bg-teal-50/80 border-l-4 border-teal-600'
                          : 'text-slate-800 font-medium'
                      }`}
                    >
                      <span className="font-semibold text-slate-900">मराठी</span>
                      <span className="text-xs text-slate-500 font-bold">Marathi</span>
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Notification Center Dropdown */}
            {user && (
              <div className="relative">
                <button
                  id="notifications-bell-btn"
                  onClick={() => {
                    setShowNotifMenu(!showNotifMenu);
                    setShowLangMenu(false);
                    setShowFontMenu(false);
                    setShowUserMenu(false);
                  }}
                  className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-100 relative border border-slate-200 cursor-pointer"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5 text-slate-700" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-teal-600 text-white text-xs font-bold rounded-full flex items-center justify-center animate-bounce">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {showNotifMenu && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setShowNotifMenu(false)}
                      aria-hidden="true"
                    />
                    <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 py-3 z-50 animate-in fade-in duration-150">
                      <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                        <div className="font-bold text-slate-900 text-base">
                          {t('notifications', currentLanguage)}
                        </div>
                        {unreadCount > 0 && (
                          <button
                            onClick={onMarkAllNotificationsRead}
                            className="text-xs text-teal-700 hover:text-teal-800 font-semibold cursor-pointer"
                          >
                            Mark all as read
                          </button>
                        )}
                      </div>
                      <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                        {notifications.length === 0 ? (
                          <div className="p-6 text-center text-sm text-slate-500">
                            No notifications right now.
                          </div>
                        ) : (
                          notifications.slice(0, 8).map((n) => (
                            <div
                              key={n.id}
                              onClick={() => {
                                onMarkNotificationRead(n.id);
                                onSelectTab('notifications');
                                setShowNotifMenu(false);
                              }}
                              className={`p-3.5 hover:bg-slate-50 cursor-pointer transition-colors ${
                                !n.isRead ? 'bg-teal-50/50' : ''
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center space-x-1.5 flex-1 min-w-0">
                                  <span className="text-xs font-bold text-slate-900 truncate">{n.title}</span>
                                </div>
                                {!n.isRead && (
                                  <span className="w-2 h-2 rounded-full bg-teal-600 mt-1 shrink-0 animate-ping" />
                                )}
                              </div>
                              <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">{n.message}</p>
                              <div className="flex items-center justify-between mt-1.5 pt-1 text-[10px] text-slate-400">
                                <span>{new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                <span className="font-semibold text-teal-700 hover:underline">View Alert →</span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                      <div className="px-4 pt-2 border-t border-slate-100 text-center">
                        <button
                          onClick={() => {
                            onSelectTab('notifications');
                            setShowNotifMenu(false);
                          }}
                          className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                        >
                          View all notifications
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* User Profile & Demo Switcher */}
            {user ? (
              <div className="relative">
                <button
                  id="user-profile-menu-btn"
                  onClick={() => {
                    setShowUserMenu(!showUserMenu);
                    setShowLangMenu(false);
                    setShowFontMenu(false);
                    setShowNotifMenu(false);
                  }}
                  className="flex items-center space-x-2 pl-2 pr-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-teal-700 text-white font-bold text-sm flex items-center justify-center">
                    {user.name.charAt(0)}
                  </div>
                  <div className="text-left hidden lg:block">
                    <p className="text-xs font-bold text-slate-900 leading-tight">{user.name}</p>
                    <span className="text-[10px] uppercase font-bold text-teal-700 tracking-wider">
                      {user.role}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-600" />
                </button>

                {showUserMenu && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setShowUserMenu(false)}
                      aria-hidden="true"
                    />
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in duration-150">
                    <div className="px-4 py-3 border-b border-slate-100">
                      <p className="text-sm font-bold text-slate-900">{user.name}</p>
                      <p className="text-xs text-slate-500">{user.email}</p>
                      <div className="mt-2 inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold bg-teal-100 text-teal-800">
                        Role: {user.role === 'senior' ? 'Senior' : user.role === 'family' ? 'Family Member' : user.role === 'caregiver' ? 'Caregiver' : 'Admin'}
                      </div>
                    </div>

                    {/* Switch role preview helper for evaluation */}
                    <div className="px-4 py-2 bg-slate-50 border-b border-slate-100">
                      <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                        Switch Demo Role
                      </p>
                      <div className="grid grid-cols-4 gap-1">
                        <button
                          onClick={() => {
                            onSwitchDemoRole('senior');
                            setShowUserMenu(false);
                          }}
                          className={`text-xs py-1 rounded-lg font-medium cursor-pointer ${
                            user.role === 'senior' ? 'bg-teal-600 text-white' : 'bg-white border text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          Senior
                        </button>
                        <button
                          onClick={() => {
                            onSwitchDemoRole('family');
                            setShowUserMenu(false);
                          }}
                          className={`text-xs py-1 rounded-lg font-medium cursor-pointer ${
                            user.role === 'family' ? 'bg-teal-600 text-white' : 'bg-white border text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          Family
                        </button>
                        <button
                          onClick={() => {
                            onSwitchDemoRole('caregiver');
                            setShowUserMenu(false);
                          }}
                          className={`text-xs py-1 rounded-lg font-medium cursor-pointer ${
                            user.role === 'caregiver' ? 'bg-teal-600 text-white' : 'bg-white border text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          Caregiver
                        </button>
                        <button
                          onClick={() => {
                            onSwitchDemoRole('admin');
                            setShowUserMenu(false);
                          }}
                          className={`text-xs py-1 rounded-lg font-medium cursor-pointer ${
                            user.role === 'admin' ? 'bg-teal-600 text-white' : 'bg-white border text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          Admin
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onSelectTab('profile');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 flex items-center space-x-2 cursor-pointer"
                    >
                      <UserIcon className="w-4 h-4 text-slate-400" />
                      <span>{t('profile', currentLanguage)}</span>
                    </button>

                    <button
                      onClick={() => {
                        onOpenAuth();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-sm text-teal-700 hover:bg-teal-50 flex items-center space-x-2 cursor-pointer font-medium"
                    >
                      <KeyRound className="w-4 h-4 text-teal-600" />
                      <span>Log In to Another Role</span>
                    </button>

                    <button
                      onClick={() => {
                        onLogout();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50 flex items-center space-x-2 cursor-pointer font-medium"
                    >
                      <LogOut className="w-4 h-4 text-rose-500" />
                      <span>Log Out</span>
                    </button>
                  </div>
                </>
              )}
            </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-bold rounded-xl shadow-xs cursor-pointer flex items-center space-x-1.5"
              >
                <KeyRound className="w-4 h-4" />
                <span>Log In</span>
              </button>
            )}

            {/* Mobile Hamburger */}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="p-2 rounded-xl text-slate-700 hover:bg-slate-100 lg:hidden border border-slate-200 cursor-pointer"
            >
              {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {showMobileMenu && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-2">
          {user?.role === 'senior' && (
            <>
              {['dashboard', 'notifications', 'calendar', 'medicines', 'healthRecords', 'waterTracker', 'calorieCounter', 'wellness', 'appointments', 'familyConnect', 'healthAssistant', 'healthTips', 'profile'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => {
                    onSelectTab(tab);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-xl font-bold text-base cursor-pointer ${
                    activeTab === tab ? 'bg-teal-600 text-white' : 'text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  {tab === 'calorieCounter' ? 'Calorie Counter' : t(tab as any, currentLanguage)}
                </button>
              ))}
            </>
          )}

          {user?.role === 'family' && (
            <>
              {['familyDashboard', 'notifications', 'calendar', 'calorieCounter', 'medicalVault', 'messages', 'appointments'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => {
                    onSelectTab(tab);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-xl font-bold text-base cursor-pointer ${
                    activeTab === tab ? 'bg-teal-600 text-white' : 'text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  {tab === 'familyDashboard'
                    ? 'Senior Overview'
                    : tab === 'calorieCounter'
                    ? 'Senior Calories'
                    : tab === 'medicalVault'
                    ? 'Medical Vault'
                    : t(tab as any, currentLanguage)}
                </button>
              ))}
            </>
          )}

          {user?.role === 'caregiver' && (
            <>
              {['caregiverDashboard', 'notifications', 'calendar', 'calorieCounter', 'messages', 'familyConnect', 'profile'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => {
                    onSelectTab(tab);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-xl font-bold text-base cursor-pointer ${
                    activeTab === tab ? 'bg-teal-600 text-white' : 'text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  {tab === 'caregiverDashboard' ? 'Connected Seniors' : tab === 'calorieCounter' ? 'Calorie Counter' : t(tab as any, currentLanguage)}
                </button>
              ))}
            </>
          )}

          {user?.role === 'admin' && (
            <>
              {['adminDashboard', 'notifications', 'adminFoods', 'adminUsers', 'adminTips', 'adminReports', 'adminLogs', 'adminAnalytics'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => {
                    onSelectTab(tab);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-xl font-bold text-base cursor-pointer ${
                    activeTab === tab ? 'bg-teal-600 text-white' : 'text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  {tab === 'adminFoods' ? 'Food Database' : t(tab as any, currentLanguage)}
                </button>
              ))}
            </>
          )}
        </div>
      )}
    </header>
  );
};
